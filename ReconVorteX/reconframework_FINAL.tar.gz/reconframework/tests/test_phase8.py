"""
tests/test_phase8.py
======================
Unit tests for Phase 8 — JavaScript Intelligence.

Covers:
  • Shannon entropy calculation (known values)
  • find_high_entropy_strings — threshold, length, charset
  • find_secret_assignments — variable name matching, entropy floor
  • JSExtractor — all 14 finding types with real JS snippets
  • JSFetcher — URL filtering, script tag parsing, size limits, errors
  • Phase 8 orchestrator — JSON output schema, dedup, empty input
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from core.config import FrameworkConfig, Phase8Config, reset_config
from plugins.js.entropy import (
    find_high_entropy_strings,
    find_secret_assignments,
    shannon_entropy,
)
from plugins.js.extractors import JSExtractor, JSFinding
from plugins.js.fetcher import FetchedJS, JSDiscoveryResult, JSFetcher


# ===========================================================================
# Fixtures
# ===========================================================================

@pytest.fixture(autouse=True)
def _reset():
    reset_config()
    yield
    reset_config()


@pytest.fixture
def cfg() -> FrameworkConfig:
    c = FrameworkConfig()
    c.phase8 = Phase8Config(
        concurrency=5,
        timeout_s=5,
        max_js_size_bytes=1_048_576,
        max_js_files=50,
        entropy_threshold=4.5,
        min_secret_length=20,
        max_secret_length=200,
        scrape_live_hosts=False,   # keep tests fast
        max_live_hosts_to_scrape=5,
    )
    return c


@pytest.fixture
def extractor() -> JSExtractor:
    return JSExtractor(entropy_threshold=4.5, min_len=20, max_len=200)


# ===========================================================================
# Shannon entropy
# ===========================================================================

class TestShannonEntropy:
    def test_uniform_string_high_entropy(self):
        # "aaaabbbb" → low entropy
        s = "aaaa"
        charset = set("abcdefghijklmnopqrstuvwxyz")
        assert shannon_entropy(s, charset) == 0.0

    def test_diverse_string_higher_entropy(self):
        import string
        s = string.ascii_letters[:26]
        charset = set(string.ascii_letters + string.digits)
        assert shannon_entropy(s, charset) > 3.0

    def test_out_of_charset_returns_zero(self):
        s = "hello world!"   # space and ! not in alnum charset
        charset = set("abcdefghijklmnopqrstuvwxyz0123456789")
        assert shannon_entropy(s, charset) == 0.0

    def test_empty_string_returns_zero(self):
        assert shannon_entropy("", set("abc")) == 0.0

    def test_known_entropy(self):
        # "ab" with charset {a,b} → entropy = 1.0
        assert abs(shannon_entropy("ab", {"a", "b"}) - 1.0) < 0.001


# ===========================================================================
# find_high_entropy_strings
# ===========================================================================

class TestFindHighEntropyStrings:
    def test_finds_base64_secret(self):
        secret = "xK9pLm2nQrTvWyZ1Ab3Cd5Ef7Gh"
        src = f'const key = "{secret}"'
        # Use a low threshold to ensure detection
        hits = find_high_entropy_strings(src, threshold=3.0, min_len=10, max_len=100)
        values = [h.value for h in hits]
        assert secret in values

    def test_ignores_low_entropy_strings(self):
        src = '"aaaaaaaaaaaaaaaaaaaaaaaa"'
        hits = find_high_entropy_strings(src, threshold=4.5, min_len=20, max_len=100)
        assert len(hits) == 0

    def test_respects_min_length(self):
        src = '"shortkey"'
        hits = find_high_entropy_strings(src, threshold=3.0, min_len=20, max_len=100)
        assert len(hits) == 0

    def test_respects_max_length(self):
        long_secret = "A" * 300
        src = f'"{long_secret}"'
        hits = find_high_entropy_strings(src, threshold=3.0, min_len=20, max_len=200)
        assert len(hits) == 0

    def test_deduplicates_same_value(self):
        secret = "xK9pLm2nQrTvWyZ1Ab3Cd5Ef7Gh"
        src    = f'const a = "{secret}"; const b = "{secret}";'
        hits   = find_high_entropy_strings(src, threshold=3.0, min_len=10, max_len=100)
        assert sum(1 for h in hits if h.value == secret) == 1

    def test_sorted_by_entropy_descending(self):
        hits = find_high_entropy_strings(
            '"xK9pLm2nQrTvWyZ1Ab3Cd5Ef7Gh" "ABCDEFGHIJKLMNOPQRSTUVWXYZabcde"',
            threshold=2.0, min_len=10, max_len=100,
        )
        if len(hits) >= 2:
            assert hits[0].entropy >= hits[1].entropy


# ===========================================================================
# find_secret_assignments
# ===========================================================================

class TestFindSecretAssignments:
    def test_detects_api_key_assignment(self):
        src = 'const API_KEY = "xK9pLm2nQrTvWyZ1Ab3"'
        hits = find_secret_assignments(src, threshold=2.0, min_len=8)
        assert any(h["var_name"] == "API_KEY" for h in hits)

    def test_detects_token_assignment(self):
        src = 'let token = "eyJhbGciOiJIUzI1NiJ9abc"'
        hits = find_secret_assignments(src, threshold=2.0, min_len=8)
        assert any("token" in h["var_name"].lower() for h in hits)

    def test_ignores_unknown_var_name(self):
        src = 'const myVariable = "xK9pLm2nQrTvWyZ1Ab3"'
        hits = find_secret_assignments(src, threshold=2.0, min_len=8)
        assert not any(h["var_name"] == "myVariable" for h in hits)

    def test_respects_min_length(self):
        src = 'const key = "abc"'
        hits = find_secret_assignments(src, threshold=2.0, min_len=20)
        assert len(hits) == 0

    def test_deduplicates_same_value(self):
        val = "xK9pLm2nQrTvWyZ1Ab3"
        src = f'const key = "{val}"; const secret = "{val}"'
        hits = find_secret_assignments(src, threshold=2.0, min_len=8)
        assert sum(1 for h in hits if h["value"] == val) == 1


# ===========================================================================
# JSExtractor — finding types
# ===========================================================================

class TestJSExtractorEndpoints:
    def test_api_path_extracted(self, extractor):
        src = 'fetch("/api/users")'
        findings = extractor.extract("https://example.com/app.js", src)
        assert any(f.finding_type == "endpoint" for f in findings)

    def test_v1_path_extracted(self, extractor):
        src = 'axios.get("/v1/orders")'
        findings = extractor.extract("https://example.com/app.js", src)
        assert any(f.finding_type == "endpoint" for f in findings)

    def test_fetch_url_extracted(self, extractor):
        src = 'fetch("https://api.internal.com/data")'
        findings = extractor.extract("https://example.com/app.js", src)
        types = {f.finding_type for f in findings}
        assert "endpoint" in types or "internal_url" in types

    def test_xhr_open_extracted(self, extractor):
        src = 'xhr.open("GET", "/api/v2/profile")'
        findings = extractor.extract("https://example.com/app.js", src)
        assert any(f.finding_type == "endpoint" for f in findings)


class TestJSExtractorRoutes:
    def test_express_route_extracted(self, extractor):
        src = 'router.get("/admin/users", handler)'
        findings = extractor.extract("https://example.com/app.js", src)
        assert any(f.finding_type == "api_route" for f in findings)

    def test_app_post_extracted(self, extractor):
        src = 'app.post("/api/login", authenticate)'
        findings = extractor.extract("https://example.com/app.js", src)
        assert any(f.finding_type == "api_route" for f in findings)


class TestJSExtractorAWS:
    def test_aws_access_key_extracted(self, extractor):
        src = 'const awsKey = "AKIAIOSFODNN7EXAMPLE"'
        findings = extractor.extract("https://example.com/app.js", src)
        assert any(f.finding_type == "aws_key" for f in findings)

    def test_s3_bucket_extracted(self, extractor):
        src = 'const url = "https://my-bucket.s3.amazonaws.com/data"'
        findings = extractor.extract("https://example.com/app.js", src)
        assert any(f.finding_type == "aws_s3" for f in findings)

    def test_s3_uri_extracted(self, extractor):
        src = 'const path = "s3://my-bucket/uploads/"'
        findings = extractor.extract("https://example.com/app.js", src)
        assert any(f.finding_type == "aws_s3" for f in findings)


class TestJSExtractorGraphQL:
    def test_query_definition_extracted(self, extractor):
        src = "query GetUsers { users { id name } }"
        findings = extractor.extract("https://example.com/app.js", src)
        assert any(f.finding_type == "graphql" for f in findings)

    def test_mutation_definition_extracted(self, extractor):
        src = "mutation CreateUser($input: UserInput) { createUser(input: $input) { id } }"
        findings = extractor.extract("https://example.com/app.js", src)
        assert any(f.finding_type == "graphql" for f in findings)


class TestJSExtractorInternalURLs:
    def test_localhost_url_extracted(self, extractor):
        src = 'const base = "http://localhost:8080/api"'
        findings = extractor.extract("https://example.com/app.js", src)
        assert any(f.finding_type == "internal_url" for f in findings)

    def test_rfc1918_url_extracted(self, extractor):
        src = 'const svc = "http://192.168.1.100:3000/health"'
        findings = extractor.extract("https://example.com/app.js", src)
        assert any(f.finding_type == "internal_url" for f in findings)

    def test_10_dot_network_extracted(self, extractor):
        src = 'const url = "http://10.0.0.5:9200/"'
        findings = extractor.extract("https://example.com/app.js", src)
        assert any(f.finding_type == "internal_url" for f in findings)


class TestJSExtractorJWT:
    def test_jwt_token_extracted(self, extractor):
        src = 'const tok = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"'
        findings = extractor.extract("https://example.com/app.js", src)
        assert any(f.finding_type == "jwt" for f in findings)


class TestJSExtractorSourceMap:
    def test_source_map_extracted(self, extractor):
        src = "var a=1;\n//# sourceMappingURL=app.js.map"
        findings = extractor.extract("https://example.com/app.js", src)
        assert any(f.finding_type == "source_map" for f in findings)

    def test_source_map_value_is_filename(self, extractor):
        src = "//# sourceMappingURL=bundle.min.js.map"
        findings = extractor.extract("https://example.com/app.js", src)
        sm = next(f for f in findings if f.finding_type == "source_map")
        assert "bundle.min.js.map" in sm.value


class TestJSExtractorCommentedCode:
    def test_commented_password_extracted(self, extractor):
        src = "// password: admin123\nvar x = 1;"
        findings = extractor.extract("https://example.com/app.js", src)
        assert any(f.finding_type == "commented_code" for f in findings)

    def test_commented_api_key_extracted(self, extractor):
        src = "// api_key = AKIAIOSFODNN7EXAMPLE (old key)"
        findings = extractor.extract("https://example.com/app.js", src)
        assert any(f.finding_type == "commented_code" for f in findings)


class TestJSExtractorPackages:
    def test_require_extracted(self, extractor):
        src = 'const axios = require("axios")'
        findings = extractor.extract("https://example.com/app.js", src)
        assert any(f.finding_type == "package_ref" and "axios" in f.value for f in findings)

    def test_import_extracted(self, extractor):
        src = 'import lodash from "lodash"'
        findings = extractor.extract("https://example.com/app.js", src)
        assert any(f.finding_type == "package_ref" and "lodash" in f.value for f in findings)

    def test_relative_path_not_extracted(self, extractor):
        src = 'import helper from "./utils/helper"'
        findings = extractor.extract("https://example.com/app.js", src)
        pkg_vals = [f.value for f in findings if f.finding_type == "package_ref"]
        assert not any("./utils/helper" in v for v in pkg_vals)


class TestJSExtractorDedup:
    def test_same_endpoint_deduplicated(self, extractor):
        src = 'fetch("/api/users"); fetch("/api/users"); fetch("/api/users")'
        findings = extractor.extract("https://example.com/app.js", src)
        endpoints = [f for f in findings if f.finding_type == "endpoint"
                     and "/api/users" in f.value]
        assert len(endpoints) == 1

    def test_empty_source_returns_empty(self, extractor):
        assert extractor.extract("https://example.com/app.js", "") == []

    def test_whitespace_only_returns_empty(self, extractor):
        assert extractor.extract("https://example.com/app.js", "   \n\t  ") == []


# ===========================================================================
# JSFetcher — URL filtering
# ===========================================================================

class TestJSFetcherFiltering:
    def test_js_extension_detected(self, cfg):
        fetcher = JSFetcher(cfg.phase8)
        assert fetcher._is_js_url("https://example.com/app.js") is True
        assert fetcher._is_js_url("https://example.com/module.mjs") is True
        assert fetcher._is_js_url("https://example.com/style.css") is False
        assert fetcher._is_js_url("https://example.com/page.html") is False

    def test_js_url_with_query_string(self, cfg):
        fetcher = JSFetcher(cfg.phase8)
        assert fetcher._is_js_url("https://example.com/app.js?v=2") is True

    def test_script_tag_extraction(self, cfg):
        fetcher  = JSFetcher(cfg.phase8)
        html     = '<script src="/static/app.js"></script><script src="https://cdn.example.com/lib.js"></script>'
        base_url = "https://example.com"
        urls     = fetcher._extract_script_urls(html, base_url)
        assert any("app.js" in u for u in urls)
        assert any("lib.js" in u for u in urls)

    def test_relative_script_resolved(self, cfg):
        fetcher  = JSFetcher(cfg.phase8)
        html     = '<script src="../js/main.js"></script>'
        base_url = "https://example.com/app/"
        urls     = fetcher._extract_script_urls(html, base_url)
        assert any("main.js" in u for u in urls)

    def test_protocol_relative_script_resolved(self, cfg):
        fetcher  = JSFetcher(cfg.phase8)
        html     = '<script src="//cdn.example.com/vue.min.js"></script>'
        base_url = "https://example.com"
        urls     = fetcher._extract_script_urls(html, base_url)
        assert any("vue.min.js" in u for u in urls)
        assert any(u.startswith("https://") for u in urls)

    def test_data_uri_skipped(self, cfg):
        fetcher  = JSFetcher(cfg.phase8)
        html     = '<script src="data:text/javascript,console.log(1)"></script>'
        base_url = "https://example.com"
        urls     = fetcher._extract_script_urls(html, base_url)
        assert len(urls) == 0


# ===========================================================================
# Phase 8 orchestrator
# ===========================================================================

class TestPhase8Orchestrator:
    def _make_fetched(self, url: str, source: str) -> FetchedJS:
        return FetchedJS(url=url, source=source, size=len(source.encode()), status=200)

    @pytest.mark.asyncio
    async def test_writes_js_analysis_json(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.js_analysis_json = str(tmp_path / "js_analysis.json")
        cfg.output.urls_txt = str(tmp_path / "urls.txt")
        cfg.output.live_hosts_json = str(tmp_path / "live_hosts.json")
        reset_config()

        js_source = 'fetch("/api/users"); const APIKEY = "AKIAIOSFODNN7EXAMPLE"'
        fake_discovery = JSDiscoveryResult(
            js_urls=["https://example.com/app.js"],
            fetched=[self._make_fetched("https://example.com/app.js", js_source)],
        )

        with patch("phases.phase8_js.JSFetcher") as MockFetcher:
            MockFetcher.return_value.discover_and_fetch = AsyncMock(return_value=fake_discovery)
            from phases.phase8_js import run_phase8
            results = await run_phase8("example.com", cfg, phase6_urls=[], live_hosts=[])

        out = tmp_path / "js_analysis.json"
        assert out.exists()
        data = json.loads(out.read_text())
        assert "findings" in data
        assert "meta" in data

    @pytest.mark.asyncio
    async def test_aws_key_in_findings(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.js_analysis_json = str(tmp_path / "js_analysis.json")
        cfg.output.urls_txt = str(tmp_path / "urls.txt")
        cfg.output.live_hosts_json = str(tmp_path / "live_hosts.json")
        reset_config()

        js_source = 'const creds = "AKIAIOSFODNN7EXAMPLE"'
        fake_discovery = JSDiscoveryResult(
            js_urls=["https://example.com/config.js"],
            fetched=[self._make_fetched("https://example.com/config.js", js_source)],
        )

        with patch("phases.phase8_js.JSFetcher") as MockFetcher:
            MockFetcher.return_value.discover_and_fetch = AsyncMock(return_value=fake_discovery)
            from phases.phase8_js import run_phase8
            results = await run_phase8("example.com", cfg, phase6_urls=[], live_hosts=[])

        assert any(f.finding_type == "aws_key" for f in results)

    @pytest.mark.asyncio
    async def test_empty_input_returns_empty(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.js_analysis_json = str(tmp_path / "js_analysis.json")
        cfg.output.urls_txt = str(tmp_path / "urls.txt")
        cfg.output.live_hosts_json = str(tmp_path / "live_hosts.json")
        reset_config()

        fake_discovery = JSDiscoveryResult(js_urls=[], fetched=[])
        with patch("phases.phase8_js.JSFetcher") as MockFetcher:
            MockFetcher.return_value.discover_and_fetch = AsyncMock(return_value=fake_discovery)
            from phases.phase8_js import run_phase8
            results = await run_phase8("example.com", cfg, phase6_urls=[], live_hosts=[])

        assert results == []

    @pytest.mark.asyncio
    async def test_global_dedup_across_files(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.js_analysis_json = str(tmp_path / "js_analysis.json")
        cfg.output.urls_txt = str(tmp_path / "urls.txt")
        cfg.output.live_hosts_json = str(tmp_path / "live_hosts.json")
        reset_config()

        same_src = 'const AKIAIOSFODNN7EXAMPLE = "key"'
        fake_discovery = JSDiscoveryResult(
            js_urls=["https://example.com/a.js", "https://example.com/b.js"],
            fetched=[
                self._make_fetched("https://example.com/a.js", same_src),
                self._make_fetched("https://example.com/b.js", same_src),
            ],
        )

        with patch("phases.phase8_js.JSFetcher") as MockFetcher:
            MockFetcher.return_value.discover_and_fetch = AsyncMock(return_value=fake_discovery)
            from phases.phase8_js import run_phase8
            results = await run_phase8("example.com", cfg, phase6_urls=[], live_hosts=[])

        aws_findings = [f for f in results if f.finding_type == "aws_key"
                        and "AKIAIOSFODNN7EXAMPLE" in f.value]
        assert len(aws_findings) == 1

    @pytest.mark.asyncio
    async def test_json_type_distribution_present(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.js_analysis_json = str(tmp_path / "js_analysis.json")
        cfg.output.urls_txt = str(tmp_path / "urls.txt")
        cfg.output.live_hosts_json = str(tmp_path / "live_hosts.json")
        reset_config()

        js_source = (
            'fetch("/api/v1/users"); '
            'router.get("/admin", h); '
            'const KEY = "AKIAIOSFODNN7EXAMPLE"; '
            '//# sourceMappingURL=app.js.map'
        )
        fake_discovery = JSDiscoveryResult(
            js_urls=["https://example.com/app.js"],
            fetched=[self._make_fetched("https://example.com/app.js", js_source)],
        )

        with patch("phases.phase8_js.JSFetcher") as MockFetcher:
            MockFetcher.return_value.discover_and_fetch = AsyncMock(return_value=fake_discovery)
            from phases.phase8_js import run_phase8
            await run_phase8("example.com", cfg, phase6_urls=[], live_hosts=[])

        data = json.loads((tmp_path / "js_analysis.json").read_text())
        assert "type_distribution" in data
        assert len(data["type_distribution"]) >= 1
