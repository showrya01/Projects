"""
tests/test_phase5.py
======================
Unit tests for Phase 5 — Screenshot Collection.

Covers:
  • GowitnessRunner — binary missing (soft skip), command construction,
                      stdout parsing, timeout, temp file cleanup
  • build_gallery   — HTML structure, risk badge colours, search JS,
                      base64 embedding, empty-entries handling
  • _build_url_list — CRITICAL/HIGH priority ordering, dedup, max_hosts cap
  • Phase 5 orchestrator — metadata JSON, gallery generation, empty inputs
"""

from __future__ import annotations

import asyncio
import base64
import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from core.base_plugin import PluginContext
from core.config import FrameworkConfig, Phase5Config, reset_config
from plugins.screenshots.gallery import GalleryEntry, build_gallery
from plugins.screenshots.gowitness_runner import GowitnessRunner, ScreenshotResult, _SAVED_RE


# ===========================================================================
# Fixtures
# ===========================================================================

@pytest.fixture(autouse=True)
def _reset():
    reset_config()
    yield
    reset_config()


@pytest.fixture
def cfg() -> FrameworkConfig:
    c = FrameworkConfig()
    c.phase5 = Phase5Config(
        gowitness_bin="gowitness",
        threads=5,
        timeout_s=10,
        max_hosts=100,
        priority_risk_levels=["CRITICAL", "HIGH"],
        disable_db=True,
        screenshot_format="png",
        resolution_x=1440,
        resolution_y=900,
        output_dir="output/screenshots",
        gallery_file="output/screenshots/index.html",
        gallery_title="Test Gallery",
        thumbnails_per_row=4,
    )
    return c


@pytest.fixture
def ctx(cfg: FrameworkConfig) -> PluginContext:
    context = PluginContext(domain="example.com", config=cfg)
    context.metadata["screenshot_urls"] = [
        "https://example.com",
        "https://admin.example.com",
    ]
    return context


def _make_png_bytes() -> bytes:
    """Minimal 1×1 red PNG for testing."""
    import struct, zlib
    def chunk(name: bytes, data: bytes) -> bytes:
        c = name + data
        return struct.pack(">I", len(data)) + c + struct.pack(">I", zlib.crc32(c) & 0xFFFFFFFF)
    sig    = b"\x89PNG\r\n\x1a\n"
    ihdr   = chunk(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 8, 2, 0, 0, 0))
    idat   = chunk(b"IDAT", zlib.compress(b"\x00\xff\x00\x00"))
    iend   = chunk(b"IEND", b"")
    return sig + ihdr + idat + iend


# ===========================================================================
# GowitnessRunner — binary detection
# ===========================================================================

class TestGowitnessRunnerBinary:
    @pytest.mark.asyncio
    async def test_soft_skip_when_binary_missing(self, ctx):
        ctx.config.phase5.gowitness_bin = "/nonexistent/gowitness"
        with patch("shutil.which", return_value=None):
            result = await GowitnessRunner().execute(ctx)
        assert result.success is True
        assert result.data == []

    @pytest.mark.asyncio
    async def test_soft_skip_when_no_urls(self, ctx):
        ctx.metadata["screenshot_urls"] = []
        with patch("shutil.which", return_value="/usr/bin/gowitness"):
            result = await GowitnessRunner().execute(ctx)
        assert result.success is True
        assert result.data == []


# ===========================================================================
# GowitnessRunner — command construction
# ===========================================================================

class TestGowitnessCommand:
    def test_command_contains_required_flags(self, cfg):
        from plugins.screenshots.gowitness_runner import GowitnessRunner
        cmd = GowitnessRunner._build_cmd(
            "/usr/bin/gowitness",
            "/tmp/urls.txt",
            Path("output/screenshots"),
            cfg.phase5,
        )
        assert "file" in cmd
        assert "-f" in cmd
        assert "--threads" in cmd
        assert "--timeout" in cmd
        assert "--resolution-x" in cmd
        assert "--resolution-y" in cmd
        assert "--disable-db" in cmd

    def test_threads_value_in_command(self, cfg):
        from plugins.screenshots.gowitness_runner import GowitnessRunner
        cmd = GowitnessRunner._build_cmd(
            "/usr/bin/gowitness", "/tmp/urls.txt",
            Path("output/screenshots"), cfg.phase5,
        )
        idx = cmd.index("--threads")
        assert cmd[idx + 1] == str(cfg.phase5.threads)

    def test_disable_db_flag_present_when_enabled(self, cfg):
        from plugins.screenshots.gowitness_runner import GowitnessRunner
        cfg.phase5.disable_db = True
        cmd = GowitnessRunner._build_cmd(
            "/usr/bin/gowitness", "/tmp/urls.txt",
            Path("output/screenshots"), cfg.phase5,
        )
        assert "--disable-db" in cmd

    def test_disable_db_flag_absent_when_disabled(self, cfg):
        from plugins.screenshots.gowitness_runner import GowitnessRunner
        cfg.phase5.disable_db = False
        cmd = GowitnessRunner._build_cmd(
            "/usr/bin/gowitness", "/tmp/urls.txt",
            Path("output/screenshots"), cfg.phase5,
        )
        assert "--disable-db" not in cmd

    def test_delay_flag_added_when_nonzero(self, cfg):
        from plugins.screenshots.gowitness_runner import GowitnessRunner
        cfg.phase5.delay = 2
        cmd = GowitnessRunner._build_cmd(
            "/usr/bin/gowitness", "/tmp/urls.txt",
            Path("output/screenshots"), cfg.phase5,
        )
        assert "--delay" in cmd
        idx = cmd.index("--delay")
        assert cmd[idx + 1] == "2"


# ===========================================================================
# GowitnessRunner — stdout parsing regex
# ===========================================================================

class TestGowitnessStdoutParsing:
    def test_matches_saved_to_pattern(self):
        line = "Screenshot of https://example.com saved to /out/abc123.png"
        m = _SAVED_RE.search(line)
        assert m is not None
        assert m.group(1).endswith(".png")

    def test_matches_screenshotted_arrow_pattern(self):
        line = "Screenshotted https://example.com -> screenshots/def456.png"
        m = _SAVED_RE.search(line)
        assert m is not None

    def test_no_match_on_unrelated_line(self):
        line = "Starting browser with 10 threads"
        assert _SAVED_RE.search(line) is None

    def test_no_match_on_empty_line(self):
        assert _SAVED_RE.search("") is None

    def test_jpg_extension_also_matches(self):
        line = "Screenshot saved to /out/img001.jpg"
        m = _SAVED_RE.search(line)
        assert m is not None


# ===========================================================================
# GowitnessRunner — subprocess mock
# ===========================================================================

class TestGowitnessSubprocess:
    @pytest.mark.asyncio
    async def test_successful_run_marks_success(self, ctx, tmp_path):
        ctx.config.phase5.output_dir = str(tmp_path)
        # Create a fake PNG in the output dir to simulate gowitness output
        fake_png = tmp_path / "abc123.png"
        fake_png.write_bytes(_make_png_bytes())

        stdout_text = (
            f"Screenshot of https://example.com saved to {fake_png}\n"
            f"Screenshot of https://admin.example.com saved to {fake_png}\n"
        ).encode()

        mock_proc = MagicMock()
        mock_proc.returncode = 0
        mock_proc.communicate = AsyncMock(return_value=(stdout_text, b""))

        with patch("shutil.which", return_value="/usr/bin/gowitness"), \
             patch("asyncio.create_subprocess_exec", return_value=mock_proc), \
             patch("asyncio.wait_for", return_value=(stdout_text, b"")), \
             patch("pathlib.Path.unlink"):
            result = await GowitnessRunner().execute(ctx)

        assert result.success is True
        assert result.data is not None

    @pytest.mark.asyncio
    async def test_timeout_marks_error(self, ctx):
        async def _timeout(*args, **kwargs):
            raise asyncio.TimeoutError()

        mock_proc = MagicMock()
        mock_proc.returncode = 1
        mock_proc.communicate = AsyncMock(return_value=(b"", b""))

        with patch("shutil.which", return_value="/usr/bin/gowitness"), \
             patch("asyncio.create_subprocess_exec", return_value=mock_proc), \
             patch("asyncio.wait_for", side_effect=asyncio.TimeoutError), \
             patch("pathlib.Path.unlink"):
            result = await GowitnessRunner().execute(ctx)

        assert result.success is True   # plugin itself doesn't fail
        errors = [r.error for r in (result.data or []) if r.error]
        assert any("timeout" in str(e).lower() for e in errors)

    @pytest.mark.asyncio
    async def test_temp_file_cleaned_up_on_success(self, ctx, tmp_path):
        ctx.config.phase5.output_dir = str(tmp_path)
        mock_proc = MagicMock()
        mock_proc.returncode = 0
        mock_proc.communicate = AsyncMock(return_value=(b"", b""))

        unlinked: list[str] = []

        original_unlink = Path.unlink
        def _track_unlink(self, *args, **kwargs):
            unlinked.append(str(self))

        with patch("shutil.which", return_value="/usr/bin/gowitness"), \
             patch("asyncio.create_subprocess_exec", return_value=mock_proc), \
             patch("asyncio.wait_for", return_value=(b"", b"")), \
             patch.object(Path, "unlink", _track_unlink):
            await GowitnessRunner().execute(ctx)

        # At least one temp file was unlinked
        assert any("rf_screenshots_" in p for p in unlinked)


# ===========================================================================
# build_gallery — HTML structure
# ===========================================================================

class TestBuildGallery:
    def _make_entry(self, tmp_path: Path, url: str, risk: str = "HIGH") -> GalleryEntry:
        png = tmp_path / f"{url.replace('://', '_').replace('/', '_')}.png"
        png.write_bytes(_make_png_bytes())
        return GalleryEntry(
            url=url,
            file_path=str(png),
            host=url.split("//")[-1].split("/")[0],
            risk_level=risk,
            tags=["admin-panel", "high-value"],
            title="Test Page",
        )

    def test_generates_html_file(self, tmp_path):
        entry = self._make_entry(tmp_path, "https://example.com", "HIGH")
        out   = tmp_path / "index.html"
        ok    = build_gallery([entry], out)
        assert ok is True
        assert out.exists()

    def test_html_contains_risk_badge(self, tmp_path):
        entry = self._make_entry(tmp_path, "https://example.com", "CRITICAL")
        out   = tmp_path / "index.html"
        build_gallery([entry], out)
        html = out.read_text()
        assert "CRITICAL" in html

    def test_html_contains_host(self, tmp_path):
        entry = self._make_entry(tmp_path, "https://admin.example.com", "HIGH")
        out   = tmp_path / "index.html"
        build_gallery([entry], out)
        html = out.read_text()
        assert "admin.example.com" in html

    def test_html_contains_base64_image(self, tmp_path):
        entry = self._make_entry(tmp_path, "https://example.com")
        out   = tmp_path / "index.html"
        build_gallery([entry], out)
        html = out.read_text()
        assert "data:image/png;base64," in html

    def test_html_contains_search_input(self, tmp_path):
        entry = self._make_entry(tmp_path, "https://example.com")
        out   = tmp_path / "index.html"
        build_gallery([entry], out)
        html = out.read_text()
        assert 'id="search"' in html

    def test_html_contains_risk_filter(self, tmp_path):
        entry = self._make_entry(tmp_path, "https://example.com")
        out   = tmp_path / "index.html"
        build_gallery([entry], out)
        html = out.read_text()
        assert 'id="risk-filter"' in html

    def test_html_contains_filter_js(self, tmp_path):
        entry = self._make_entry(tmp_path, "https://example.com")
        out   = tmp_path / "index.html"
        build_gallery([entry], out)
        html = out.read_text()
        assert "filterCards" in html

    def test_multiple_entries_all_in_gallery(self, tmp_path):
        entries = [
            self._make_entry(tmp_path, "https://a.example.com", "CRITICAL"),
            self._make_entry(tmp_path, "https://b.example.com", "HIGH"),
            self._make_entry(tmp_path, "https://c.example.com", "MEDIUM"),
        ]
        out = tmp_path / "index.html"
        build_gallery(entries, out)
        html = out.read_text()
        assert "a.example.com" in html
        assert "b.example.com" in html
        assert "c.example.com" in html

    def test_returns_false_when_no_valid_images(self, tmp_path):
        entry = GalleryEntry(
            url="https://example.com",
            file_path="/nonexistent/path.png",
            host="example.com",
            risk_level="HIGH",
        )
        out = tmp_path / "index.html"
        ok  = build_gallery([entry], out)
        assert ok is False
        assert not out.exists()

    def test_custom_title_in_html(self, tmp_path):
        entry = self._make_entry(tmp_path, "https://example.com")
        out   = tmp_path / "index.html"
        build_gallery([entry], out, title="Custom Recon Title")
        html = out.read_text()
        assert "Custom Recon Title" in html

    def test_risk_colour_in_badge(self, tmp_path):
        entry = self._make_entry(tmp_path, "https://example.com", "CRITICAL")
        out   = tmp_path / "index.html"
        build_gallery([entry], out)
        html = out.read_text()
        # CRITICAL badge should use red colour
        assert "#ff4444" in html

    def test_tags_rendered_in_card(self, tmp_path):
        entry = self._make_entry(tmp_path, "https://example.com")
        entry.tags = ["admin-panel", "jenkins"]
        out = tmp_path / "index.html"
        build_gallery([entry], out)
        html = out.read_text()
        assert "admin-panel" in html
        assert "jenkins" in html


# ===========================================================================
# URL list building — _build_url_list
# ===========================================================================

class TestBuildUrlList:
    def _cfg(self, max_hosts=10):
        c = Phase5Config(
            max_hosts=max_hosts,
            priority_risk_levels=["CRITICAL", "HIGH"],
        )
        return c

    def test_critical_hosts_first(self):
        from phases.phase5_screenshots import _build_url_list
        intel = [
            {"url": "https://jenkins.example.com", "risk_level": "CRITICAL"},
            {"url": "https://admin.example.com",   "risk_level": "HIGH"},
        ]
        hosts = [
            {"url": "https://www.example.com"},
        ]
        urls = _build_url_list(intel, hosts, self._cfg())
        assert urls[0] == "https://jenkins.example.com"
        assert urls[1] == "https://admin.example.com"

    def test_live_hosts_fill_remaining_slots(self):
        from phases.phase5_screenshots import _build_url_list
        intel = [{"url": "https://admin.example.com", "risk_level": "CRITICAL"}]
        hosts = [
            {"url": "https://www.example.com"},
            {"url": "https://blog.example.com"},
        ]
        urls = _build_url_list(intel, hosts, self._cfg(max_hosts=10))
        assert "https://www.example.com"  in urls
        assert "https://blog.example.com" in urls

    def test_max_hosts_cap_respected(self):
        from phases.phase5_screenshots import _build_url_list
        hosts = [{"url": f"https://sub{i}.example.com"} for i in range(50)]
        urls  = _build_url_list([], hosts, self._cfg(max_hosts=10))
        assert len(urls) == 10

    def test_deduplication_across_intel_and_hosts(self):
        from phases.phase5_screenshots import _build_url_list
        intel = [{"url": "https://admin.example.com", "risk_level": "HIGH"}]
        hosts = [{"url": "https://admin.example.com"}]   # same URL
        urls  = _build_url_list(intel, hosts, self._cfg())
        assert urls.count("https://admin.example.com") == 1

    def test_medium_risk_not_prioritised(self):
        from phases.phase5_screenshots import _build_url_list
        intel = [
            {"url": "https://staging.example.com", "risk_level": "MEDIUM"},
        ]
        hosts = [{"url": "https://api.example.com"}]
        urls  = _build_url_list(intel, hosts, self._cfg())
        # MEDIUM not in priority list — comes from hosts fill, not intel
        # staging URL still appears (from hosts), just not first guaranteed
        assert "https://api.example.com" in urls

    def test_empty_intel_uses_hosts_only(self):
        from phases.phase5_screenshots import _build_url_list
        hosts = [
            {"url": "https://www.example.com"},
            {"url": "https://api.example.com"},
        ]
        urls = _build_url_list([], hosts, self._cfg())
        assert "https://www.example.com" in urls
        assert "https://api.example.com" in urls

    def test_empty_inputs_returns_empty(self):
        from phases.phase5_screenshots import _build_url_list
        assert _build_url_list([], [], self._cfg()) == []


# ===========================================================================
# Phase 5 orchestrator
# ===========================================================================

class TestPhase5Orchestrator:
    def _intel_json(self, tmp_path: Path, findings: list) -> Path:
        p = tmp_path / "asset_intelligence.json"
        p.write_text(json.dumps({"meta": {}, "findings": findings}))
        return p

    def _hosts_json(self, tmp_path: Path, hosts: list) -> Path:
        p = tmp_path / "live_hosts.json"
        p.write_text(json.dumps({"meta": {}, "hosts": hosts}))
        return p

    def _fake_screenshot(self, tmp_path: Path, url: str) -> ScreenshotResult:
        png = tmp_path / "screenshot.png"
        png.write_bytes(_make_png_bytes())
        return ScreenshotResult(url=url, file_path=str(png), success=True)

    @pytest.mark.asyncio
    async def test_writes_metadata_json(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.phase5.output_dir   = str(tmp_path / "screenshots")
        cfg.phase5.gallery_file = str(tmp_path / "screenshots" / "index.html")
        cfg.output.asset_intelligence_json = str(self._intel_json(tmp_path, []))
        cfg.output.live_hosts_json = str(self._hosts_json(tmp_path, [
            {"url": "https://example.com", "host": "example.com"},
        ]))
        reset_config()

        fake_shot = self._fake_screenshot(tmp_path, "https://example.com")
        mock_result = MagicMock(success=True, data=[fake_shot], error=None,
                                duration_seconds=0.1)

        with patch("plugins.screenshots.gowitness_runner.GowitnessRunner.run",
                   return_value=mock_result):
            from phases.phase5_screenshots import run_phase5
            result = await run_phase5("example.com", cfg)

        meta_path = tmp_path / "screenshots" / "metadata.json"
        assert meta_path.exists()
        data = json.loads(meta_path.read_text())
        assert data["meta"]["total_urls"] >= 1

    @pytest.mark.asyncio
    async def test_gallery_generated_when_screenshots_exist(
        self, cfg: FrameworkConfig, tmp_path: Path
    ):
        cfg.phase5.output_dir   = str(tmp_path / "screenshots")
        cfg.phase5.gallery_file = str(tmp_path / "screenshots" / "index.html")
        cfg.output.asset_intelligence_json = str(self._intel_json(tmp_path, []))
        cfg.output.live_hosts_json = str(self._hosts_json(tmp_path, [
            {"url": "https://example.com", "host": "example.com"},
        ]))
        reset_config()

        fake_shot = self._fake_screenshot(tmp_path, "https://example.com")
        mock_result = MagicMock(success=True, data=[fake_shot], error=None,
                                duration_seconds=0.1)

        with patch("plugins.screenshots.gowitness_runner.GowitnessRunner.run",
                   return_value=mock_result):
            from phases.phase5_screenshots import run_phase5
            result = await run_phase5("example.com", cfg)

        assert result.gallery_path is not None
        assert Path(result.gallery_path).exists()

    @pytest.mark.asyncio
    async def test_critical_hosts_prioritised(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.phase5.output_dir   = str(tmp_path / "screenshots")
        cfg.phase5.gallery_file = str(tmp_path / "screenshots" / "index.html")
        cfg.output.asset_intelligence_json = str(self._intel_json(tmp_path, [
            {"url": "https://jenkins.example.com", "host": "jenkins.example.com",
             "risk_level": "CRITICAL", "tags": ["jenkins"]},
        ]))
        cfg.output.live_hosts_json = str(self._hosts_json(tmp_path, [
            {"url": "https://www.example.com", "host": "www.example.com"},
        ]))
        reset_config()

        captured_urls: list[str] = []
        original_run = GowitnessRunner.run

        async def _capture_urls(self, ctx):
            captured_urls.extend(ctx.metadata.get("screenshot_urls", []))
            return MagicMock(success=True, data=[], error=None, duration_seconds=0.0)

        with patch.object(GowitnessRunner, "run", _capture_urls):
            from phases.phase5_screenshots import run_phase5
            await run_phase5("example.com", cfg)

        assert len(captured_urls) >= 1
        assert captured_urls[0] == "https://jenkins.example.com"

    @pytest.mark.asyncio
    async def test_empty_live_hosts_returns_zero_urls(
        self, cfg: FrameworkConfig, tmp_path: Path
    ):
        cfg.phase5.output_dir   = str(tmp_path / "screenshots")
        cfg.phase5.gallery_file = str(tmp_path / "screenshots" / "index.html")
        cfg.output.asset_intelligence_json = str(self._intel_json(tmp_path, []))
        cfg.output.live_hosts_json = str(self._hosts_json(tmp_path, []))
        reset_config()

        from phases.phase5_screenshots import run_phase5
        result = await run_phase5("example.com", cfg)
        assert result.total_urls == 0
        assert result.screenshots == []

    @pytest.mark.asyncio
    async def test_metadata_records_risk_level(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.phase5.output_dir   = str(tmp_path / "screenshots")
        cfg.phase5.gallery_file = str(tmp_path / "screenshots" / "index.html")
        cfg.output.asset_intelligence_json = str(self._intel_json(tmp_path, [
            {"url": "https://admin.example.com", "host": "admin.example.com",
             "risk_level": "CRITICAL", "tags": ["admin-panel"]},
        ]))
        cfg.output.live_hosts_json = str(self._hosts_json(tmp_path, []))
        reset_config()

        fake_shot = self._fake_screenshot(tmp_path, "https://admin.example.com")
        mock_result = MagicMock(success=True, data=[fake_shot], error=None,
                                duration_seconds=0.1)

        with patch("plugins.screenshots.gowitness_runner.GowitnessRunner.run",
                   return_value=mock_result):
            from phases.phase5_screenshots import run_phase5
            await run_phase5("example.com", cfg)

        meta = json.loads(
            (tmp_path / "screenshots" / "metadata.json").read_text()
        )
        screenshot_entry = next(
            (s for s in meta["screenshots"]
             if "admin.example.com" in s.get("url", "")),
            None,
        )
        assert screenshot_entry is not None
        assert screenshot_entry["risk_level"] == "CRITICAL"
