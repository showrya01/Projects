"""
tests/test_phase10.py
=======================
Unit tests for Phase 10 — Safe Vulnerability Scanning.

Covers:
  • Individual header checks — positive + negative cases
  • Cookie flag checks — Secure, HttpOnly
  • CORS misconfiguration detection
  • HeaderChecker.check_all — concurrent, aiohttp mock
  • NucleiScanner — binary missing (soft skip), JSON parsing, severity mapping
  • Phase 10 orchestrator — merge/dedup, Phase 11 scores, JSON schema
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from core.base_plugin import PluginContext
from core.config import FrameworkConfig, Phase10Config, reset_config
from core.models import NucleiFinding
from plugins.scanner.header_checker import (
    HeaderChecker,
    _check_cookies,
    _check_cors,
    _check_csp,
    _check_hsts,
    _check_permissions,
    _check_referrer,
    _check_server_disclosure,
    _check_x_powered_by,
    _check_xcto,
    _check_xframe,
    _check_xss_protection,
)
from plugins.scanner.nuclei_scanner import NucleiScanner


# ===========================================================================
# Fixtures
# ===========================================================================

@pytest.fixture(autouse=True)
def _reset():
    reset_config()
    yield
    reset_config()


@pytest.fixture
def cfg() -> FrameworkConfig:
    c = FrameworkConfig()
    c.phase10 = Phase10Config(
        nuclei_bin="nuclei",
        concurrency=5,
        timeout_s=5,
        tool_timeout=30,
        check_headers=True,
        header_timeout_s=5,
        score_critical=15,
        score_high=10,
        score_medium=6,
        score_low=3,
        score_info=1,
    )
    return c


@pytest.fixture
def ctx(cfg: FrameworkConfig) -> PluginContext:
    context = PluginContext(domain="example.com", config=cfg)
    context.metadata["scan_urls"] = [
        "https://example.com",
        "https://admin.example.com",
    ]
    return context


# ===========================================================================
# Individual header checks — _check_hsts
# ===========================================================================

class TestHSTSCheck:
    def test_missing_hsts_on_https(self):
        result = _check_hsts({}, "https://example.com")
        assert result is not None
        assert result.check_id == "missing-hsts"
        assert result.severity == "high"

    def test_no_hsts_check_on_http(self):
        result = _check_hsts({}, "http://example.com")
        assert result is None

    def test_hsts_present_returns_none(self):
        headers = {"strict-transport-security": "max-age=31536000; includeSubDomains"}
        assert _check_hsts(headers, "https://example.com") is None

    def test_short_max_age_flagged(self):
        headers = {"strict-transport-security": "max-age=3600"}
        result = _check_hsts(headers, "https://example.com")
        assert result is not None
        assert result.check_id == "short-hsts-maxage"
        assert result.severity == "medium"

    def test_max_age_exactly_one_year_ok(self):
        headers = {"strict-transport-security": "max-age=31536000"}
        assert _check_hsts(headers, "https://example.com") is None


# ===========================================================================
# _check_csp
# ===========================================================================

class TestCSPCheck:
    def test_missing_csp_flagged(self):
        issues = _check_csp({})
        assert any(i.check_id == "missing-csp" for i in issues)
        assert any(i.severity == "high" for i in issues)

    def test_csp_present_no_issues(self):
        headers = {"content-security-policy": "default-src 'self'"}
        issues  = _check_csp(headers)
        assert not any(i.check_id == "missing-csp" for i in issues)

    def test_unsafe_inline_flagged(self):
        headers = {"content-security-policy": "default-src 'self'; script-src 'unsafe-inline'"}
        issues  = _check_csp(headers)
        assert any(i.check_id == "csp-unsafe-inline" for i in issues)

    def test_unsafe_eval_flagged(self):
        headers = {"content-security-policy": "script-src 'self' 'unsafe-eval'"}
        issues  = _check_csp(headers)
        assert any(i.check_id == "csp-unsafe-eval" for i in issues)

    def test_wildcard_source_flagged(self):
        headers = {"content-security-policy": "default-src *"}
        issues  = _check_csp(headers)
        assert any(i.check_id == "csp-wildcard-src" for i in issues)

    def test_clean_csp_no_issues(self):
        headers = {"content-security-policy": "default-src 'self'; script-src 'self'"}
        issues  = _check_csp(headers)
        assert len(issues) == 0


# ===========================================================================
# _check_xframe, _check_xcto
# ===========================================================================

class TestXFrameXCTO:
    def test_missing_xframe_flagged(self):
        result = _check_xframe({})
        assert result is not None
        assert result.severity == "medium"

    def test_xframe_present_ok(self):
        assert _check_xframe({"x-frame-options": "DENY"}) is None
        assert _check_xframe({"x-frame-options": "SAMEORIGIN"}) is None

    def test_missing_xcto_flagged(self):
        result = _check_xcto({})
        assert result is not None
        assert result.severity == "medium"

    def test_xcto_nosniff_ok(self):
        assert _check_xcto({"x-content-type-options": "nosniff"}) is None


# ===========================================================================
# _check_referrer, _check_permissions
# ===========================================================================

class TestReferrerPermissions:
    def test_missing_referrer_policy_flagged(self):
        result = _check_referrer({})
        assert result is not None
        assert result.severity == "low"

    def test_referrer_policy_present_ok(self):
        assert _check_referrer({"referrer-policy": "no-referrer"}) is None

    def test_missing_permissions_flagged(self):
        result = _check_permissions({})
        assert result is not None
        assert result.severity == "low"

    def test_permissions_policy_present_ok(self):
        assert _check_permissions({"permissions-policy": "camera=()"}) is None

    def test_feature_policy_accepted(self):
        # Legacy name
        assert _check_permissions({"feature-policy": "microphone 'none'"}) is None


# ===========================================================================
# _check_cors
# ===========================================================================

class TestCORSCheck:
    def test_wildcard_cors_flagged(self):
        result = _check_cors({"access-control-allow-origin": "*"})
        assert result is not None
        assert result.severity == "high"
        assert result.check_id == "cors-wildcard"

    def test_wildcard_with_credentials_critical(self):
        result = _check_cors({
            "access-control-allow-origin": "*",
            "access-control-allow-credentials": "true",
        })
        assert result is not None
        assert result.severity == "critical"
        assert result.check_id == "cors-wildcard-with-credentials"

    def test_specific_origin_not_flagged(self):
        assert _check_cors({
            "access-control-allow-origin": "https://example.com"
        }) is None

    def test_no_cors_header_not_flagged(self):
        assert _check_cors({}) is None


# ===========================================================================
# _check_server_disclosure, _check_x_powered_by
# ===========================================================================

class TestInfoDisclosure:
    def test_server_with_version_flagged(self):
        result = _check_server_disclosure({"server": "Apache/2.4.51"})
        assert result is not None
        assert result.severity == "low"

    def test_server_without_version_ok(self):
        assert _check_server_disclosure({"server": "Apache"}) is None
        assert _check_server_disclosure({"server": "nginx"}) is None

    def test_no_server_header_ok(self):
        assert _check_server_disclosure({}) is None

    def test_x_powered_by_flagged(self):
        result = _check_x_powered_by({"x-powered-by": "PHP/8.2.1"})
        assert result is not None
        assert result.severity == "low"

    def test_no_x_powered_by_ok(self):
        assert _check_x_powered_by({}) is None


# ===========================================================================
# _check_xss_protection
# ===========================================================================

class TestXSSProtection:
    def test_missing_flagged_as_info(self):
        result = _check_xss_protection({})
        assert result is not None
        assert result.severity == "info"

    def test_present_ok(self):
        assert _check_xss_protection({"x-xss-protection": "1; mode=block"}) is None


# ===========================================================================
# _check_cookies
# ===========================================================================

class TestCookieChecks:
    def test_missing_secure_flagged(self):
        issues = _check_cookies("session=abc123; Path=/; HttpOnly")
        assert any(i.check_id == "cookie-missing-secure" for i in issues)

    def test_missing_httponly_flagged(self):
        issues = _check_cookies("session=abc123; Path=/; Secure")
        assert any(i.check_id == "cookie-missing-httponly" for i in issues)

    def test_both_flags_present_no_issues(self):
        issues = _check_cookies("session=abc123; Path=/; Secure; HttpOnly")
        assert len(issues) == 0

    def test_empty_cookie_no_issues(self):
        assert _check_cookies("") == []

    def test_multiple_cookies_checked(self):
        cookie_str = "a=1; Secure; HttpOnly, b=2; Path=/"
        issues = _check_cookies(cookie_str)
        # Cookie 'b' is missing both Secure and HttpOnly
        assert len(issues) >= 1


# ===========================================================================
# NucleiScanner
# ===========================================================================

class TestNucleiScanner:
    @pytest.mark.asyncio
    async def test_soft_skip_when_binary_missing(self, ctx):
        ctx.config.phase10.nuclei_bin = "/nonexistent/nuclei"
        with patch("shutil.which", return_value=None):
            result = await NucleiScanner().execute(ctx)
        assert result.success is True
        assert result.data == []

    @pytest.mark.asyncio
    async def test_soft_skip_when_no_urls(self, ctx):
        ctx.metadata["scan_urls"] = []
        with patch("shutil.which", return_value="/usr/bin/nuclei"):
            result = await NucleiScanner().execute(ctx)
        assert result.success is True
        assert result.data == []

    @pytest.mark.asyncio
    async def test_parses_nuclei_json_output(self, ctx):
        fake_stdout = "\n".join([
            json.dumps({
                "template-id": "apache-detect",
                "info": {"name": "Apache Detection", "severity": "info",
                         "description": "Apache web server detected",
                         "tags": ["tech", "apache"]},
                "host": "https://example.com",
                "matched-at": "https://example.com",
            }),
            json.dumps({
                "template-id": "missing-csp",
                "info": {"name": "Missing CSP", "severity": "high",
                         "description": "No Content-Security-Policy",
                         "tags": ["security-headers"]},
                "host": "https://admin.example.com",
                "matched-at": "https://admin.example.com",
            }),
        ]).encode()

        mock_proc = MagicMock()
        mock_proc.communicate = AsyncMock(return_value=(fake_stdout, b""))

        with patch("shutil.which", return_value="/usr/bin/nuclei"), \
             patch("asyncio.create_subprocess_exec", return_value=mock_proc), \
             patch("asyncio.wait_for", return_value=(fake_stdout, b"")), \
             patch("pathlib.Path.unlink"):
            result = await NucleiScanner().execute(ctx)

        assert result.success is True
        assert result.data is not None
        assert len(result.data) == 2
        names = {f.name for f in result.data}
        assert "Apache Detection" in names
        assert "Missing CSP" in names

    @pytest.mark.asyncio
    async def test_severity_mapped_correctly(self, ctx):
        fake_stdout = json.dumps({
            "template-id": "test-crit",
            "info": {"name": "Critical Test", "severity": "critical", "tags": []},
            "host": "https://example.com",
            "matched-at": "https://example.com",
        }).encode()

        mock_proc = MagicMock()
        mock_proc.communicate = AsyncMock(return_value=(fake_stdout, b""))

        with patch("shutil.which", return_value="/usr/bin/nuclei"), \
             patch("asyncio.create_subprocess_exec", return_value=mock_proc), \
             patch("asyncio.wait_for", return_value=(fake_stdout, b"")), \
             patch("pathlib.Path.unlink"):
            result = await NucleiScanner().execute(ctx)

        assert result.data[0].severity == "critical"

    @pytest.mark.asyncio
    async def test_corrupt_json_lines_skipped(self, ctx):
        fake_stdout = b"not json\n{broken\n\n"
        mock_proc = MagicMock()
        mock_proc.communicate = AsyncMock(return_value=(fake_stdout, b""))

        with patch("shutil.which", return_value="/usr/bin/nuclei"), \
             patch("asyncio.create_subprocess_exec", return_value=mock_proc), \
             patch("asyncio.wait_for", return_value=(fake_stdout, b"")), \
             patch("pathlib.Path.unlink"):
            result = await NucleiScanner().execute(ctx)

        assert result.success is True
        assert result.data == []

    @pytest.mark.asyncio
    async def test_host_parsed_correctly(self, ctx):
        fake_stdout = json.dumps({
            "template-id": "cors-wildcard",
            "info": {"name": "CORS Wildcard", "severity": "high", "tags": ["cors"]},
            "host": "https://api.example.com/v1/data",
            "matched-at": "https://api.example.com/v1/data",
        }).encode()

        mock_proc = MagicMock()
        mock_proc.communicate = AsyncMock(return_value=(fake_stdout, b""))

        with patch("shutil.which", return_value="/usr/bin/nuclei"), \
             patch("asyncio.create_subprocess_exec", return_value=mock_proc), \
             patch("asyncio.wait_for", return_value=(fake_stdout, b"")), \
             patch("pathlib.Path.unlink"):
            result = await NucleiScanner().execute(ctx)

        # Host should be extracted without path/port
        assert result.data[0].host == "api.example.com"


# ===========================================================================
# Phase 10 orchestrator
# ===========================================================================

class TestPhase10Orchestrator:
    def _hosts_json(self, tmp_path: Path, hosts: list[dict]) -> Path:
        p = tmp_path / "live_hosts.json"
        p.write_text(json.dumps({"meta": {}, "hosts": hosts}))
        return p

    def _nuclei_finding(self, host: str, sev: str = "high") -> NucleiFinding:
        return NucleiFinding(
            host=host, template_id=f"test-{sev}",
            name=f"Test {sev.title()} Finding", severity=sev,
            matched_at=f"https://{host}", tags=["misconfig"],
        )

    @pytest.mark.asyncio
    async def test_writes_nuclei_results_json(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.nuclei_results_json = str(tmp_path / "nuclei_results.json")
        cfg.output.live_hosts_json = str(self._hosts_json(tmp_path, [
            {"url": "https://example.com", "host": "example.com"},
        ]))
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        finding = self._nuclei_finding("example.com", "high")
        mock_result = MagicMock(success=True, data=[finding], error=None,
                                duration_seconds=0.1)

        with patch("plugins.scanner.nuclei_scanner.NucleiScanner.run",
                   return_value=mock_result), \
             patch("plugins.scanner.header_checker.HeaderChecker.check_all",
                   AsyncMock(return_value=[])):
            from phases.phase10_scan import run_phase10
            results = await run_phase10("example.com", cfg)

        out = tmp_path / "nuclei_results.json"
        assert out.exists()
        data = json.loads(out.read_text())
        assert "findings" in data
        assert "meta" in data
        assert data["meta"]["total"] >= 1

    @pytest.mark.asyncio
    async def test_deduplication_same_host_template(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.nuclei_results_json = str(tmp_path / "nuclei_results.json")
        cfg.output.live_hosts_json = str(self._hosts_json(tmp_path, [
            {"url": "https://example.com", "host": "example.com"},
        ]))
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        finding = self._nuclei_finding("example.com", "medium")
        mock_result = MagicMock(success=True, data=[finding, finding], error=None,
                                duration_seconds=0.1)

        with patch("plugins.scanner.nuclei_scanner.NucleiScanner.run",
                   return_value=mock_result), \
             patch("plugins.scanner.header_checker.HeaderChecker.check_all",
                   AsyncMock(return_value=[finding])):
            from phases.phase10_scan import run_phase10
            results = await run_phase10("example.com", cfg)

        # Same (host, template_id) from Nuclei twice + header checker = 1
        assert len(results) == 1

    @pytest.mark.asyncio
    async def test_phase11_scores_computed(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.nuclei_results_json = str(tmp_path / "nuclei_results.json")
        cfg.output.live_hosts_json = str(self._hosts_json(tmp_path, [
            {"url": "https://example.com", "host": "example.com"},
        ]))
        cfg.database.path = str(tmp_path / "recon.db")
        cfg.phase10.score_high = 10
        cfg.phase10.score_medium = 6
        reset_config()

        findings = [
            self._nuclei_finding("example.com", "high"),    # +10
            NucleiFinding(host="example.com", template_id="test-med",
                         name="Test Medium", severity="medium",
                         matched_at="https://example.com", tags=[]),  # +6
        ]
        mock_result = MagicMock(success=True, data=findings, error=None,
                                duration_seconds=0.1)

        with patch("plugins.scanner.nuclei_scanner.NucleiScanner.run",
                   return_value=mock_result), \
             patch("plugins.scanner.header_checker.HeaderChecker.check_all",
                   AsyncMock(return_value=[])):
            from phases.phase10_scan import run_phase10
            await run_phase10("example.com", cfg)

        data = json.loads((tmp_path / "nuclei_results.json").read_text())
        assert "phase11_score_contributions" in data
        assert data["phase11_score_contributions"].get("example.com", 0) == 16

    @pytest.mark.asyncio
    async def test_sorted_by_severity(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.nuclei_results_json = str(tmp_path / "nuclei_results.json")
        cfg.output.live_hosts_json = str(self._hosts_json(tmp_path, [
            {"url": "https://example.com", "host": "example.com"},
        ]))
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        findings = [
            NucleiFinding(host="example.com", template_id="t1",
                         name="Low", severity="low", matched_at="https://example.com", tags=[]),
            NucleiFinding(host="example.com", template_id="t2",
                         name="Critical", severity="critical", matched_at="https://example.com", tags=[]),
            NucleiFinding(host="example.com", template_id="t3",
                         name="High", severity="high", matched_at="https://example.com", tags=[]),
        ]
        mock_result = MagicMock(success=True, data=findings, error=None, duration_seconds=0.1)

        with patch("plugins.scanner.nuclei_scanner.NucleiScanner.run",
                   return_value=mock_result), \
             patch("plugins.scanner.header_checker.HeaderChecker.check_all",
                   AsyncMock(return_value=[])):
            from phases.phase10_scan import run_phase10
            results = await run_phase10("example.com", cfg)

        sev_order = [f.severity for f in results]
        rank_order = [{"critical":0,"high":1,"medium":2,"low":3,"info":4}[s] for s in sev_order]
        assert rank_order == sorted(rank_order)

    @pytest.mark.asyncio
    async def test_empty_live_hosts_returns_empty(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.nuclei_results_json = str(tmp_path / "nuclei_results.json")
        cfg.output.live_hosts_json = str(tmp_path / "live_hosts.json")
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        from phases.phase10_scan import run_phase10
        results = await run_phase10("example.com", cfg, live_hosts=[])
        assert results == []

    @pytest.mark.asyncio
    async def test_header_checker_findings_included(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.nuclei_results_json = str(tmp_path / "nuclei_results.json")
        cfg.output.live_hosts_json = str(self._hosts_json(tmp_path, [
            {"url": "https://example.com", "host": "example.com"},
        ]))
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        header_finding = NucleiFinding(
            host="example.com", template_id="missing-csp",
            name="Missing CSP", severity="high",
            matched_at="https://example.com", tags=["security-headers"],
        )
        mock_result = MagicMock(success=True, data=[], error=None, duration_seconds=0.0)

        with patch("plugins.scanner.nuclei_scanner.NucleiScanner.run",
                   return_value=mock_result), \
             patch("plugins.scanner.header_checker.HeaderChecker.check_all",
                   AsyncMock(return_value=[header_finding])):
            from phases.phase10_scan import run_phase10
            results = await run_phase10("example.com", cfg)

        assert any(f.template_id == "missing-csp" for f in results)
