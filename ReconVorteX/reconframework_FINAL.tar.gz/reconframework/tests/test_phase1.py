"""
tests/test_phase1.py
=====================
Unit tests for Phase 1 — Multi-Source Asset Discovery.

Coverage:
  • Subdomain model validation & normalisation
  • DiscoveryResult finalise() stats
  • Database upsert / bulk_upsert / get
  • CrtShPlugin (mocked HTTP)
  • AlienVaultPlugin (mocked HTTP)
  • HackerTargetPlugin (mocked HTTP)
  • Tool runner (binary missing path)
  • Phase1Discovery merge + output files
"""

from __future__ import annotations

import json
import asyncio
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import pytest_asyncio

from core.base_plugin import PluginContext, PluginResult
from core.database import Database
from core.models import DiscoveryResult, Subdomain
from plugins.subdomains.alienvault import AlienVaultPlugin
from plugins.subdomains.crtsh import CrtShPlugin
from plugins.subdomains.hackertarget import HackerTargetPlugin
from plugins.subdomains.tool_runner import SubfinderPlugin, _parse_hostnames


# ===========================================================================
# Model tests
# ===========================================================================

class TestSubdomainModel:
    def test_host_normalisation(self):
        s = Subdomain(host="  *.Example.COM  ")
        assert s.host == "example.com"

    def test_sources_deduped(self):
        s = Subdomain(host="sub.example.com", sources=["crtsh", "crtsh", "amass"])
        assert s.sources == ["amass", "crtsh"]  # sorted + deduped

    def test_add_source(self):
        s = Subdomain(host="sub.example.com", sources=["crtsh"])
        s.add_source("amass")
        s.add_source("crtsh")  # duplicate — should be ignored
        assert "amass" in s.sources
        assert s.sources.count("crtsh") == 1

    def test_wildcard_strip(self):
        s = Subdomain(host="*.test.example.com")
        assert s.host == "test.example.com"


class TestDiscoveryResult:
    def test_finalise_computes_stats(self):
        result = DiscoveryResult(domain="example.com")
        result.subdomains = [
            Subdomain(host="a.example.com"),
            Subdomain(host="b.example.com"),
        ]
        result.total_discovered = 5
        result.finalise()

        assert result.unique_discovered == 2
        assert result.finished_at is not None
        assert isinstance(result.duration_seconds, float)
        assert result.duration_seconds >= 0


# ===========================================================================
# Database tests
# ===========================================================================

class TestDatabase:
    @pytest.mark.asyncio
    async def test_upsert_and_get(self, test_db: Database):
        sub = Subdomain(host="api.example.com", sources=["crtsh"])
        await test_db.upsert_subdomain(sub, "example.com")

        rows = await test_db.get_subdomains("example.com")
        assert len(rows) == 1
        assert rows[0].host == "api.example.com"
        assert "crtsh" in rows[0].sources

    @pytest.mark.asyncio
    async def test_upsert_updates_sources(self, test_db: Database):
        sub1 = Subdomain(host="api.example.com", sources=["crtsh"])
        await test_db.upsert_subdomain(sub1, "example.com")

        sub2 = Subdomain(host="api.example.com", sources=["amass"])
        await test_db.upsert_subdomain(sub2, "example.com")

        rows = await test_db.get_subdomains("example.com")
        assert len(rows) == 1  # still one row

    @pytest.mark.asyncio
    async def test_bulk_upsert(self, test_db: Database):
        subs = [
            Subdomain(host=f"host{i}.example.com", sources=["subfinder"])
            for i in range(10)
        ]
        await test_db.bulk_upsert_subdomains(subs, "example.com")
        count = await test_db.count_subdomains("example.com")
        assert count == 10

    @pytest.mark.asyncio
    async def test_count_subdomains_empty(self, test_db: Database):
        count = await test_db.count_subdomains("nothere.com")
        assert count == 0


# ===========================================================================
# Plugin tests (mocked HTTP)
# ===========================================================================

def _make_ctx(domain: str = "example.com", config=None) -> PluginContext:
    if config is None:
        from core.config import load_config
        config = load_config("config.yaml")
    return PluginContext(domain=domain, config=config)


class TestCrtShPlugin:
    @pytest.mark.asyncio
    async def test_success(self):
        fake_data = [
            {"name_value": "api.example.com\nmail.example.com"},
            {"name_value": "*.example.com"},   # wildcard — normalised
            {"name_value": "other.com"},        # different domain — filtered
        ]
        with patch("plugins.subdomains.crtsh.fetch_json", new=AsyncMock(return_value=fake_data)):
            plugin = CrtShPlugin()
            result = await plugin.run(_make_ctx())

        assert result.success is True
        hosts = {s.host for s in result.data}
        assert "api.example.com" in hosts
        assert "mail.example.com" in hosts
        # Wildcard stripped to root — filtered (doesn't end with example.com subpath)
        assert "other.com" not in hosts

    @pytest.mark.asyncio
    async def test_http_failure(self):
        with patch("plugins.subdomains.crtsh.fetch_json", new=AsyncMock(return_value=None)):
            plugin = CrtShPlugin()
            ctx = _make_ctx()
            result = await plugin.run(ctx)

        assert result.success is False
        assert len(ctx.errors) == 1

    @pytest.mark.asyncio
    async def test_empty_response(self):
        with patch("plugins.subdomains.crtsh.fetch_json", new=AsyncMock(return_value=[])):
            plugin = CrtShPlugin()
            result = await plugin.run(_make_ctx())

        assert result.success is True
        assert result.data == []


class TestAlienVaultPlugin:
    @pytest.mark.asyncio
    async def test_success(self):
        fake_data = {
            "passive_dns": [
                {"hostname": "shop.example.com"},
                {"hostname": "cdn.example.com"},
                {"hostname": "badactor.com"},     # filtered
            ]
        }
        with patch("plugins.subdomains.alienvault.fetch_json", new=AsyncMock(return_value=fake_data)):
            plugin = AlienVaultPlugin()
            result = await plugin.run(_make_ctx())

        assert result.success is True
        hosts = {s.host for s in result.data}
        assert "shop.example.com" in hosts
        assert "cdn.example.com" in hosts
        assert "badactor.com" not in hosts

    @pytest.mark.asyncio
    async def test_none_response(self):
        with patch("plugins.subdomains.alienvault.fetch_json", new=AsyncMock(return_value=None)):
            plugin = AlienVaultPlugin()
            ctx = _make_ctx()
            result = await plugin.run(ctx)
        assert result.success is False


class TestHackerTargetPlugin:
    @pytest.mark.asyncio
    async def test_success(self):
        fake_text = "dev.example.com,1.2.3.4\nstaging.example.com,5.6.7.8\nother.org,9.9.9.9"
        with patch("plugins.subdomains.hackertarget.fetch_text", new=AsyncMock(return_value=fake_text)):
            plugin = HackerTargetPlugin()
            result = await plugin.run(_make_ctx())

        assert result.success is True
        hosts = {s.host for s in result.data}
        assert "dev.example.com" in hosts
        assert "staging.example.com" in hosts
        assert "other.org" not in hosts

    @pytest.mark.asyncio
    async def test_rate_limit(self):
        with patch(
            "plugins.subdomains.hackertarget.fetch_text",
            new=AsyncMock(return_value="API count exceeded for the day"),
        ):
            plugin = HackerTargetPlugin()
            ctx = _make_ctx()
            result = await plugin.run(ctx)
        assert result.success is False
        assert len(ctx.errors) == 1


# ===========================================================================
# Tool runner tests
# ===========================================================================

class TestToolRunner:
    def test_parse_hostnames(self):
        raw = "api.example.com\ndev.example.com\nbadsite.org\n\n"
        hosts = _parse_hostnames(raw, "example.com")
        assert "api.example.com" in hosts
        assert "dev.example.com" in hosts
        assert "badsite.org" not in hosts
        assert "" not in hosts

    def test_parse_hostnames_csv_format(self):
        raw = "api.example.com,1.1.1.1\ndev.example.com,2.2.2.2"
        hosts = _parse_hostnames(raw, "example.com")
        assert "api.example.com" in hosts
        assert "dev.example.com" in hosts

    @pytest.mark.asyncio
    async def test_missing_binary(self):
        plugin = SubfinderPlugin()
        ctx = _make_ctx()
        # Override binary to something that definitely doesn't exist
        ctx.config.phase1.subfinder_bin = "/nonexistent/subfinder_xyz"
        result = await plugin.run(ctx)
        assert result.success is False
        assert "not installed" in (result.error or "").lower() or "not found" in (result.error or "").lower()


# ===========================================================================
# Phase 1 orchestrator — integration-style (all HTTP mocked)
# ===========================================================================

from phases.phase1_discovery import Phase1Discovery


class TestPhase1Orchestrator:
    @pytest.mark.asyncio
    async def test_merge_deduplication(self, test_config, tmp_output):
        """Two plugins finding the same host should merge sources."""
        from phases.phase1_discovery import _merge_subdomains
        from core.base_plugin import PluginResult

        r1 = PluginResult(
            plugin_name="crtsh",
            success=True,
            data=[Subdomain(host="api.example.com", sources=["crtsh"])],
        )
        r2 = PluginResult(
            plugin_name="alienvault",
            success=True,
            data=[
                Subdomain(host="api.example.com", sources=["alienvault"]),
                Subdomain(host="mail.example.com", sources=["alienvault"]),
            ],
        )
        merged = _merge_subdomains([r1, r2])
        assert len(merged) == 2
        assert "crtsh" in merged["api.example.com"].sources
        assert "alienvault" in merged["api.example.com"].sources

    @pytest.mark.asyncio
    async def test_output_files_written(self, test_config, tmp_output):
        """Full phase1 run writes both output files."""
        crtsh_data = [{"name_value": "sub1.example.com\nsub2.example.com"}]
        alienvault_data = {"passive_dns": [{"hostname": "sub3.example.com"}]}
        hackertarget_data = "sub4.example.com,1.2.3.4"
        rapiddns_data = ""  # empty

        with (
            patch("plugins.subdomains.crtsh.fetch_json", new=AsyncMock(return_value=crtsh_data)),
            patch("plugins.subdomains.alienvault.fetch_json", new=AsyncMock(return_value=alienvault_data)),
            patch("plugins.subdomains.hackertarget.fetch_text", new=AsyncMock(return_value=hackertarget_data)),
            patch("plugins.subdomains.rapiddns.fetch_text", new=AsyncMock(return_value=rapiddns_data)),
            # Binary tools won't be installed in CI — mock them as missing
            patch("plugins.subdomains.tool_runner._binary_available", return_value=False),
            patch("core.http_client.close_session", new=AsyncMock()),
        ):
            phase = Phase1Discovery(test_config)
            result = await phase.run("example.com")

        # Check DiscoveryResult
        assert result.domain == "example.com"
        assert result.unique_discovered >= 3  # sub1, sub2, sub3, sub4

        # Check files
        txt = Path(test_config.output.subdomains_txt)
        assert txt.exists()
        lines = txt.read_text().strip().splitlines()
        assert len(lines) >= 3

        js = Path(test_config.output.subdomains_json)
        assert js.exists()
        data = json.loads(js.read_text())
        assert data["domain"] == "example.com"
        assert data["unique_discovered"] >= 3
        assert isinstance(data["subdomains"], list)
        assert "source_breakdown" in data
