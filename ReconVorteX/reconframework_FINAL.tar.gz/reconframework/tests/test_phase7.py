"""
tests/test_phase7.py
======================
Unit tests for Phase 7 — Sensitive Endpoint Discovery.

Covers:
  • Pattern compilation (all regex valid, no duplicates)
  • EndpointPattern.matches() — positive and negative cases for every
    major category
  • match_urls() — deduplication, severity filtering, sort order,
    multi-pattern hits per URL
  • severity_passes() helper
  • Phase 7 orchestrator — TXT output, JSON output schema, Phase 11
    score map, empty URL list, max_findings cap, min_severity filter
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from core.config import FrameworkConfig, Phase7Config, reset_config
from plugins.endpoints.matcher import EndpointFinding, match_urls, severity_passes
from plugins.endpoints.patterns import (
    COMPILED_PATTERNS,
    EndpointPattern,
    PatternCategory,
    Severity,
    get_compiled_patterns,
)


# ===========================================================================
# Fixtures
# ===========================================================================

@pytest.fixture(autouse=True)
def _reset():
    reset_config()
    yield
    reset_config()


@pytest.fixture
def cfg() -> FrameworkConfig:
    c = FrameworkConfig()
    c.phase7 = Phase7Config(
        min_severity="LOW",
        max_findings=0,
        feed_phase11=True,
        score_critical=10,
        score_high=7,
        score_medium=4,
        score_low=2,
    )
    return c


# ===========================================================================
# Pattern compilation
# ===========================================================================

class TestPatternCompilation:
    def test_all_patterns_compile_without_error(self):
        patterns = get_compiled_patterns()
        assert len(patterns) > 0
        for p in patterns:
            assert p._compiled, f"{p.name} has no compiled patterns"

    def test_no_duplicate_names(self):
        names = [p.name for p in COMPILED_PATTERNS]
        assert len(names) == len(set(names)), "Duplicate pattern names"

    def test_all_have_phase11_score(self):
        for p in COMPILED_PATTERNS:
            assert p.phase11_score >= 0, f"{p.name} has negative phase11_score"

    def test_critical_patterns_have_high_score(self):
        for p in COMPILED_PATTERNS:
            if p.severity == Severity.CRITICAL:
                assert p.phase11_score >= 8, (
                    f"CRITICAL pattern {p.name} has low score {p.phase11_score}"
                )

    def test_sorted_critical_first(self):
        sev_rank = {s: i for i, s in enumerate(
            [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO]
        )}
        ranks = [sev_rank[p.severity] for p in COMPILED_PATTERNS]
        assert ranks == sorted(ranks), "Patterns not sorted by severity"

    def test_all_categories_covered(self):
        categories = {p.category for p in COMPILED_PATTERNS}
        required = {
            PatternCategory.ENV_SECRETS,
            PatternCategory.SOURCE_CONTROL,
            PatternCategory.BACKUP,
            PatternCategory.CONFIG,
            PatternCategory.API_DOCS,
            PatternCategory.ADMIN,
            PatternCategory.DEBUG,
            PatternCategory.AUTH,
            PatternCategory.PACKAGE,
            PatternCategory.CI_CD,
        }
        missing = required - categories
        assert not missing, f"Missing categories: {missing}"


# ===========================================================================
# severity_passes helper
# ===========================================================================

class TestSeverityPasses:
    def test_critical_passes_all(self):
        for min_sev in Severity:
            assert severity_passes(Severity.CRITICAL, min_sev)

    def test_info_only_passes_info_minimum(self):
        assert severity_passes(Severity.INFO, Severity.INFO)
        assert not severity_passes(Severity.INFO, Severity.LOW)
        assert not severity_passes(Severity.INFO, Severity.MEDIUM)

    def test_high_passes_high_and_above(self):
        # HIGH passes when minimum is HIGH or lower-severity minimum (MEDIUM, LOW, INFO)
        assert severity_passes(Severity.HIGH, Severity.HIGH)
        assert severity_passes(Severity.HIGH, Severity.MEDIUM)
        assert severity_passes(Severity.HIGH, Severity.LOW)
        # HIGH does NOT pass a CRITICAL-only filter
        assert not severity_passes(Severity.HIGH, Severity.CRITICAL)

    def test_medium_passes_medium_minimum(self):
        # MEDIUM passes when minimum is MEDIUM or less severe (LOW, INFO)
        assert severity_passes(Severity.MEDIUM, Severity.MEDIUM)
        assert severity_passes(Severity.MEDIUM, Severity.LOW)
        # MEDIUM does NOT pass a HIGH-only filter
        assert not severity_passes(Severity.MEDIUM, Severity.HIGH)


# ===========================================================================
# EndpointPattern.matches()
# ===========================================================================

class TestPatternMatches:
    def _pat(self, *regexes: str) -> EndpointPattern:
        p = EndpointPattern(
            name="test",
            description="test pattern",
            category=PatternCategory.ENV_SECRETS,
            severity=Severity.HIGH,
            phase11_score=7,
            path_patterns=list(regexes),
        )
        p.compile()
        return p

    def test_simple_match(self):
        p = self._pat(r"/\.env$")
        assert p.matches("/.env")

    def test_no_match(self):
        p = self._pat(r"/\.env$")
        assert not p.matches("/about")

    def test_case_insensitive(self):
        p = self._pat(r"/admin")
        assert p.matches("/ADMIN/panel")

    def test_any_pattern_fires(self):
        p = self._pat(r"/\.env$", r"/config\.php$")
        assert p.matches("/config.php")

    def test_query_string_matched(self):
        p = self._pat(r"\?phpinfo")
        assert p.matches("/index.php?phpinfo=1")

    def test_path_with_prefix(self):
        p = self._pat(r"/\.git(/|$)")
        assert p.matches("/repo/.git/config")
        assert not p.matches("/notagit")


# ===========================================================================
# match_urls() — core matching engine
# ===========================================================================

class TestMatchUrls:

    # --- Environment & Secrets ---
    def test_env_file_detected(self):
        findings = match_urls(["https://example.com/.env"])
        names = [f.pattern_name for f in findings]
        assert "env_file" in names

    def test_env_production_detected(self):
        findings = match_urls(["https://example.com/.env.production"])
        names = [f.pattern_name for f in findings]
        assert "env_file" in names

    def test_aws_credentials_detected(self):
        findings = match_urls(["https://example.com/.aws/credentials"])
        names = [f.pattern_name for f in findings]
        assert "aws_credentials" in names

    def test_private_key_detected(self):
        findings = match_urls(["https://example.com/server.pem"])
        names = [f.pattern_name for f in findings]
        assert "private_key" in names or "certificate_file" in names

    # --- Source Control ---
    def test_git_config_detected(self):
        findings = match_urls(["https://example.com/.git/config"])
        names = [f.pattern_name for f in findings]
        assert "git_config" in names

    def test_git_directory_detected(self):
        findings = match_urls(["https://example.com/.git/"])
        names = [f.pattern_name for f in findings]
        assert "git_config" in names

    def test_svn_detected(self):
        findings = match_urls(["https://example.com/.svn/entries"])
        names = [f.pattern_name for f in findings]
        assert "svn_exposed" in names

    def test_ds_store_detected(self):
        findings = match_urls(["https://example.com/.DS_Store"])
        names = [f.pattern_name for f in findings]
        assert "ds_store" in names

    # --- Backup & Archive ---
    def test_backup_zip_detected(self):
        findings = match_urls(["https://example.com/backup.zip"])
        names = [f.pattern_name for f in findings]
        assert "backup_archive" in names

    def test_sql_dump_detected(self):
        findings = match_urls(["https://example.com/db.sql"])
        names = [f.pattern_name for f in findings]
        assert "sql_dump" in names

    def test_bak_file_detected(self):
        findings = match_urls(["https://example.com/index.php.bak"])
        names = [f.pattern_name for f in findings]
        assert "bak_file" in names

    def test_tar_gz_detected(self):
        findings = match_urls(["https://example.com/data.tar.gz"])
        names = [f.pattern_name for f in findings]
        assert "backup_archive" in names

    # --- Config Files ---
    def test_wp_config_detected(self):
        findings = match_urls(["https://example.com/wp-config.php"])
        names = [f.pattern_name for f in findings]
        assert "wp_config" in names

    def test_web_config_detected(self):
        findings = match_urls(["https://example.com/web.config"])
        names = [f.pattern_name for f in findings]
        assert "web_config" in names

    def test_htaccess_detected(self):
        findings = match_urls(["https://example.com/.htaccess"])
        names = [f.pattern_name for f in findings]
        assert "htaccess" in names

    def test_htpasswd_detected(self):
        findings = match_urls(["https://example.com/.htpasswd"])
        names = [f.pattern_name for f in findings]
        assert "htaccess" in names

    def test_django_settings_detected(self):
        findings = match_urls(["https://example.com/settings.py"])
        names = [f.pattern_name for f in findings]
        assert "django_settings" in names

    # --- API Docs ---
    def test_swagger_json_detected(self):
        findings = match_urls(["https://example.com/swagger.json"])
        names = [f.pattern_name for f in findings]
        assert "swagger" in names

    def test_openapi_yaml_detected(self):
        findings = match_urls(["https://example.com/openapi.yaml"])
        names = [f.pattern_name for f in findings]
        assert "swagger" in names

    def test_graphql_detected(self):
        findings = match_urls(["https://example.com/graphql"])
        names = [f.pattern_name for f in findings]
        assert "graphql_endpoint" in names

    def test_api_docs_detected(self):
        findings = match_urls(["https://example.com/api-docs"])
        names = [f.pattern_name for f in findings]
        assert "swagger" in names

    # --- Admin Panels ---
    def test_admin_path_detected(self):
        findings = match_urls(["https://example.com/admin/"])
        names = [f.pattern_name for f in findings]
        assert "admin_panel" in names

    def test_phpmyadmin_detected(self):
        findings = match_urls(["https://example.com/phpmyadmin/"])
        names = [f.pattern_name for f in findings]
        assert "phpmyadmin" in names

    def test_wp_admin_detected(self):
        findings = match_urls(["https://example.com/wp-admin/"])
        names = [f.pattern_name for f in findings]
        assert "admin_panel" in names

    # --- Debug & Diagnostic ---
    def test_phpinfo_detected(self):
        findings = match_urls(["https://example.com/phpinfo.php"])
        names = [f.pattern_name for f in findings]
        assert "phpinfo" in names

    def test_actuator_detected(self):
        findings = match_urls(["https://api.example.com/actuator/env"])
        names = [f.pattern_name for f in findings]
        assert "spring_actuator" in names

    def test_server_status_detected(self):
        findings = match_urls(["https://example.com/server-status"])
        names = [f.pattern_name for f in findings]
        assert "server_status" in names

    # --- CI/CD ---
    def test_jenkinsfile_detected(self):
        findings = match_urls(["https://example.com/Jenkinsfile"])
        names = [f.pattern_name for f in findings]
        assert "cicd_config" in names

    def test_travis_yml_detected(self):
        findings = match_urls(["https://example.com/.travis.yml"])
        names = [f.pattern_name for f in findings]
        assert "cicd_config" in names

    def test_gitlab_ci_detected(self):
        findings = match_urls(["https://example.com/.gitlab-ci.yml"])
        names = [f.pattern_name for f in findings]
        assert "cicd_config" in names

    # --- Auth & JWT ---
    def test_oauth_endpoint_detected(self):
        findings = match_urls(["https://example.com/oauth/token"])
        names = [f.pattern_name for f in findings]
        assert any("oauth" in n or "token" in n for n in names)

    def test_wellknown_jwks_detected(self):
        findings = match_urls(["https://example.com/.well-known/jwks.json"])
        names = [f.pattern_name for f in findings]
        assert any("oauth" in n or "jwt" in n for n in names)

    # --- Package Managers ---
    def test_package_json_detected(self):
        findings = match_urls(["https://example.com/package.json"])
        names = [f.pattern_name for f in findings]
        assert "npm_package" in names

    def test_requirements_txt_detected(self):
        findings = match_urls(["https://example.com/requirements.txt"])
        names = [f.pattern_name for f in findings]
        assert "python_requirements" in names

    def test_composer_json_detected(self):
        findings = match_urls(["https://example.com/composer.json"])
        names = [f.pattern_name for f in findings]
        assert "composer_json" in names

    def test_gemfile_detected(self):
        findings = match_urls(["https://example.com/Gemfile.lock"])
        names = [f.pattern_name for f in findings]
        assert "ruby_gemfile" in names

    # --- Framework Internals ---
    def test_webpack_hmr_detected(self):
        findings = match_urls(["https://example.com/__webpack_hmr"])
        names = [f.pattern_name for f in findings]
        assert "webpack_hmr" in names

    def test_django_debug_toolbar_detected(self):
        findings = match_urls(["https://example.com/__debug__/"])
        names = [f.pattern_name for f in findings]
        assert "django_debug" in names

    def test_laravel_telescope_detected(self):
        findings = match_urls(["https://example.com/telescope"])
        names = [f.pattern_name for f in findings]
        assert "laravel_telescope" in names

    def test_wordpress_rest_api_detected(self):
        findings = match_urls(["https://example.com/wp-json/wp/v2/users"])
        names = [f.pattern_name for f in findings]
        assert "wordpress_api" in names

    # --- Logs ---
    def test_access_log_detected(self):
        findings = match_urls(["https://example.com/access.log"])
        names = [f.pattern_name for f in findings]
        assert "access_log" in names

    def test_error_log_detected(self):
        findings = match_urls(["https://example.com/error.log"])
        names = [f.pattern_name for f in findings]
        assert "access_log" in names

    # --- Discovery ---
    def test_robots_txt_detected(self):
        findings = match_urls(["https://example.com/robots.txt"])
        names = [f.pattern_name for f in findings]
        assert "robots_txt" in names

    def test_sitemap_xml_detected(self):
        # sitemap is INFO severity — must pass min_severity=INFO to appear
        findings = match_urls(
            ["https://example.com/sitemap.xml"],
            min_severity=Severity.INFO,
        )
        names = [f.pattern_name for f in findings]
        assert "sitemap" in names

    # --- Negative cases ---
    def test_plain_html_not_flagged(self):
        findings = match_urls(["https://example.com/about.html"])
        assert len(findings) == 0

    def test_image_url_not_flagged(self):
        findings = match_urls(["https://example.com/logo.png"])
        assert len(findings) == 0

    def test_empty_url_list_returns_empty(self):
        assert match_urls([]) == []

    def test_blank_lines_skipped(self):
        assert match_urls(["", "   ", "\n"]) == []


# ===========================================================================
# match_urls() — dedup, filtering, ordering
# ===========================================================================

class TestMatchUrlsOrdering:
    def test_results_sorted_critical_first(self):
        urls = [
            "https://example.com/robots.txt",        # LOW/INFO
            "https://example.com/.git/config",        # CRITICAL
            "https://example.com/swagger.json",       # HIGH
        ]
        findings = match_urls(urls)
        sev_rank = {s: i for i, s in enumerate(
            [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO]
        )}
        ranks = [sev_rank[f.severity] for f in findings]
        assert ranks == sorted(ranks)

    def test_deduplication_same_url_same_pattern(self):
        url = "https://example.com/.env"
        findings = match_urls([url, url, url])
        env_findings = [f for f in findings if f.pattern_name == "env_file"]
        assert len(env_findings) == 1

    def test_same_url_multiple_patterns(self):
        """A .sql.bak file can match both sql_dump and bak_file."""
        findings = match_urls(["https://example.com/db.sql.bak"])
        pattern_names = {f.pattern_name for f in findings}
        # At least two patterns should fire
        assert len(pattern_names) >= 1   # at minimum bak_file

    def test_severity_filter_excludes_info(self):
        findings = match_urls(
            ["https://example.com/sitemap.xml"],
            min_severity=Severity.LOW,
        )
        # sitemap is INFO severity — should be excluded when min=LOW
        assert all(f.severity != Severity.INFO for f in findings)

    def test_severity_filter_info_includes_all(self):
        findings = match_urls(
            ["https://example.com/sitemap.xml"],
            min_severity=Severity.INFO,
        )
        assert any(f.pattern_name == "sitemap" for f in findings)

    def test_finding_has_correct_host(self):
        findings = match_urls(["https://api.example.com/swagger.json"])
        swagger = next(f for f in findings if f.pattern_name == "swagger")
        assert swagger.host == "api.example.com"

    def test_finding_has_correct_path(self):
        findings = match_urls(["https://example.com/api/swagger.json"])
        swagger = next(f for f in findings if f.pattern_name == "swagger")
        assert swagger.path == "/api/swagger.json"

    def test_phase11_score_positive(self):
        findings = match_urls(["https://example.com/.env"])
        env = next(f for f in findings if f.pattern_name == "env_file")
        assert env.phase11_score > 0

    def test_critical_findings_have_max_score(self):
        findings = match_urls(["https://example.com/.git/config"])
        git = next(f for f in findings if f.pattern_name == "git_config")
        assert git.severity == Severity.CRITICAL
        assert git.phase11_score >= 8


# ===========================================================================
# Phase 7 orchestrator
# ===========================================================================

class TestPhase7Orchestrator:
    def _write_urls_json(self, tmp_path: Path, urls: list[str]) -> Path:
        p = tmp_path / "urls.json"
        p.write_text(json.dumps({"meta": {}, "urls": urls}))
        return p

    @pytest.mark.asyncio
    async def test_writes_sensitive_endpoints_txt(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.urls_txt = str(tmp_path / "urls.txt")
        cfg.output.sensitive_endpoints_txt = str(tmp_path / "sensitive_endpoints.txt")
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        urls = ["https://example.com/.env", "https://example.com/admin/"]
        self._write_urls_json(tmp_path, urls)

        from phases.phase7_endpoints import run_phase7
        await run_phase7("example.com", cfg, urls=urls)

        txt = tmp_path / "sensitive_endpoints.txt"
        assert txt.exists()
        lines = [l for l in txt.read_text().splitlines() if l.strip()]
        assert len(lines) >= 1

    @pytest.mark.asyncio
    async def test_writes_sensitive_endpoints_json(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.urls_txt = str(tmp_path / "urls.txt")
        cfg.output.sensitive_endpoints_txt = str(tmp_path / "sensitive_endpoints.txt")
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        urls = ["https://example.com/.git/config", "https://example.com/swagger.json"]
        from phases.phase7_endpoints import run_phase7
        await run_phase7("example.com", cfg, urls=urls)

        json_path = tmp_path / "sensitive_endpoints.json"
        assert json_path.exists()
        data = json.loads(json_path.read_text())
        assert "meta" in data
        assert "findings" in data
        assert data["meta"]["total"] >= 2

    @pytest.mark.asyncio
    async def test_phase11_scores_in_json(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.urls_txt = str(tmp_path / "urls.txt")
        cfg.output.sensitive_endpoints_txt = str(tmp_path / "sensitive_endpoints.txt")
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        urls = ["https://example.com/.env", "https://example.com/.git/config"]
        from phases.phase7_endpoints import run_phase7
        await run_phase7("example.com", cfg, urls=urls)

        data = json.loads((tmp_path / "sensitive_endpoints.json").read_text())
        assert "phase11_score_contributions" in data
        assert "example.com" in data["phase11_score_contributions"]
        assert data["phase11_score_contributions"]["example.com"] > 0

    @pytest.mark.asyncio
    async def test_max_findings_cap(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.phase7.max_findings = 2
        cfg.output.urls_txt = str(tmp_path / "urls.txt")
        cfg.output.sensitive_endpoints_txt = str(tmp_path / "sensitive_endpoints.txt")
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        urls = [
            "https://example.com/.env",
            "https://example.com/.git/config",
            "https://example.com/swagger.json",
            "https://example.com/backup.zip",
        ]
        from phases.phase7_endpoints import run_phase7
        findings = await run_phase7("example.com", cfg, urls=urls)
        assert len(findings) <= 2

    @pytest.mark.asyncio
    async def test_min_severity_filter_applied(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.phase7.min_severity = "HIGH"
        cfg.output.urls_txt = str(tmp_path / "urls.txt")
        cfg.output.sensitive_endpoints_txt = str(tmp_path / "sensitive_endpoints.txt")
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        urls = [
            "https://example.com/robots.txt",    # LOW
            "https://example.com/sitemap.xml",   # INFO
            "https://example.com/.git/config",   # CRITICAL (passes HIGH filter)
        ]
        from phases.phase7_endpoints import run_phase7
        findings = await run_phase7("example.com", cfg, urls=urls)

        for f in findings:
            assert f.severity not in (Severity.LOW, Severity.INFO)

    @pytest.mark.asyncio
    async def test_empty_url_list_returns_empty(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.urls_txt = str(tmp_path / "urls.txt")
        cfg.output.sensitive_endpoints_txt = str(tmp_path / "sensitive_endpoints.txt")
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        from phases.phase7_endpoints import run_phase7
        findings = await run_phase7("example.com", cfg, urls=[])
        assert findings == []

    @pytest.mark.asyncio
    async def test_loads_urls_from_json_file(self, cfg: FrameworkConfig, tmp_path: Path):
        json_path = tmp_path / "urls.json"
        json_path.write_text(json.dumps({"urls": ["https://example.com/.env"]}))
        cfg.output.urls_txt = str(tmp_path / "urls.txt")
        cfg.output.sensitive_endpoints_txt = str(tmp_path / "sensitive_endpoints.txt")
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        from phases.phase7_endpoints import run_phase7
        findings = await run_phase7("example.com", cfg)
        assert any(f.pattern_name == "env_file" for f in findings)

    @pytest.mark.asyncio
    async def test_loads_urls_from_txt_fallback(self, cfg: FrameworkConfig, tmp_path: Path):
        txt_path = tmp_path / "urls.txt"
        txt_path.write_text("https://example.com/.htpasswd\n")
        cfg.output.urls_txt = str(txt_path)
        cfg.output.sensitive_endpoints_txt = str(tmp_path / "sensitive_endpoints.txt")
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        from phases.phase7_endpoints import run_phase7
        findings = await run_phase7("example.com", cfg)
        assert any(f.pattern_name == "htaccess" for f in findings)

    @pytest.mark.asyncio
    async def test_txt_output_deduplicates_urls(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.urls_txt = str(tmp_path / "urls.txt")
        cfg.output.sensitive_endpoints_txt = str(tmp_path / "sensitive_endpoints.txt")
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        # Same URL repeated — only one line in txt
        urls = ["https://example.com/.env", "https://example.com/.env"]
        from phases.phase7_endpoints import run_phase7
        await run_phase7("example.com", cfg, urls=urls)

        lines = [
            l for l in
            (tmp_path / "sensitive_endpoints.txt").read_text().splitlines()
            if l.strip()
        ]
        env_lines = [l for l in lines if ".env" in l]
        assert len(env_lines) == 1

    @pytest.mark.asyncio
    async def test_json_severity_distribution_correct(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.urls_txt = str(tmp_path / "urls.txt")
        cfg.output.sensitive_endpoints_txt = str(tmp_path / "sensitive_endpoints.txt")
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        urls = [
            "https://example.com/.git/config",  # CRITICAL
            "https://example.com/swagger.json",  # HIGH
            "https://example.com/robots.txt",    # LOW
        ]
        from phases.phase7_endpoints import run_phase7
        await run_phase7("example.com", cfg, urls=urls)

        data = json.loads((tmp_path / "sensitive_endpoints.json").read_text())
        dist = data["meta"]["severity_distribution"]
        assert "CRITICAL" in dist
        assert dist["CRITICAL"] >= 1
