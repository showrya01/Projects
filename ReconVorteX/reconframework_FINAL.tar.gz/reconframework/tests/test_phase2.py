"""
tests/test_phase2.py
=====================
Unit tests for Phase 2 — Live Host Discovery.

Covers:
  • HttpxBinaryProber  — stdout parsing, no-binary fallback signal
  • AiohttpProber      — redirect chain tracking, title extraction,
                         status filtering, concurrency, error handling
  • phase2_live_hosts  — strategy selection (binary vs fallback),
                         JSON output, DB persistence
  • _extract_title     — HTML edge cases
  • _parse_response_time
"""

from __future__ import annotations

import asyncio
import json
import shutil
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from core.base_plugin import PluginContext
from core.config import FrameworkConfig, Phase2Config, reset_config
from core.models import LiveHost
from plugins.live_hosts.aiohttp_prober import AiohttpProber, _extract_title
from plugins.live_hosts.httpx_prober import HttpxBinaryProber, _parse_line, _parse_response_time


# ===========================================================================
# Fixtures
# ===========================================================================

@pytest.fixture(autouse=True)
def _reset_config():
    reset_config()
    yield
    reset_config()


@pytest.fixture
def cfg() -> FrameworkConfig:
    c = FrameworkConfig()
    c.phase2 = Phase2Config(
        concurrency=5,
        timeout_s=5,
        max_redirects=5,
        probe_http=True,
        probe_https=True,
        live_status_codes=[200, 301, 302, 403, 404, 500],
        retry_attempts=1,
        retry_wait_min=0.0,
        retry_wait_max=0.0,
    )
    return c


@pytest.fixture
def ctx(cfg: FrameworkConfig) -> PluginContext:
    context = PluginContext(domain="example.com", config=cfg)
    context.metadata["subdomains"] = ["sub1.example.com", "sub2.example.com"]
    return context


# ===========================================================================
# _parse_response_time
# ===========================================================================

class TestParseResponseTime:
    def test_milliseconds(self):
        assert _parse_response_time("342ms") == 342.0

    def test_seconds_converted(self):
        assert _parse_response_time("1.5s") == 1500.0

    def test_none_input(self):
        assert _parse_response_time(None) is None

    def test_empty_string(self):
        assert _parse_response_time("") is None

    def test_no_numeric(self):
        assert _parse_response_time("fast") is None

    def test_decimal_ms(self):
        assert _parse_response_time("12.7ms") == 12.7


# ===========================================================================
# _parse_line (httpx JSON line parser)
# ===========================================================================

class TestParseHttpxLine:
    LIVE_CODES = {200, 301, 302, 403, 404, 500}

    def _line(self, **kwargs) -> str:
        defaults = {
            "url": "https://sub.example.com",
            "host": "sub.example.com",
            "status-code": 200,
            "title": "Test Page",
            "webserver": "nginx/1.18.0",
            "content-length": 1234,
            "ip": "1.2.3.4",
            "tech": ["Bootstrap:4.3.1"],
            "response-time": "220ms",
            "redirect-chain": [],
        }
        defaults.update(kwargs)
        return json.dumps(defaults)

    def test_parses_valid_line(self):
        host = _parse_line(self._line(), self.LIVE_CODES)
        assert host is not None
        assert host.url == "https://sub.example.com"
        assert host.status_code == 200
        assert host.title == "Test Page"
        assert host.web_server == "nginx/1.18.0"
        assert host.ip_address == "1.2.3.4"
        assert host.content_length == 1234
        assert host.response_time_ms == 220.0

    def test_strips_tech_version(self):
        host = _parse_line(self._line(tech=["Bootstrap:4.3.1", "jQuery:3.4.1"]), self.LIVE_CODES)
        assert host is not None
        assert "Bootstrap" in host.technologies
        assert "jQuery" in host.technologies
        # Version strings stripped
        assert "Bootstrap:4.3.1" not in host.technologies

    def test_skips_non_live_status(self):
        host = _parse_line(self._line(**{"status-code": 204}), self.LIVE_CODES)
        assert host is None

    def test_skips_invalid_json(self):
        assert _parse_line("not json at all", self.LIVE_CODES) is None

    def test_skips_empty_line(self):
        assert _parse_line("", self.LIVE_CODES) is None

    def test_redirect_chain_captured(self):
        host = _parse_line(
            self._line(**{"redirect-chain": ["http://sub.example.com"], "status-code": 301}),
            self.LIVE_CODES,
        )
        assert host is not None
        assert "http://sub.example.com" in host.redirect_chain

    def test_missing_tech_field(self):
        line = json.dumps({"url": "https://x.com", "host": "x.com", "status-code": 200})
        host = _parse_line(line, self.LIVE_CODES)
        assert host is not None
        assert host.technologies == []


# ===========================================================================
# _extract_title
# ===========================================================================

class TestExtractTitle:
    def test_basic_title(self):
        html = b"<html><head><title>Hello World</title></head></html>"
        assert _extract_title(html) == "Hello World"

    def test_case_insensitive(self):
        html = b"<TITLE>CAPS TITLE</TITLE>"
        assert _extract_title(html) == "CAPS TITLE"

    def test_whitespace_collapsed(self):
        html = b"<title>  \n  Multiple   Spaces  \n</title>"
        assert _extract_title(html) == "Multiple Spaces"

    def test_no_title(self):
        assert _extract_title(b"<html><body>no title</body></html>") is None

    def test_empty_title(self):
        assert _extract_title(b"<title>   </title>") is None

    def test_title_with_attributes(self):
        html = b'<title lang="en">My Page</title>'
        assert _extract_title(html) == "My Page"

    def test_truncated_at_256_chars(self):
        long_title = "A" * 300
        html = f"<title>{long_title}</title>".encode()
        result = _extract_title(html)
        assert result is not None
        assert len(result) == 256

    def test_empty_body(self):
        assert _extract_title(b"") is None


# ===========================================================================
# HttpxBinaryProber
# ===========================================================================

class TestHttpxBinaryProber:
    @pytest.mark.asyncio
    async def test_returns_fail_when_binary_missing(self, ctx: PluginContext):
        ctx.config.phase2.httpx_bin = "/nonexistent/httpx"
        prober = HttpxBinaryProber()
        result = await prober.execute(ctx)
        assert not result.success
        assert "not found" in (result.error or "").lower()

    @pytest.mark.asyncio
    async def test_returns_fail_when_no_subdomains(self, ctx: PluginContext, cfg: FrameworkConfig):
        ctx.metadata["subdomains"] = []
        with patch("shutil.which", return_value="/usr/bin/httpx"):
            prober = HttpxBinaryProber()
            result = await prober.execute(ctx)
        assert not result.success
        assert "No subdomains" in (result.error or "")

    @pytest.mark.asyncio
    async def test_parses_httpx_stdout(self, ctx: PluginContext):
        """Mock subprocess to feed known JSON lines through the parser."""
        fake_stdout = "\n".join([
            json.dumps({
                "url": "https://sub1.example.com",
                "host": "sub1.example.com",
                "status-code": 200,
                "title": "Sub1",
                "webserver": "Apache",
                "content-length": 500,
                "ip": "10.0.0.1",
                "tech": ["WordPress:6.1"],
                "response-time": "150ms",
                "redirect-chain": [],
            }),
            json.dumps({
                "url": "https://sub2.example.com",
                "host": "sub2.example.com",
                "status-code": 403,
                "title": "Forbidden",
                "webserver": "nginx",
                "content-length": 162,
                "ip": "10.0.0.2",
                "tech": [],
                "response-time": "80ms",
                "redirect-chain": [],
            }),
            # This line should be skipped (status 204 not in live_codes fixture)
            json.dumps({
                "url": "https://dead.example.com",
                "host": "dead.example.com",
                "status-code": 204,
            }),
        ]).encode()

        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(fake_stdout, b""))

        with patch("shutil.which", return_value="/usr/bin/httpx"), \
             patch("asyncio.create_subprocess_exec", return_value=mock_proc), \
             patch("pathlib.Path.unlink"):
            prober = HttpxBinaryProber()
            result = await prober.execute(ctx)

        assert result.success
        assert result.data is not None
        # 204 is not in live_codes fixture, so only 2 hosts returned
        assert len(result.data) == 2
        urls = {h.url for h in result.data}
        assert "https://sub1.example.com" in urls
        assert "https://sub2.example.com" in urls

    @pytest.mark.asyncio
    async def test_handles_empty_stdout(self, ctx: PluginContext):
        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(b"", b""))

        with patch("shutil.which", return_value="/usr/bin/httpx"), \
             patch("asyncio.create_subprocess_exec", return_value=mock_proc), \
             patch("pathlib.Path.unlink"):
            result = await HttpxBinaryProber().execute(ctx)

        assert result.success
        assert result.data == []

    @pytest.mark.asyncio
    async def test_handles_corrupt_json_lines(self, ctx: PluginContext):
        """Garbage lines in stdout should be silently skipped."""
        fake_stdout = b"not json\nalso not json\n{broken\n"
        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(fake_stdout, b""))

        with patch("shutil.which", return_value="/usr/bin/httpx"), \
             patch("asyncio.create_subprocess_exec", return_value=mock_proc), \
             patch("pathlib.Path.unlink"):
            result = await HttpxBinaryProber().execute(ctx)

        assert result.success
        assert result.data == []


# ===========================================================================
# AiohttpProber
# ===========================================================================

def _make_mock_response(
    status: int,
    body: bytes = b"<title>Test</title>",
    headers: dict | None = None,
    url: str = "https://sub1.example.com",
) -> MagicMock:
    """Build a minimal aiohttp.ClientResponse mock."""
    resp = MagicMock()
    resp.status = status
    resp.url = MagicMock()
    resp.url.__str__ = MagicMock(return_value=url)
    resp.headers = headers or {"Server": "nginx/1.18", "Content-Length": str(len(body))}
    resp.content = MagicMock()
    resp.content.read = AsyncMock(return_value=body)
    return resp


class TestAiohttpProber:
    @pytest.mark.asyncio
    async def test_returns_fail_when_no_subdomains(self, ctx: PluginContext):
        ctx.metadata["subdomains"] = []
        result = await AiohttpProber().execute(ctx)
        assert not result.success
        assert "No subdomains" in (result.error or "")

    @pytest.mark.asyncio
    async def test_live_host_200(self, ctx: PluginContext):
        """Happy path: 200 response with title extraction."""
        resp = _make_mock_response(
            200,
            body=b"<html><title>Hello</title></html>",
            headers={"Server": "Apache/2.4", "Content-Length": "33"},
            url="https://sub1.example.com",
        )
        cm = MagicMock()
        cm.__aenter__ = AsyncMock(return_value=resp)
        cm.__aexit__ = AsyncMock(return_value=False)

        with patch("aiohttp.ClientSession.get", return_value=cm), \
             patch("asyncio.get_event_loop") as mock_loop:
            mock_loop.return_value.run_in_executor = AsyncMock(return_value="1.2.3.4")
            result = await AiohttpProber().execute(ctx)

        assert result.success
        assert result.data is not None
        live = [h for h in result.data if h is not None]
        assert len(live) >= 1
        assert live[0].title == "Hello"
        assert live[0].web_server == "Apache/2.4"
        assert live[0].status_code == 200

    @pytest.mark.asyncio
    async def test_status_not_in_live_codes_is_discarded(self, ctx: PluginContext):
        """Status 204 is not in fixture live_codes — host should be discarded."""
        resp = _make_mock_response(204, url="https://sub1.example.com")
        cm = MagicMock()
        cm.__aenter__ = AsyncMock(return_value=resp)
        cm.__aexit__ = AsyncMock(return_value=False)

        with patch("aiohttp.ClientSession.get", return_value=cm), \
             patch("asyncio.get_event_loop") as mock_loop:
            mock_loop.return_value.run_in_executor = AsyncMock(return_value=None)
            result = await AiohttpProber().execute(ctx)

        assert result.success
        assert result.data == []

    @pytest.mark.asyncio
    async def test_redirect_chain_recorded(self, ctx: PluginContext):
        """301 → 200 redirect should record intermediate URL in chain."""
        redirect_resp = MagicMock()
        redirect_resp.status = 301
        redirect_resp.url = MagicMock()
        redirect_resp.url.__str__ = MagicMock(return_value="http://sub1.example.com")
        redirect_resp.headers = {"Location": "https://sub1.example.com", "Server": "nginx"}
        redirect_resp.content = MagicMock()
        redirect_resp.content.read = AsyncMock(return_value=b"")

        final_resp = MagicMock()
        final_resp.status = 200
        final_resp.url = MagicMock()
        final_resp.url.__str__ = MagicMock(return_value="https://sub1.example.com")
        final_resp.headers = {"Server": "nginx", "Content-Length": "50"}
        final_resp.content = MagicMock()
        final_resp.content.read = AsyncMock(return_value=b"<title>Secure</title>")

        call_count = 0

        def make_cm(*args, **kwargs):
            nonlocal call_count
            cm = MagicMock()
            if call_count == 0:
                cm.__aenter__ = AsyncMock(return_value=redirect_resp)
            else:
                cm.__aenter__ = AsyncMock(return_value=final_resp)
            cm.__aexit__ = AsyncMock(return_value=False)
            call_count += 1
            return cm

        with patch("aiohttp.ClientSession.get", side_effect=make_cm), \
             patch("asyncio.get_event_loop") as mock_loop:
            mock_loop.return_value.run_in_executor = AsyncMock(return_value="1.2.3.4")
            result = await AiohttpProber().execute(ctx)

        assert result.success
        live = [h for h in (result.data or []) if h is not None]
        hosts_with_redirects = [h for h in live if h.redirect_chain]
        assert any(h.title == "Secure" for h in live)
        assert any(len(h.redirect_chain) > 0 for h in live)

    @pytest.mark.asyncio
    async def test_connection_error_returns_empty(self, ctx: PluginContext):
        """Network errors should not crash — just return empty list."""
        import aiohttp as _aiohttp
        with patch(
            "aiohttp.ClientSession.get",
            side_effect=_aiohttp.ClientConnectorError(
                MagicMock(), OSError("connection refused")
            ),
        ):
            result = await AiohttpProber().execute(ctx)

        assert result.success
        assert result.data == []

    @pytest.mark.asyncio
    async def test_timeout_returns_empty(self, ctx: PluginContext):
        with patch("aiohttp.ClientSession.get", side_effect=asyncio.TimeoutError()):
            result = await AiohttpProber().execute(ctx)

        assert result.success
        assert result.data == []


# ===========================================================================
# Phase 2 orchestrator integration
# ===========================================================================

class TestPhase2Orchestrator:
    """Integration-level tests that exercise run_phase2() with mocked probers."""

    def _make_live_host(self, host: str, status: int = 200) -> LiveHost:
        return LiveHost(
            url=f"https://{host}",
            host=host,
            status_code=status,
            title=f"Title of {host}",
            web_server="nginx",
            ip_address="1.2.3.4",
        )

    @pytest.mark.asyncio
    async def test_uses_binary_when_available(self, cfg: FrameworkConfig, tmp_path: Path):
        """When httpx binary is found, PREFERRED prober should be called."""
        cfg.output.base_dir = str(tmp_path)
        cfg.output.subdomains_json = str(tmp_path / "subdomains.json")
        cfg.output.live_hosts_json = str(tmp_path / "live_hosts.json")
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        fake_hosts = [self._make_live_host("sub1.example.com")]
        mock_result = MagicMock(success=True, data=fake_hosts, error=None)

        with patch("shutil.which", return_value="/usr/bin/httpx"), \
             patch(
                 "phases.phase2_live_hosts.PREFERRED",
                 return_value=MagicMock(execute=AsyncMock(return_value=mock_result)),
             ):
            from phases.phase2_live_hosts import run_phase2
            hosts = await run_phase2(
                "example.com",
                cfg,
                subdomains=["sub1.example.com"],
            )

        assert len(hosts) == 1
        assert hosts[0].host == "sub1.example.com"

    @pytest.mark.asyncio
    async def test_falls_back_to_aiohttp_when_no_binary(self, cfg: FrameworkConfig, tmp_path: Path):
        """When binary missing → _probe_with_strategy should use FALLBACK prober."""
        cfg.output.live_hosts_json = str(tmp_path / "live_hosts.json")
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        fake_hosts = [self._make_live_host("sub2.example.com", 403)]
        mock_result = MagicMock(success=True, data=fake_hosts, error=None)
        mock_fallback_instance = MagicMock(execute=AsyncMock(return_value=mock_result))

        import phases.phase2_live_hosts as p2mod

        # Patch at the module level so the already-imported run_phase2 sees the mock
        with patch("shutil.which", return_value=None), \
             patch.object(p2mod, "FALLBACK", return_value=mock_fallback_instance):
            hosts = await p2mod.run_phase2(
                "example.com",
                cfg,
                subdomains=["sub2.example.com"],
            )

        assert len(hosts) == 1
        assert hosts[0].status_code == 403

    @pytest.mark.asyncio
    async def test_writes_json_output(self, cfg: FrameworkConfig, tmp_path: Path):
        """live_hosts.json must be written with correct structure."""
        out_file = tmp_path / "live_hosts.json"
        cfg.output.live_hosts_json = str(out_file)
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        fake_hosts = [
            self._make_live_host("sub1.example.com"),
            self._make_live_host("sub2.example.com", 404),
        ]
        mock_result = MagicMock(success=True, data=fake_hosts, error=None)

        with patch("shutil.which", return_value="/usr/bin/httpx"), \
             patch(
                 "phases.phase2_live_hosts.PREFERRED",
                 return_value=MagicMock(execute=AsyncMock(return_value=mock_result)),
             ):
            from phases.phase2_live_hosts import run_phase2
            await run_phase2("example.com", cfg, subdomains=["sub1.example.com", "sub2.example.com"])

        assert out_file.exists()
        data = json.loads(out_file.read_text())
        assert "hosts" in data
        assert data["meta"]["total"] == 2

    @pytest.mark.asyncio
    async def test_empty_subdomain_list_returns_empty(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.live_hosts_json = str(tmp_path / "live_hosts.json")
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        from phases.phase2_live_hosts import run_phase2
        hosts = await run_phase2("example.com", cfg, subdomains=[])
        assert hosts == []

    @pytest.mark.asyncio
    async def test_loads_subdomains_from_json(self, cfg: FrameworkConfig, tmp_path: Path):
        """run_phase2 can load hosts from subdomains.json when not passed directly."""
        sub_json = tmp_path / "subdomains.json"
        sub_json.write_text(json.dumps({
            "domain": "example.com",
            "subdomains": [{"host": "from-file.example.com"}, {"host": "also.example.com"}],
        }))
        cfg.output.subdomains_json = str(sub_json)
        cfg.output.live_hosts_json = str(tmp_path / "live_hosts.json")
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        captured: list[str] = []

        async def fake_probe(subdomains, _cfg):
            captured.extend(subdomains)
            return []

        with patch("shutil.which", return_value=None):
            from phases.phase2_live_hosts import _load_subdomains
            hosts = await _load_subdomains("example.com", cfg)

        assert "from-file.example.com" in hosts
        assert "also.example.com" in hosts
