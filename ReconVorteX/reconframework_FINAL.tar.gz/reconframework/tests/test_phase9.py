"""
tests/test_phase9.py
======================
Unit tests for Phase 9 — Subdomain Takeover Detection.

Covers:
  • TakeoverFingerprint compilation and matching (CNAME + body)
  • HTTPTakeoverChecker — all three confidence levels, no false positives
  • SubzyRunner — binary missing (soft skip), JSON parsing, malformed lines
  • NucleiTakeoverRunner — binary missing (soft skip), JSON parsing
  • Phase 9 orchestrator — merge/dedup, JSON output schema, empty subdomains
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from core.base_plugin import PluginContext
from core.config import FrameworkConfig, Phase9Config, reset_config
from plugins.takeover.fingerprints import (
    COMPILED_FINGERPRINTS,
    TakeoverFingerprint,
    get_compiled_fingerprints,
)
from plugins.takeover.http_checker import (
    HTTPTakeoverChecker,
    TakeoverCandidate,
)
from plugins.takeover.nuclei_runner import NucleiTakeoverRunner
from plugins.takeover.subzy_runner import SubzyRunner


# ---------------------------------------------------------------------------
# Import the static method correctly
# ---------------------------------------------------------------------------
from plugins.takeover.http_checker import HTTPTakeoverChecker as _HTC

_match_fp = staticmethod(_HTC._match_fingerprint)


# ===========================================================================
# Fixtures
# ===========================================================================

@pytest.fixture(autouse=True)
def _reset():
    reset_config()
    yield
    reset_config()


@pytest.fixture
def cfg() -> FrameworkConfig:
    c = FrameworkConfig()
    c.phase9 = Phase9Config(
        concurrency=5,
        timeout_s=5,
        tool_timeout=30,
        conf_cname_only=0.60,
        conf_cname_body=0.90,
        conf_subzy=0.95,
        conf_nuclei=0.97,
    )
    return c


@pytest.fixture
def ctx(cfg: FrameworkConfig) -> PluginContext:
    context = PluginContext(domain="example.com", config=cfg)
    context.metadata["takeover_hosts"] = ["sub1.example.com", "sub2.example.com"]
    return context


# ===========================================================================
# Fingerprint compilation
# ===========================================================================

class TestFingerprintCompilation:
    def test_all_fingerprints_compile(self):
        fps = get_compiled_fingerprints()
        assert len(fps) > 0
        for fp in fps:
            assert fp._cname_compiled is not None or fp._body_compiled is not None

    def test_no_duplicate_services(self):
        names = [fp.service for fp in COMPILED_FINGERPRINTS]
        assert len(names) == len(set(names)), "Duplicate service names"

    def test_all_have_body_patterns(self):
        for fp in COMPILED_FINGERPRINTS:
            assert len(fp.body_patterns) > 0, f"{fp.service} has no body patterns"

    def test_all_have_cname_patterns(self):
        for fp in COMPILED_FINGERPRINTS:
            assert len(fp.cname_patterns) > 0, f"{fp.service} has no CNAME patterns"

    def test_known_services_present(self):
        services = {fp.service for fp in COMPILED_FINGERPRINTS}
        required = {
            "GitHub Pages", "Heroku", "Netlify", "AWS S3",
            "Azure App Service", "Shopify", "Vercel", "Fastly",
        }
        missing = required - services
        assert not missing, f"Missing services: {missing}"


# ===========================================================================
# TakeoverFingerprint.matches_cname / matches_body
# ===========================================================================

class TestFingerprintMatching:
    def _fp(self, cname_pats: list[str], body_pats: list[str]) -> TakeoverFingerprint:
        fp = TakeoverFingerprint(
            service="TestService",
            cname_patterns=cname_pats,
            body_patterns=body_pats,
            status_codes=[404],
        )
        fp.compile()
        return fp

    def test_cname_match(self):
        fp = self._fp([r"\.github\.io$"], [r"no site here"])
        assert fp.matches_cname("myproject.github.io") is True
        assert fp.matches_cname("myproject.netlify.app") is False

    def test_body_match(self):
        fp = self._fp([r"\.github\.io$"], [r"There isn't a GitHub Pages site here"])
        assert fp.matches_body("There isn't a GitHub Pages site here.") is True
        assert fp.matches_body("Welcome to MyApp") is False

    def test_case_insensitive_body(self):
        fp = self._fp([], [r"no such app"])
        assert fp.matches_body("NO SUCH APP") is True

    def test_case_insensitive_cname(self):
        fp = self._fp([r"\.HEROKU\.COM$"], [])
        assert fp.matches_cname("myapp.heroku.com") is True

    def test_no_match_returns_false(self):
        fp = self._fp([r"\.github\.io$"], [r"no site here"])
        assert fp.matches_cname("example.com") is False
        assert fp.matches_body("Hello World") is False

    # --- Known service fingerprints ---

    def test_github_pages_cname(self):
        fp = next(f for f in COMPILED_FINGERPRINTS if f.service == "GitHub Pages")
        assert fp.matches_cname("myorg.github.io")

    def test_github_pages_body(self):
        fp = next(f for f in COMPILED_FINGERPRINTS if f.service == "GitHub Pages")
        assert fp.matches_body("There isn't a GitHub Pages site here.")

    def test_heroku_cname(self):
        fp = next(f for f in COMPILED_FINGERPRINTS if f.service == "Heroku")
        assert fp.matches_cname("myapp.herokuapp.com")

    def test_heroku_body(self):
        fp = next(f for f in COMPILED_FINGERPRINTS if f.service == "Heroku")
        assert fp.matches_body("no such app")

    def test_netlify_cname(self):
        fp = next(f for f in COMPILED_FINGERPRINTS if f.service == "Netlify")
        assert fp.matches_cname("awesome.netlify.app")

    def test_aws_s3_cname(self):
        fp = next(f for f in COMPILED_FINGERPRINTS if f.service == "AWS S3")
        assert fp.matches_cname("mybucket.s3.amazonaws.com")

    def test_aws_s3_body(self):
        fp = next(f for f in COMPILED_FINGERPRINTS if f.service == "AWS S3")
        assert fp.matches_body("<Code>NoSuchBucket</Code>")

    def test_vercel_cname(self):
        fp = next(f for f in COMPILED_FINGERPRINTS if f.service == "Vercel")
        assert fp.matches_cname("myapp.vercel.app")

    def test_vercel_body(self):
        fp = next(f for f in COMPILED_FINGERPRINTS if f.service == "Vercel")
        assert fp.matches_body("The deployment you are trying to access does not exist")

    def test_shopify_body(self):
        fp = next(f for f in COMPILED_FINGERPRINTS if f.service == "Shopify")
        assert fp.matches_body("Sorry, this shop is currently unavailable.")

    def test_fastly_body(self):
        fp = next(f for f in COMPILED_FINGERPRINTS if f.service == "Fastly")
        assert fp.matches_body("Fastly error: unknown domain")


# ===========================================================================
# HTTPTakeoverChecker._match_fingerprint (static method)
# ===========================================================================

class TestMatchFingerprint:
    def _make_fp(
        self,
        cname_pats: list[str],
        body_pats:  list[str],
        status_codes: list[int] = None,
    ) -> TakeoverFingerprint:
        fp = TakeoverFingerprint(
            service="TestService",
            cname_patterns=cname_pats,
            body_patterns=body_pats,
            status_codes=status_codes or [404],
        )
        fp.compile()
        return fp

    def test_cname_only_returns_low_confidence(self):
        fp     = self._make_fp([r"\.github\.io"], [r"no site"])
        result = _match_fp.__func__(
            fp, "sub.example.com", "https://sub.example.com",
            200, "Welcome page", "sub.github.io",
        )
        assert result is not None
        assert result.confidence == 0.60
        assert result.fingerprint == "cname"

    def test_body_only_returns_medium_confidence(self):
        fp     = self._make_fp([r"\.github\.io"], [r"There isn't a GitHub Pages site here"])
        result = _match_fp.__func__(
            fp, "sub.example.com", "https://sub.example.com",
            404, "There isn't a GitHub Pages site here.", None,
        )
        assert result is not None
        assert result.confidence == 0.75
        assert result.fingerprint == "body"

    def test_cname_and_body_returns_high_confidence(self):
        fp     = self._make_fp([r"\.github\.io"], [r"There isn't a GitHub Pages site here"])
        result = _match_fp.__func__(
            fp, "sub.example.com", "https://sub.example.com",
            404, "There isn't a GitHub Pages site here.", "sub.github.io",
        )
        assert result is not None
        assert result.confidence == 0.90
        assert result.fingerprint == "cname+body"

    def test_body_match_wrong_status_not_flagged(self):
        fp     = self._make_fp([r"\.github\.io"], [r"There isn't a GitHub Pages site here"])
        result = _match_fp.__func__(
            fp, "sub.example.com", "https://sub.example.com",
            200, "There isn't a GitHub Pages site here.", None,
        )
        assert result is None

    def test_no_match_returns_none(self):
        fp     = self._make_fp([r"\.github\.io"], [r"no site here"])
        result = _match_fp.__func__(
            fp, "sub.example.com", "https://sub.example.com",
            200, "Welcome to my site", "sub.example.com",
        )
        assert result is None

    def test_service_name_in_result(self):
        fp     = self._make_fp([r"\.github\.io"], [r"no site"], [404])
        result = _match_fp.__func__(
            fp, "sub.example.com", "https://sub.example.com",
            404, "no site here", "sub.github.io",
        )
        assert result is not None
        assert result.service == "TestService"

    def test_evidence_populated(self):
        fp     = self._make_fp([r"\.github\.io"], [r"no site"], [404])
        result = _match_fp.__func__(
            fp, "sub.example.com", "https://sub.example.com",
            404, "no site found", "sub.github.io",
        )
        assert result is not None
        assert len(result.evidence) >= 1


# ===========================================================================
# HTTPTakeoverChecker._infer_cname
# ===========================================================================

class TestInferCname:
    def test_redirect_url_different_host(self, cfg):
        checker = HTTPTakeoverChecker(cfg.phase9)
        hint = checker._infer_cname(
            "https://myapp.github.io/path",
            {},
            "sub.example.com",
        )
        assert hint is not None
        assert "github.io" in hint

    def test_same_host_after_redirect_not_flagged(self, cfg):
        checker = HTTPTakeoverChecker(cfg.phase9)
        hint = checker._infer_cname(
            "https://sub.example.com/page",
            {},
            "sub.example.com",
        )
        assert hint is None

    def test_server_header_included(self, cfg):
        checker = HTTPTakeoverChecker(cfg.phase9)
        hint = checker._infer_cname(
            "https://sub.example.com/",
            {"server": "AmazonS3"},
            "sub.example.com",
        )
        assert hint is not None
        assert "AmazonS3" in hint

    def test_cloudfront_header_included(self, cfg):
        checker = HTTPTakeoverChecker(cfg.phase9)
        hint = checker._infer_cname(
            "https://sub.example.com/",
            {"x-amz-cf-id": "abc123"},
            "sub.example.com",
        )
        assert hint is not None
        assert "x-amz-cf-id" in hint


# ===========================================================================
# SubzyRunner
# ===========================================================================

class TestSubzyRunner:
    @pytest.mark.asyncio
    async def test_soft_skip_when_binary_missing(self, ctx):
        ctx.config.phase9.subzy_bin = "/nonexistent/subzy"
        with patch("shutil.which", return_value=None):
            result = await SubzyRunner().execute(ctx)
        assert result.success is True
        assert result.data == []

    @pytest.mark.asyncio
    async def test_soft_skip_when_no_hosts(self, ctx):
        ctx.metadata["takeover_hosts"] = []
        with patch("shutil.which", return_value="/usr/bin/subzy"):
            result = await SubzyRunner().execute(ctx)
        assert result.success is True
        assert result.data == []

    @pytest.mark.asyncio
    async def test_parses_vulnerable_json(self, ctx):
        fake_stdout = json.dumps({
            "subdomain": "admin.example.com",
            "service":   "GitHub",
            "vulnerable": True,
            "type":      "github-pages",
        }).encode() + b"\n"
        fake_stdout += json.dumps({
            "subdomain": "safe.example.com",
            "service":   "Netlify",
            "vulnerable": False,
        }).encode() + b"\n"

        mock_proc = MagicMock()
        mock_proc.communicate = AsyncMock(return_value=(fake_stdout, b""))

        with patch("shutil.which", return_value="/usr/bin/subzy"), \
             patch("asyncio.create_subprocess_exec", return_value=mock_proc), \
             patch("asyncio.wait_for", return_value=(fake_stdout, b"")), \
             patch("pathlib.Path.unlink"):
            result = await SubzyRunner().execute(ctx)

        assert result.success is True
        assert result.data is not None
        assert len(result.data) == 1
        assert result.data[0].host == "admin.example.com"
        assert result.data[0].service == "GitHub"
        assert result.data[0].method == "subzy"

    @pytest.mark.asyncio
    async def test_skips_non_vulnerable(self, ctx):
        fake_stdout = json.dumps({
            "subdomain": "www.example.com",
            "service":   "Netlify",
            "vulnerable": False,
        }).encode() + b"\n"

        mock_proc = MagicMock()
        mock_proc.communicate = AsyncMock(return_value=(fake_stdout, b""))

        with patch("shutil.which", return_value="/usr/bin/subzy"), \
             patch("asyncio.create_subprocess_exec", return_value=mock_proc), \
             patch("asyncio.wait_for", return_value=(fake_stdout, b"")), \
             patch("pathlib.Path.unlink"):
            result = await SubzyRunner().execute(ctx)

        assert result.success is True
        assert result.data == []

    @pytest.mark.asyncio
    async def test_handles_corrupt_json(self, ctx):
        fake_stdout = b"not json\n{broken\n\n"
        mock_proc = MagicMock()
        mock_proc.communicate = AsyncMock(return_value=(fake_stdout, b""))

        with patch("shutil.which", return_value="/usr/bin/subzy"), \
             patch("asyncio.create_subprocess_exec", return_value=mock_proc), \
             patch("asyncio.wait_for", return_value=(fake_stdout, b"")), \
             patch("pathlib.Path.unlink"):
            result = await SubzyRunner().execute(ctx)

        assert result.success is True
        assert result.data == []

    @pytest.mark.asyncio
    async def test_confidence_set_to_conf_subzy(self, ctx):
        ctx.config.phase9.conf_subzy = 0.95
        fake_stdout = json.dumps({
            "subdomain": "admin.example.com",
            "service":   "Heroku",
            "vulnerable": True,
        }).encode() + b"\n"

        mock_proc = MagicMock()
        mock_proc.communicate = AsyncMock(return_value=(fake_stdout, b""))

        with patch("shutil.which", return_value="/usr/bin/subzy"), \
             patch("asyncio.create_subprocess_exec", return_value=mock_proc), \
             patch("asyncio.wait_for", return_value=(fake_stdout, b"")), \
             patch("pathlib.Path.unlink"):
            result = await SubzyRunner().execute(ctx)

        assert result.data[0].confidence == 0.95


# ===========================================================================
# NucleiTakeoverRunner
# ===========================================================================

class TestNucleiTakeoverRunner:
    @pytest.mark.asyncio
    async def test_soft_skip_when_binary_missing(self, ctx):
        ctx.config.phase9.nuclei_bin = "/nonexistent/nuclei"
        with patch("shutil.which", return_value=None):
            result = await NucleiTakeoverRunner().execute(ctx)
        assert result.success is True
        assert result.data == []

    @pytest.mark.asyncio
    async def test_parses_nuclei_json(self, ctx):
        fake_stdout = json.dumps({
            "template-id": "github-pages-takeover",
            "info": {"name": "GitHub Pages Takeover", "severity": "high"},
            "host": "https://admin.example.com",
            "matched-at": "https://admin.example.com",
        }).encode() + b"\n"

        mock_proc = MagicMock()
        mock_proc.communicate = AsyncMock(return_value=(fake_stdout, b""))

        with patch("shutil.which", return_value="/usr/bin/nuclei"), \
             patch("asyncio.create_subprocess_exec", return_value=mock_proc), \
             patch("asyncio.wait_for", return_value=(fake_stdout, b"")), \
             patch("pathlib.Path.unlink"):
            result = await NucleiTakeoverRunner().execute(ctx)

        assert result.success is True
        assert result.data is not None
        assert len(result.data) == 1
        assert result.data[0].host == "admin.example.com"
        assert result.data[0].method == "nuclei"

    @pytest.mark.asyncio
    async def test_confidence_set_to_conf_nuclei(self, ctx):
        ctx.config.phase9.conf_nuclei = 0.97
        fake_stdout = json.dumps({
            "template-id": "heroku-takeover",
            "info": {"name": "Heroku Takeover", "severity": "high"},
            "host": "https://app.example.com",
        }).encode() + b"\n"

        mock_proc = MagicMock()
        mock_proc.communicate = AsyncMock(return_value=(fake_stdout, b""))

        with patch("shutil.which", return_value="/usr/bin/nuclei"), \
             patch("asyncio.create_subprocess_exec", return_value=mock_proc), \
             patch("asyncio.wait_for", return_value=(fake_stdout, b"")), \
             patch("pathlib.Path.unlink"):
            result = await NucleiTakeoverRunner().execute(ctx)

        assert result.data[0].confidence == 0.97

    @pytest.mark.asyncio
    async def test_handles_empty_stdout(self, ctx):
        mock_proc = MagicMock()
        mock_proc.communicate = AsyncMock(return_value=(b"", b""))

        with patch("shutil.which", return_value="/usr/bin/nuclei"), \
             patch("asyncio.create_subprocess_exec", return_value=mock_proc), \
             patch("asyncio.wait_for", return_value=(b"", b"")), \
             patch("pathlib.Path.unlink"):
            result = await NucleiTakeoverRunner().execute(ctx)

        assert result.success is True
        assert result.data == []


# ===========================================================================
# Phase 9 orchestrator
# ===========================================================================

class TestPhase9Orchestrator:
    def _write_subdomains_json(self, tmp_path: Path, hosts: list[str]) -> Path:
        p = tmp_path / "subdomains.json"
        p.write_text(json.dumps({
            "domain": "example.com",
            "subdomains": [{"host": h} for h in hosts],
        }))
        return p

    def _make_candidate(self, host: str, service: str, conf: float, method: str = "http_check") -> TakeoverCandidate:
        return TakeoverCandidate(
            host=host, url=f"https://{host}",
            service=service, fingerprint="body",
            confidence=conf, method=method,
            evidence=[f"{service} unclaimed"],
        )

    @pytest.mark.asyncio
    async def test_writes_takeovers_json(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.subdomains_json = str(self._write_subdomains_json(
            tmp_path, ["admin.example.com"]
        ))
        cfg.output.takeovers_json = str(tmp_path / "takeovers.json")
        cfg.database.path         = str(tmp_path / "recon.db")
        reset_config()

        candidate = self._make_candidate("admin.example.com", "GitHub Pages", 0.90)

        with patch("phases.phase9_takeover.HTTPTakeoverChecker") as MockHTTP, \
             patch("phases.phase9_takeover.SubzyRunner") as MockSubzy, \
             patch("phases.phase9_takeover.NucleiTakeoverRunner") as MockNuclei:
            MockHTTP.return_value.check_all = AsyncMock(return_value=[candidate])
            MockSubzy.return_value.execute  = AsyncMock(return_value=MagicMock(
                success=True, data=[], error=None
            ))
            MockNuclei.return_value.execute = AsyncMock(return_value=MagicMock(
                success=True, data=[], error=None
            ))

            from phases.phase9_takeover import run_phase9
            findings = await run_phase9("example.com", cfg)

        assert (tmp_path / "takeovers.json").exists()
        data = json.loads((tmp_path / "takeovers.json").read_text())
        assert "takeovers" in data
        assert len(data["takeovers"]) == 1

    @pytest.mark.asyncio
    async def test_deduplication_keeps_highest_confidence(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.subdomains_json = str(self._write_subdomains_json(
            tmp_path, ["admin.example.com"]
        ))
        cfg.output.takeovers_json = str(tmp_path / "takeovers.json")
        cfg.database.path         = str(tmp_path / "recon.db")
        reset_config()

        http_candidate  = self._make_candidate("admin.example.com", "GitHub Pages", 0.75)
        subzy_candidate = self._make_candidate("admin.example.com", "GitHub Pages", 0.95, "subzy")

        with patch("phases.phase9_takeover.HTTPTakeoverChecker") as MockHTTP, \
             patch("phases.phase9_takeover.SubzyRunner") as MockSubzy, \
             patch("phases.phase9_takeover.NucleiTakeoverRunner") as MockNuclei:
            MockHTTP.return_value.check_all = AsyncMock(return_value=[http_candidate])
            MockSubzy.return_value.execute  = AsyncMock(return_value=MagicMock(
                success=True, data=[subzy_candidate], error=None
            ))
            MockNuclei.return_value.execute = AsyncMock(return_value=MagicMock(
                success=True, data=[], error=None
            ))

            from phases.phase9_takeover import run_phase9
            findings = await run_phase9("example.com", cfg)

        # Same host from two sources → only one finding, highest confidence
        assert len(findings) == 1
        assert findings[0].confidence == 0.95

    @pytest.mark.asyncio
    async def test_empty_subdomains_returns_empty(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.subdomains_json = str(tmp_path / "subdomains.json")
        cfg.output.takeovers_json  = str(tmp_path / "takeovers.json")
        cfg.database.path          = str(tmp_path / "recon.db")
        reset_config()

        from phases.phase9_takeover import run_phase9
        findings = await run_phase9("example.com", cfg, subdomains=[])
        assert findings == []

    @pytest.mark.asyncio
    async def test_sorted_by_confidence_descending(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.subdomains_json = str(self._write_subdomains_json(
            tmp_path, ["a.example.com", "b.example.com", "c.example.com"]
        ))
        cfg.output.takeovers_json = str(tmp_path / "takeovers.json")
        cfg.database.path         = str(tmp_path / "recon.db")
        reset_config()

        candidates = [
            self._make_candidate("a.example.com", "Heroku",      0.60),
            self._make_candidate("b.example.com", "GitHub Pages", 0.90),
            self._make_candidate("c.example.com", "Netlify",     0.75),
        ]

        with patch("phases.phase9_takeover.HTTPTakeoverChecker") as MockHTTP, \
             patch("phases.phase9_takeover.SubzyRunner") as MockSubzy, \
             patch("phases.phase9_takeover.NucleiTakeoverRunner") as MockNuclei:
            MockHTTP.return_value.check_all = AsyncMock(return_value=candidates)
            MockSubzy.return_value.execute  = AsyncMock(return_value=MagicMock(
                success=True, data=[], error=None
            ))
            MockNuclei.return_value.execute = AsyncMock(return_value=MagicMock(
                success=True, data=[], error=None
            ))

            from phases.phase9_takeover import run_phase9
            findings = await run_phase9("example.com", cfg)

        confs = [f.confidence for f in findings]
        assert confs == sorted(confs, reverse=True)

    @pytest.mark.asyncio
    async def test_loads_subdomains_from_txt_fallback(self, cfg: FrameworkConfig, tmp_path: Path):
        txt = tmp_path / "subdomains.txt"
        txt.write_text("sub1.example.com\nsub2.example.com\n")
        cfg.output.subdomains_json = str(tmp_path / "subdomains.json")  # doesn't exist
        cfg.output.subdomains_txt  = str(txt)
        cfg.output.takeovers_json  = str(tmp_path / "takeovers.json")
        cfg.database.path          = str(tmp_path / "recon.db")
        reset_config()

        captured_hosts: list[str] = []

        async def _fake_check_all(hosts):
            captured_hosts.extend(hosts)
            return []

        with patch("phases.phase9_takeover.HTTPTakeoverChecker") as MockHTTP, \
             patch("phases.phase9_takeover.SubzyRunner") as MockSubzy, \
             patch("phases.phase9_takeover.NucleiTakeoverRunner") as MockNuclei:
            MockHTTP.return_value.check_all = _fake_check_all
            MockSubzy.return_value.execute  = AsyncMock(return_value=MagicMock(
                success=True, data=[], error=None
            ))
            MockNuclei.return_value.execute = AsyncMock(return_value=MagicMock(
                success=True, data=[], error=None
            ))

            from phases.phase9_takeover import run_phase9
            await run_phase9("example.com", cfg)

        assert "sub1.example.com" in captured_hosts
        assert "sub2.example.com" in captured_hosts

    @pytest.mark.asyncio
    async def test_json_confidence_distribution(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.subdomains_json = str(self._write_subdomains_json(
            tmp_path, ["a.example.com"]
        ))
        cfg.output.takeovers_json = str(tmp_path / "takeovers.json")
        cfg.database.path         = str(tmp_path / "recon.db")
        reset_config()

        candidates = [self._make_candidate("a.example.com", "GitHub Pages", 0.90)]

        with patch("phases.phase9_takeover.HTTPTakeoverChecker") as MockHTTP, \
             patch("phases.phase9_takeover.SubzyRunner") as MockSubzy, \
             patch("phases.phase9_takeover.NucleiTakeoverRunner") as MockNuclei:
            MockHTTP.return_value.check_all = AsyncMock(return_value=candidates)
            MockSubzy.return_value.execute  = AsyncMock(return_value=MagicMock(
                success=True, data=[], error=None
            ))
            MockNuclei.return_value.execute = AsyncMock(return_value=MagicMock(
                success=True, data=[], error=None
            ))

            from phases.phase9_takeover import run_phase9
            await run_phase9("example.com", cfg)

        data = json.loads((tmp_path / "takeovers.json").read_text())
        assert "confidence_distribution" in data["meta"]
        assert data["meta"]["confidence_distribution"]["high"] >= 1
