"""
tests/test_phase6.py
======================
Unit tests for Phase 6 — Historical URL Collection.

Covers:
  • URLFilter — extension matching, param matching, segment matching,
                deduplication, exclusion patterns, batch behaviour
  • GauCollector — binary missing (soft skip), stdout parsing,
                   timeout handling
  • WaybackCollector — CDX response parsing, rate-limit handling,
                       retry on transient errors
  • CommonCrawlCollector — index discovery, per-index query, malformed
                           JSON lines skipped, 404 per index handled
  • Phase 6 orchestrator — parallel execution, merged dedup, txt + json
                           output correctness, in-memory return
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import aiohttp
import pytest

from core.base_plugin import PluginContext
from core.config import FrameworkConfig, Phase6Config, reset_config
from plugins.urls.filter import URLFilter, _has_interesting_extension, _has_interesting_param, _has_interesting_segment, _normalise
from plugins.urls.gau_collector import GauCollector
from plugins.urls.wayback_collector import WaybackCollector
from plugins.urls.commoncrawl_collector import CommonCrawlCollector


# ===========================================================================
# Fixtures
# ===========================================================================

@pytest.fixture(autouse=True)
def _reset():
    reset_config()
    yield
    reset_config()


@pytest.fixture
def cfg() -> FrameworkConfig:
    c = FrameworkConfig()
    c.phase6 = Phase6Config(
        http_timeout=5,
        wayback_limit=1000,
        cc_max_indexes=2,
        interesting_extensions=[".php", ".js", ".env", ".zip", ".json", ".sql"],
        interesting_params=["id", "file", "path", "url", "redirect"],
        exclude_patterns=["google.com", "facebook.com"],
    )
    return c


@pytest.fixture
def ctx(cfg: FrameworkConfig) -> PluginContext:
    return PluginContext(domain="example.com", config=cfg)


@pytest.fixture
def url_filter(cfg: FrameworkConfig) -> URLFilter:
    return URLFilter(cfg.phase6)


# ===========================================================================
# URLFilter — extension matching
# ===========================================================================

class TestURLFilterExtensions:
    EXTS = [".php", ".js", ".env", ".zip", ".json", ".sql"]

    def test_php_kept(self, url_filter):
        result = url_filter.filter_batch(["https://example.com/login.php"])
        assert len(result) == 1

    def test_js_kept(self, url_filter):
        result = url_filter.filter_batch(["https://example.com/app.js"])
        assert len(result) == 1

    def test_env_kept(self, url_filter):
        result = url_filter.filter_batch(["https://example.com/.env"])
        assert len(result) == 1

    def test_zip_kept(self, url_filter):
        result = url_filter.filter_batch(["https://example.com/backup.zip"])
        assert len(result) == 1

    def test_html_not_kept_no_params(self, url_filter):
        result = url_filter.filter_batch(["https://example.com/about.html"])
        assert len(result) == 0

    def test_png_not_kept(self, url_filter):
        result = url_filter.filter_batch(["https://example.com/logo.png"])
        assert len(result) == 0

    def test_extension_check_case_insensitive(self, url_filter):
        result = url_filter.filter_batch(["https://example.com/config.PHP"])
        assert len(result) == 1

    def test_helper_function_extension(self):
        assert _has_interesting_extension("/page.php", [".php"]) is True
        assert _has_interesting_extension("/page.html", [".php"]) is False


# ===========================================================================
# URLFilter — parameter matching
# ===========================================================================

class TestURLFilterParams:
    def test_id_param_kept(self, url_filter):
        result = url_filter.filter_batch(["https://example.com/item?id=42"])
        assert len(result) == 1

    def test_file_param_kept(self, url_filter):
        result = url_filter.filter_batch(["https://example.com/view?file=report"])
        assert len(result) == 1

    def test_redirect_param_kept(self, url_filter):
        result = url_filter.filter_batch(["https://example.com/go?redirect=home"])
        assert len(result) == 1

    def test_uninteresting_param_not_kept(self, url_filter):
        # no interesting extension, no interesting param, no interesting segment
        result = url_filter.filter_batch(["https://example.com/page?color=blue"])
        assert len(result) == 0

    def test_helper_function_param(self):
        assert _has_interesting_param("https://x.com/?id=1", ["id"]) is True
        assert _has_interesting_param("https://x.com/?color=blue", ["id"]) is False

    def test_param_case_insensitive(self, url_filter):
        result = url_filter.filter_batch(["https://example.com/page?FILE=config"])
        assert len(result) == 1


# ===========================================================================
# URLFilter — segment matching
# ===========================================================================

class TestURLFilterSegments:
    def test_api_segment_kept(self, url_filter):
        result = url_filter.filter_batch(["https://example.com/api/users"])
        assert len(result) == 1

    def test_admin_segment_kept(self, url_filter):
        result = url_filter.filter_batch(["https://example.com/admin/settings"])
        assert len(result) == 1

    def test_login_segment_kept(self, url_filter):
        result = url_filter.filter_batch(["https://example.com/login"])
        assert len(result) == 1

    def test_graphql_segment_kept(self, url_filter):
        result = url_filter.filter_batch(["https://example.com/graphql"])
        assert len(result) == 1

    def test_about_segment_not_kept(self, url_filter):
        result = url_filter.filter_batch(["https://example.com/about"])
        assert len(result) == 0

    def test_helper_function_segment(self):
        assert _has_interesting_segment("/api/v2/users") is True
        assert _has_interesting_segment("/about/us") is False


# ===========================================================================
# URLFilter — deduplication
# ===========================================================================

class TestURLFilterDedup:
    def test_exact_duplicate_removed(self, url_filter):
        urls = ["https://example.com/login.php"] * 3
        result = url_filter.filter_batch(urls)
        assert len(result) == 1

    def test_duplicate_across_batches_removed(self, url_filter):
        url_filter.filter_batch(["https://example.com/login.php"])
        result = url_filter.filter_batch(["https://example.com/login.php"])
        assert len(result) == 0

    def test_normalised_duplicates_removed(self, url_filter):
        # Same path, different query string values — collapse by normalised form
        a = "https://example.com/page.php?id=1"
        b = "https://example.com/page.php?id=99"
        result = url_filter.filter_batch([a, b])
        assert len(result) == 1

    def test_different_paths_both_kept(self, url_filter):
        result = url_filter.filter_batch([
            "https://example.com/login.php",
            "https://example.com/admin.php",
        ])
        assert len(result) == 2

    def test_total_seen_counter(self, url_filter):
        url_filter.filter_batch([
            "https://example.com/login.php",
            "https://example.com/.env",
        ])
        assert url_filter.total_seen() == 2


# ===========================================================================
# URLFilter — exclusion patterns
# ===========================================================================

class TestURLFilterExclusion:
    def test_google_excluded(self, url_filter):
        result = url_filter.filter_batch(["https://google.com/login.php"])
        assert len(result) == 0

    def test_facebook_excluded(self, url_filter):
        result = url_filter.filter_batch(["https://www.facebook.com/admin.php"])
        assert len(result) == 0

    def test_non_http_skipped(self, url_filter):
        result = url_filter.filter_batch(["ftp://example.com/data.sql"])
        assert len(result) == 0

    def test_empty_string_skipped(self, url_filter):
        result = url_filter.filter_batch(["", "   ", "\n"])
        assert len(result) == 0


# ===========================================================================
# URL normalisation
# ===========================================================================

class TestNormalise:
    def test_lowercase_scheme_and_host(self):
        n = _normalise("HTTPS://EXAMPLE.COM/Path")
        assert n.startswith("https://example.com")

    def test_strips_utm_params(self):
        n1 = _normalise("https://example.com/p?utm_source=google")
        n2 = _normalise("https://example.com/p")
        assert n1 == n2

    def test_malformed_url_does_not_raise(self):
        n = _normalise("not-a-url-at-all")
        assert isinstance(n, str)


# ===========================================================================
# GauCollector
# ===========================================================================

class TestGauCollector:
    @pytest.mark.asyncio
    async def test_soft_skip_when_binary_missing(self, ctx):
        ctx.config.phase6.gau_bin = "/nonexistent/gau"
        collector = GauCollector()
        result = await collector.execute(ctx)
        # Missing binary is a soft skip — success=True, data=[]
        assert result.success is True
        assert result.data == []

    @pytest.mark.asyncio
    async def test_parses_stdout_urls(self, ctx):
        fake_stdout = b"https://example.com/login.php\nhttps://example.com/admin.php\nnot-a-url\n"
        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(fake_stdout, b""))

        with patch("shutil.which", return_value="/usr/bin/gau"), \
             patch("asyncio.create_subprocess_exec", return_value=mock_proc), \
             patch("asyncio.wait_for", return_value=(fake_stdout, b"")):
            result = await GauCollector().execute(ctx)

        assert result.success is True
        assert result.data is not None
        http_urls = [u for u in result.data if u.startswith("http")]
        assert len(http_urls) == 2

    @pytest.mark.asyncio
    async def test_timeout_recorded_as_fail(self, ctx):
        async def _slow(*args, **kwargs):
            raise TimeoutError("gau timed out")

        with patch("shutil.which", return_value="/usr/bin/gau"), \
             patch("asyncio.create_subprocess_exec", side_effect=_slow):
            result = await GauCollector().execute(ctx)

        assert result.success is False

    @pytest.mark.asyncio
    async def test_empty_stdout_returns_empty_list(self, ctx):
        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(b"", b""))

        with patch("shutil.which", return_value="/usr/bin/gau"), \
             patch("asyncio.create_subprocess_exec", return_value=mock_proc), \
             patch("asyncio.wait_for", return_value=(b"", b"")):
            result = await GauCollector().execute(ctx)

        assert result.success is True
        assert result.data == []


# ===========================================================================
# WaybackCollector
# ===========================================================================

def _make_aiohttp_cm(status: int, body: bytes) -> MagicMock:
    """Build a minimal mock for aiohttp.ClientSession.get context manager."""
    lines = [line + b"\n" for line in body.split(b"\n") if line]

    class _FakeContent:
        def __aiter__(self):
            return self._gen()

        async def _gen(self):
            for line in lines:
                yield line

    resp = MagicMock()
    resp.status = status
    resp.request_info = MagicMock()
    resp.history = []
    resp.raise_for_status = MagicMock()
    resp.content = _FakeContent()

    get_cm = MagicMock()
    get_cm.__aenter__ = AsyncMock(return_value=resp)
    get_cm.__aexit__  = AsyncMock(return_value=False)

    session_obj = MagicMock()
    session_obj.get = MagicMock(return_value=get_cm)

    session_cm = MagicMock()
    session_cm.__aenter__ = AsyncMock(return_value=session_obj)
    session_cm.__aexit__  = AsyncMock(return_value=False)
    return session_cm


class TestWaybackCollector:
    @pytest.mark.asyncio
    async def test_parses_cdx_lines(self, ctx):
        expected = [
            "https://example.com/login.php",
            "https://sub.example.com/.env",
            "https://example.com/api/users",
        ]

        async def _fake_fetch(domain, cfg):
            return expected[:]

        collector = WaybackCollector()
        collector._fetch = _fake_fetch
        result = await collector.execute(ctx)

        assert result.success is True
        assert result.data == expected

    @pytest.mark.asyncio
    async def test_skips_non_http_lines(self, ctx):
        async def _fake_fetch(domain, cfg):
            # Simulate CDX already returning only http lines (as the real impl does)
            return ["https://example.com/page.php"]

        collector = WaybackCollector()
        collector._fetch = _fake_fetch
        result = await collector.execute(ctx)

        assert result.success is True
        assert all(u.startswith("http") for u in result.data)

    @pytest.mark.asyncio
    async def test_empty_response_returns_empty(self, ctx):
        async def _fake_fetch(domain, cfg):
            return []

        collector = WaybackCollector()
        collector._fetch = _fake_fetch
        result = await collector.execute(ctx)

        assert result.success is True
        assert result.data == []

    @pytest.mark.asyncio
    async def test_server_error_marks_fail(self, ctx):
        import aiohttp as _aiohttp

        get_cm = MagicMock()
        get_cm.__aenter__ = AsyncMock(
            side_effect=_aiohttp.ClientError("server error")
        )
        get_cm.__aexit__ = AsyncMock(return_value=False)

        session_obj = MagicMock()
        session_obj.get = MagicMock(return_value=get_cm)

        session_cm = MagicMock()
        session_cm.__aenter__ = AsyncMock(return_value=session_obj)
        session_cm.__aexit__  = AsyncMock(return_value=False)

        with patch("aiohttp.ClientSession", return_value=session_cm):
            result = await WaybackCollector().execute(ctx)

        assert result.success is False


# ===========================================================================
# CommonCrawlCollector
# ===========================================================================

class TestCommonCrawlCollector:
    def _mock_session(self, index_body: bytes, search_body: bytes):
        """
        Build a mock session that returns:
          - index_body for the collinfo.json call
          - search_body for index search calls
        """
        collinfo_resp = MagicMock()
        collinfo_resp.status = 200
        collinfo_resp.raise_for_status = MagicMock()
        collinfo_resp.json = AsyncMock(return_value=[
            {"id": "CC-MAIN-2024-10"},
            {"id": "CC-MAIN-2024-05"},
        ])
        collinfo_cm = MagicMock()
        collinfo_cm.__aenter__ = AsyncMock(return_value=collinfo_resp)
        collinfo_cm.__aexit__  = AsyncMock(return_value=False)

        search_resp = MagicMock()
        search_resp.status = 200
        search_resp.raise_for_status = MagicMock()

        async def _aiter():
            for line in search_body.split(b"\n"):
                if line:
                    yield line + b"\n"

        search_resp.content.__aiter__ = lambda self: _aiter()
        search_cm = MagicMock()
        search_cm.__aenter__ = AsyncMock(return_value=search_resp)
        search_cm.__aexit__  = AsyncMock(return_value=False)

        collinfo_session = MagicMock()
        collinfo_session.__aenter__ = AsyncMock(return_value=MagicMock(
            get=MagicMock(return_value=collinfo_cm)
        ))
        collinfo_session.__aexit__ = AsyncMock(return_value=False)

        search_session = MagicMock()
        search_session.__aenter__ = AsyncMock(return_value=MagicMock(
            get=MagicMock(return_value=search_cm)
        ))
        search_session.__aexit__ = AsyncMock(return_value=False)

        return collinfo_session, search_session

    @pytest.mark.asyncio
    async def test_parses_json_lines(self, ctx):
        search_body = (
            b'{"url": "https://example.com/login.php"}\n'
            b'{"url": "https://example.com/admin.php"}\n'
            b'not-json\n'
        )
        cc = CommonCrawlCollector()
        cc._get_indexes = AsyncMock(return_value=["CC-MAIN-2024-10"])

        async def fake_query(session, idx, domain, sem):
            urls = []
            for line in search_body.split(b"\n"):
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                    if url := obj.get("url"):
                        if url.startswith("http"):
                            urls.append(url)
                except Exception:
                    pass
            return urls

        cc._query_index = fake_query

        result = await cc.execute(ctx)
        assert result.success is True
        assert len(result.data) == 2

    @pytest.mark.asyncio
    async def test_handles_no_indexes(self, ctx):
        cc = CommonCrawlCollector()
        cc._get_indexes = AsyncMock(return_value=[])
        result = await cc.execute(ctx)
        assert result.success is True
        assert result.data == []

    @pytest.mark.asyncio
    async def test_404_per_index_returns_empty(self, ctx):
        cc = CommonCrawlCollector()
        cc._get_indexes = AsyncMock(return_value=["CC-MAIN-2024-10"])

        resp = MagicMock()
        resp.status = 404

        cm = MagicMock()
        cm.__aenter__ = AsyncMock(return_value=resp)
        cm.__aexit__  = AsyncMock(return_value=False)

        with patch("aiohttp.ClientSession") as mock_sess:
            session_inst = MagicMock()
            session_inst.__aenter__ = AsyncMock(return_value=MagicMock(
                get=MagicMock(return_value=cm)
            ))
            session_inst.__aexit__ = AsyncMock(return_value=False)
            mock_sess.return_value = session_inst

            result = await cc.execute(ctx)

        assert result.success is True
        assert result.data == []

    @pytest.mark.asyncio
    async def test_deduplicates_across_indexes(self, ctx):
        cc = CommonCrawlCollector()
        cc._get_indexes = AsyncMock(return_value=["IDX-1", "IDX-2"])

        async def fake_query(session, idx, domain, sem):
            # Both indexes return same URL
            return ["https://example.com/login.php"]

        cc._query_index = fake_query

        result = await cc.execute(ctx)
        assert result.success is True
        assert result.data.count("https://example.com/login.php") == 1


# ===========================================================================
# Phase 6 orchestrator
# ===========================================================================

class TestPhase6Orchestrator:
    @pytest.mark.asyncio
    async def test_writes_urls_txt(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.urls_txt = str(tmp_path / "urls.txt")
        cfg.database.path   = str(tmp_path / "recon.db")
        reset_config()

        gau_urls = ["https://example.com/login.php", "https://example.com/.env"]
        wb_urls  = ["https://example.com/api/users", "https://example.com/admin.php"]
        cc_urls  = []

        with patch("plugins.urls.gau_collector.GauCollector.run",
                   return_value=MagicMock(success=True, data=gau_urls, error=None,
                                          duration_seconds=0.1)), \
             patch("plugins.urls.wayback_collector.WaybackCollector.run",
                   return_value=MagicMock(success=True, data=wb_urls, error=None,
                                          duration_seconds=0.2)), \
             patch("plugins.urls.commoncrawl_collector.CommonCrawlCollector.run",
                   return_value=MagicMock(success=True, data=cc_urls, error=None,
                                          duration_seconds=0.1)):
            from phases.phase6_urls import run_phase6
            result = await run_phase6("example.com", cfg)

        txt_path = tmp_path / "urls.txt"
        assert txt_path.exists()
        lines = txt_path.read_text().strip().splitlines()
        assert len(lines) >= 1

    @pytest.mark.asyncio
    async def test_writes_urls_json(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.urls_txt = str(tmp_path / "urls.txt")
        cfg.database.path   = str(tmp_path / "recon.db")
        reset_config()

        urls = ["https://example.com/login.php", "https://example.com/.env"]

        with patch("plugins.urls.gau_collector.GauCollector.run",
                   return_value=MagicMock(success=True, data=urls, error=None,
                                          duration_seconds=0.1)), \
             patch("plugins.urls.wayback_collector.WaybackCollector.run",
                   return_value=MagicMock(success=True, data=[], error=None,
                                          duration_seconds=0.0)), \
             patch("plugins.urls.commoncrawl_collector.CommonCrawlCollector.run",
                   return_value=MagicMock(success=True, data=[], error=None,
                                          duration_seconds=0.0)):
            from phases.phase6_urls import run_phase6
            result = await run_phase6("example.com", cfg)

        json_path = tmp_path / "urls.json"
        assert json_path.exists()
        data = json.loads(json_path.read_text())
        assert "meta" in data
        assert "urls" in data
        assert "collector_stats" in data

    @pytest.mark.asyncio
    async def test_deduplication_across_collectors(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.urls_txt = str(tmp_path / "urls.txt")
        cfg.database.path   = str(tmp_path / "recon.db")
        reset_config()

        shared_url = "https://example.com/login.php"

        with patch("plugins.urls.gau_collector.GauCollector.run",
                   return_value=MagicMock(success=True, data=[shared_url], error=None,
                                          duration_seconds=0.1)), \
             patch("plugins.urls.wayback_collector.WaybackCollector.run",
                   return_value=MagicMock(success=True, data=[shared_url], error=None,
                                          duration_seconds=0.1)), \
             patch("plugins.urls.commoncrawl_collector.CommonCrawlCollector.run",
                   return_value=MagicMock(success=True, data=[shared_url], error=None,
                                          duration_seconds=0.1)):
            from phases.phase6_urls import run_phase6
            result = await run_phase6("example.com", cfg)

        # Same URL from all three sources → only one in output
        assert result.urls.count(shared_url) == 1
        assert result.total_kept == 1

    @pytest.mark.asyncio
    async def test_total_raw_sums_all_sources(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.urls_txt = str(tmp_path / "urls.txt")
        cfg.database.path   = str(tmp_path / "recon.db")
        reset_config()

        with patch("plugins.urls.gau_collector.GauCollector.run",
                   return_value=MagicMock(success=True,
                                          data=["https://example.com/a.php",
                                                "https://example.com/b.php"],
                                          error=None, duration_seconds=0.1)), \
             patch("plugins.urls.wayback_collector.WaybackCollector.run",
                   return_value=MagicMock(success=True,
                                          data=["https://example.com/c.php"],
                                          error=None, duration_seconds=0.1)), \
             patch("plugins.urls.commoncrawl_collector.CommonCrawlCollector.run",
                   return_value=MagicMock(success=True, data=[], error=None,
                                          duration_seconds=0.0)):
            from phases.phase6_urls import run_phase6
            result = await run_phase6("example.com", cfg)

        assert result.total_raw == 3

    @pytest.mark.asyncio
    async def test_collector_error_does_not_crash_orchestrator(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.urls_txt = str(tmp_path / "urls.txt")
        cfg.database.path   = str(tmp_path / "recon.db")
        reset_config()

        with patch("plugins.urls.gau_collector.GauCollector.run",
                   return_value=MagicMock(success=False, data=None,
                                          error="binary crash", duration_seconds=0.0)), \
             patch("plugins.urls.wayback_collector.WaybackCollector.run",
                   return_value=MagicMock(success=True,
                                          data=["https://example.com/login.php"],
                                          error=None, duration_seconds=0.1)), \
             patch("plugins.urls.commoncrawl_collector.CommonCrawlCollector.run",
                   return_value=MagicMock(success=True, data=[], error=None,
                                          duration_seconds=0.0)):
            from phases.phase6_urls import run_phase6
            result = await run_phase6("example.com", cfg)

        # Wayback succeeded — should have at least one URL
        assert result.total_kept >= 1

    @pytest.mark.asyncio
    async def test_in_memory_return_matches_file(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.urls_txt = str(tmp_path / "urls.txt")
        cfg.database.path   = str(tmp_path / "recon.db")
        reset_config()

        urls = ["https://example.com/admin.php", "https://example.com/api/data"]

        with patch("plugins.urls.gau_collector.GauCollector.run",
                   return_value=MagicMock(success=True, data=urls, error=None,
                                          duration_seconds=0.1)), \
             patch("plugins.urls.wayback_collector.WaybackCollector.run",
                   return_value=MagicMock(success=True, data=[], error=None,
                                          duration_seconds=0.0)), \
             patch("plugins.urls.commoncrawl_collector.CommonCrawlCollector.run",
                   return_value=MagicMock(success=True, data=[], error=None,
                                          duration_seconds=0.0)):
            from phases.phase6_urls import run_phase6
            result = await run_phase6("example.com", cfg)

        file_lines = set((tmp_path / "urls.txt").read_text().strip().splitlines())
        memory_set = set(result.urls)
        assert memory_set == file_lines
