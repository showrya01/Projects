"""
tests/test_phase4.py
======================
Unit tests for Phase 4 — Asset Intelligence Engine.

Covers:
  • IntelRule compilation (no regex errors, no duplicates)
  • AssetAnalyzer — hostname, title, tech, behaviour, open-redirect rules
  • Score thresholds → correct risk tier
  • Confidence averaging and min_confidence filter
  • Tag deduplication and aggregation
  • Login-form and open-redirect detection helpers
  • Phase 4 orchestrator — JSON output, DB persistence, data merging
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from core.config import FrameworkConfig, Phase4Config, reset_config
from core.models import AssetIntelligence, RiskLevel
from plugins.intelligence.analyzer import (
    AssetAnalyzer,
    AssetContext,
    _detect_login_form,
    _detect_open_redirect,
)
from plugins.intelligence.rules import (
    COMPILED_RULES,
    IntelRule,
    RuleCategory,
    get_compiled_rules,
)


# ===========================================================================
# Fixtures
# ===========================================================================

@pytest.fixture(autouse=True)
def _reset():
    reset_config()
    yield
    reset_config()


@pytest.fixture
def cfg() -> FrameworkConfig:
    c = FrameworkConfig()
    c.phase4 = Phase4Config(
        score_critical=20,
        score_high=12,
        score_medium=6,
        score_low=2,
        min_confidence=0.4,
        enable_hostname_analysis=True,
        enable_title_analysis=True,
        enable_tech_analysis=True,
        enable_behavior_analysis=True,
    )
    return c


@pytest.fixture
def analyzer(cfg: FrameworkConfig) -> AssetAnalyzer:
    return AssetAnalyzer(cfg.phase4)


def _ctx(
    host: str = "example.com",
    url:  str = "https://example.com",
    status_code: int | None = 200,
    title: str | None = None,
    redirect_chain: list[str] | None = None,
    technologies: list[str] | None = None,
    html_body: str = "",
    domain: str = "example.com",
) -> AssetContext:
    return AssetContext(
        host=host,
        url=url,
        status_code=status_code,
        title=title,
        redirect_chain=redirect_chain or [],
        technologies=technologies or [],
        html_body=html_body,
        domain=domain,
    )


# ===========================================================================
# Rule compilation
# ===========================================================================

class TestRuleCompilation:
    def test_all_rules_compile(self):
        rules = get_compiled_rules()
        assert len(rules) > 0

    def test_no_duplicate_names(self):
        names = [r.name for r in COMPILED_RULES]
        assert len(names) == len(set(names)), "Duplicate rule names found"

    def test_all_scores_positive(self):
        for r in COMPILED_RULES:
            assert r.score > 0, f"{r.name} has non-positive score"

    def test_all_confidence_in_range(self):
        for r in COMPILED_RULES:
            assert 0.0 <= r.confidence <= 1.0, f"{r.name} confidence out of range"

    def test_compiled_hostname_regex_valid(self):
        for r in COMPILED_RULES:
            if r.hostname_re:
                assert r._hostname_compiled is not None

    def test_compiled_title_regex_valid(self):
        for r in COMPILED_RULES:
            if r.title_re:
                assert r._title_compiled is not None


# ===========================================================================
# Login-form detection
# ===========================================================================

class TestLoginFormDetection:
    def test_detects_password_input(self):
        html = '<form><input type="password" name="pass"></form>'
        assert _detect_login_form(html) is True

    def test_detects_login_form_action(self):
        html = '<form action="/login"><input type="text"></form>'
        assert _detect_login_form(html) is True

    def test_detects_signin_button(self):
        html = '<button type="submit">Sign In</button>'
        assert _detect_login_form(html) is True

    def test_detects_password_name_attribute(self):
        html = '<input name="password" type="text">'
        assert _detect_login_form(html) is True

    def test_no_false_positive_on_empty(self):
        assert _detect_login_form("") is False

    def test_no_false_positive_plain_form(self):
        html = '<form action="/search"><input type="text" name="q"></form>'
        assert _detect_login_form(html) is False

    def test_case_insensitive(self):
        html = '<FORM ACTION="/LOGIN"><INPUT TYPE="PASSWORD"></FORM>'
        assert _detect_login_form(html) is True


# ===========================================================================
# Open-redirect detection
# ===========================================================================

class TestOpenRedirectDetection:
    def test_external_domain_in_chain(self):
        chain = ["https://external-evil.com/page"]
        assert _detect_open_redirect(chain, "example.com") is True

    def test_same_domain_not_flagged(self):
        chain = ["http://example.com/login", "https://example.com/dashboard"]
        assert _detect_open_redirect(chain, "example.com") is False

    def test_redirect_param_with_external_url(self):
        chain = ["https://example.com/go?redirect=https://evil.com"]
        assert _detect_open_redirect(chain, "example.com") is True

    def test_empty_chain_not_flagged(self):
        assert _detect_open_redirect([], "example.com") is False

    def test_return_param_flagged(self):
        chain = ["https://example.com/auth?return=https://attacker.io"]
        assert _detect_open_redirect(chain, "example.com") is True

    def test_next_param_flagged(self):
        chain = ["https://example.com/login?next=https://phishing.com"]
        assert _detect_open_redirect(chain, "example.com") is True

    def test_subdomain_not_flagged(self):
        chain = ["https://api.example.com/v2"]
        assert _detect_open_redirect(chain, "example.com") is False


# ===========================================================================
# Hostname rules
# ===========================================================================

class TestHostnameRules:
    def test_admin_hostname_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(host="admin.example.com", url="https://admin.example.com"))
        assert result is not None
        assert any("admin" in t for t in result.tags)

    def test_dev_hostname_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(host="dev.example.com", url="https://dev.example.com"))
        assert result is not None
        assert "dev-environment" in result.tags

    def test_staging_hostname_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(host="staging.example.com", url="https://staging.example.com"))
        assert result is not None
        assert "staging-environment" in result.tags

    def test_test_hostname_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(host="test.example.com", url="https://test.example.com"))
        assert result is not None
        assert "test-environment" in result.tags

    def test_vpn_hostname_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(host="vpn.example.com", url="https://vpn.example.com"))
        assert result is not None
        assert "vpn" in result.tags

    def test_internal_hostname_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(host="internal.example.com", url="https://internal.example.com"))
        assert result is not None
        assert "internal" in result.tags

    def test_git_hostname_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(host="git.example.com", url="https://git.example.com"))
        assert result is not None
        assert "source-code" in result.tags

    def test_auth_hostname_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(host="auth.example.com", url="https://auth.example.com"))
        assert result is not None
        assert "auth" in result.tags

    def test_plain_hostname_not_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(host="www.example.com", url="https://www.example.com"))
        assert result is None

    def test_ci_hostname_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(host="ci.example.com", url="https://ci.example.com"))
        assert result is not None
        assert "ci-cd" in result.tags


# ===========================================================================
# Title rules
# ===========================================================================

class TestTitleRules:
    def test_jenkins_title_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(title="Dashboard [Jenkins]"))
        assert result is not None
        assert "jenkins" in result.tags

    def test_grafana_title_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(title="Grafana - Home"))
        assert result is not None
        assert "grafana" in result.tags

    def test_jira_title_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(title="Jira Software"))
        assert result is not None
        assert "jira" in result.tags

    def test_kibana_title_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(title="Kibana"))
        assert result is not None
        assert "kibana" in result.tags

    def test_sonarqube_title_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(title="SonarQube"))
        assert result is not None
        assert "sonarqube" in result.tags

    def test_phpmyadmin_title_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(title="phpMyAdmin"))
        assert result is not None
        assert "phpmyadmin" in result.tags

    def test_login_title_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(title="Login - MyApp"))
        assert result is not None
        assert "login-portal" in result.tags

    def test_admin_title_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(title="Administration Panel"))
        assert result is not None
        assert "admin-panel" in result.tags

    def test_swagger_title_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(title="Swagger UI"))
        assert result is not None
        assert "swagger" in result.tags

    def test_case_insensitive_title(self, analyzer):
        result = analyzer.analyse(_ctx(title="JENKINS - BUILD SERVER"))
        assert result is not None
        assert "jenkins" in result.tags


# ===========================================================================
# Technology rules
# ===========================================================================

class TestTechnologyRules:
    def test_jenkins_tech_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(technologies=["Jenkins"]))
        assert result is not None
        assert "jenkins" in result.tags

    def test_grafana_tech_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(technologies=["Grafana"]))
        assert result is not None
        assert "grafana" in result.tags

    def test_phpmyadmin_tech_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(technologies=["phpMyAdmin"]))
        assert result is not None
        assert "database" in result.tags

    def test_wordpress_tech_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(technologies=["WordPress"]))
        assert result is not None
        assert "wordpress" in result.tags

    def test_swagger_tech_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(technologies=["Swagger UI"]))
        assert result is not None
        assert "swagger" in result.tags

    def test_graphql_tech_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(technologies=["GraphQL"]))
        assert result is not None
        assert "graphql" in result.tags

    def test_unknown_tech_not_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(technologies=["SomeRandomLib"]))
        assert result is None

    def test_tech_names_case_insensitive(self, analyzer):
        result = analyzer.analyse(_ctx(technologies=["jenkins"]))
        assert result is not None


# ===========================================================================
# HTTP behaviour rules
# ===========================================================================

class TestBehaviourRules:
    def test_401_status_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(status_code=401))
        assert result is not None
        assert "auth-wall" in result.tags
        assert "401" in result.tags

    def test_403_status_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(status_code=403))
        assert result is not None
        assert "forbidden" in result.tags

    def test_500_status_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(status_code=500))
        assert result is not None
        assert "server-error" in result.tags

    def test_login_form_in_body_flagged(self, analyzer):
        body = '<form><input type="password" name="pass"></form>'
        result = analyzer.analyse(_ctx(html_body=body))
        assert result is not None
        assert "login-portal" in result.tags

    def test_open_redirect_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(
            redirect_chain=["https://evil.com/phishing"],
            domain="example.com",
        ))
        assert result is not None
        assert "open-redirect" in result.tags

    def test_200_plain_no_other_signals_not_flagged(self, analyzer):
        result = analyzer.analyse(_ctx(status_code=200))
        assert result is None


# ===========================================================================
# Risk scoring and tiers
# ===========================================================================

class TestRiskScoring:
    def test_critical_threshold(self, cfg, analyzer):
        # Jenkins tech (10) + Jenkins title (10) = 20 → CRITICAL
        result = analyzer.analyse(_ctx(
            title="Dashboard [Jenkins]",
            technologies=["Jenkins"],
        ))
        assert result is not None
        assert result.risk_level == RiskLevel.CRITICAL

    def test_high_threshold(self, cfg, analyzer):
        # admin hostname (7) + 401 (6) = 13 → HIGH
        result = analyzer.analyse(_ctx(
            host="admin.example.com",
            url="https://admin.example.com",
            status_code=401,
        ))
        assert result is not None
        assert result.risk_level == RiskLevel.HIGH

    def test_medium_threshold(self, cfg, analyzer):
        # login title (5) + login form (5) = 10, but confidence avg may matter
        # Use WordPress tech (4) + login title (5) = 9 → HIGH (>=12 is high)
        # staging (5) + 403 (5) = 10 → still below 12 for HIGH → MEDIUM? no, 10>=6 MEDIUM
        result = analyzer.analyse(_ctx(
            host="staging.example.com",
            url="https://staging.example.com",
            status_code=403,
        ))
        assert result is not None
        assert result.risk_level in (RiskLevel.MEDIUM, RiskLevel.HIGH)

    def test_low_threshold(self, cfg, analyzer):
        # WordPress tech (4) alone → score=4 → LOW (>=2)
        result = analyzer.analyse(_ctx(technologies=["WordPress"]))
        assert result is not None
        assert result.risk_level in (RiskLevel.LOW, RiskLevel.MEDIUM)

    def test_no_result_below_min_confidence(self, cfg):
        # Set min_confidence very high so no single-rule hit passes
        cfg.phase4.min_confidence = 0.99
        analyzer = AssetAnalyzer(cfg.phase4)
        result = analyzer.analyse(_ctx(technologies=["WordPress"]))
        assert result is None

    def test_multiple_rules_boost_score(self, analyzer):
        # Jenkins in title + tech + hostname = very high score
        result = analyzer.analyse(_ctx(
            host="jenkins.example.com",
            url="https://jenkins.example.com",
            title="Dashboard [Jenkins]",
            technologies=["Jenkins"],
        ))
        assert result is not None
        assert result.risk_level == RiskLevel.CRITICAL

    def test_tags_deduplicated(self, analyzer):
        # Two rules that both add "high-value" tag — should only appear once
        result = analyzer.analyse(_ctx(
            title="Dashboard [Jenkins]",
            technologies=["Jenkins"],
        ))
        assert result is not None
        assert result.tags.count("high-value") == 1

    def test_all_reasons_listed(self, analyzer):
        # Multiple rules fire → multiple reasons
        result = analyzer.analyse(_ctx(
            host="admin.example.com",
            url="https://admin.example.com",
            title="Login",
            status_code=401,
        ))
        assert result is not None
        assert len(result.reasons) >= 3


# ===========================================================================
# Analyser toggle flags
# ===========================================================================

class TestAnalyserToggles:
    def test_disable_hostname_analysis(self, cfg):
        cfg.phase4.enable_hostname_analysis = False
        analyzer = AssetAnalyzer(cfg.phase4)
        # admin hostname alone should not fire
        result = analyzer.analyse(_ctx(
            host="admin.example.com",
            url="https://admin.example.com",
        ))
        assert result is None

    def test_disable_title_analysis(self, cfg):
        cfg.phase4.enable_title_analysis = False
        analyzer = AssetAnalyzer(cfg.phase4)
        result = analyzer.analyse(_ctx(title="Dashboard [Jenkins]"))
        assert result is None

    def test_disable_tech_analysis(self, cfg):
        cfg.phase4.enable_tech_analysis = False
        analyzer = AssetAnalyzer(cfg.phase4)
        result = analyzer.analyse(_ctx(technologies=["Jenkins"]))
        assert result is None

    def test_disable_behavior_analysis(self, cfg):
        cfg.phase4.enable_behavior_analysis = False
        analyzer = AssetAnalyzer(cfg.phase4)
        result = analyzer.analyse(_ctx(status_code=401))
        assert result is None


# ===========================================================================
# Phase 4 orchestrator
# ===========================================================================

class TestPhase4Orchestrator:
    def _live_hosts_json(self, tmp_path, hosts):
        p = tmp_path / "live_hosts.json"
        p.write_text(json.dumps({"meta": {}, "hosts": hosts}))
        return p

    def _tech_json(self, tmp_path, hosts):
        p = tmp_path / "technologies.json"
        p.write_text(json.dumps({"meta": {}, "hosts": hosts}))
        return p

    @pytest.mark.asyncio
    async def test_writes_asset_intelligence_json(self, cfg: FrameworkConfig, tmp_path: Path):
        out = tmp_path / "asset_intelligence.json"
        cfg.output.asset_intelligence_json = str(out)
        cfg.output.live_hosts_json = str(self._live_hosts_json(tmp_path, [
            {"url": "https://admin.example.com", "host": "admin.example.com",
             "status_code": 401, "title": "Login", "redirect_chain": [], "technologies": []},
        ]))
        cfg.output.technologies_json = str(self._tech_json(tmp_path, []))
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        from phases.phase4_intelligence import run_phase4
        results = await run_phase4("example.com", cfg)

        assert out.exists()
        data = json.loads(out.read_text())
        assert "findings" in data
        assert data["meta"]["total_flagged"] >= 1

    @pytest.mark.asyncio
    async def test_jenkins_host_is_critical(self, cfg: FrameworkConfig, tmp_path: Path):
        out = tmp_path / "asset_intelligence.json"
        cfg.output.asset_intelligence_json = str(out)
        cfg.output.live_hosts_json = str(self._live_hosts_json(tmp_path, [
            {"url": "https://ci.example.com", "host": "ci.example.com",
             "status_code": 200, "title": "Dashboard [Jenkins]",
             "redirect_chain": [], "technologies": ["Jenkins"]},
        ]))
        cfg.output.technologies_json = str(self._tech_json(tmp_path, []))
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        from phases.phase4_intelligence import run_phase4
        results = await run_phase4("example.com", cfg)

        assert any(r.risk_level == RiskLevel.CRITICAL for r in results)

    @pytest.mark.asyncio
    async def test_tech_merged_from_phase3(self, cfg: FrameworkConfig, tmp_path: Path):
        """Phase 3 technologies should be merged into the asset context."""
        out = tmp_path / "asset_intelligence.json"
        cfg.output.asset_intelligence_json = str(out)
        cfg.output.live_hosts_json = str(self._live_hosts_json(tmp_path, [
            {"url": "https://example.com", "host": "example.com",
             "status_code": 200, "title": "", "redirect_chain": [], "technologies": []},
        ]))
        cfg.output.technologies_json = str(self._tech_json(tmp_path, [
            {"url": "https://example.com", "host": "example.com",
             "technologies": ["Grafana"]},
        ]))
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        from phases.phase4_intelligence import run_phase4
        results = await run_phase4("example.com", cfg)

        assert any("grafana" in r.tags for r in results)

    @pytest.mark.asyncio
    async def test_empty_live_hosts_returns_empty(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.live_hosts_json = str(tmp_path / "live_hosts.json")
        cfg.output.technologies_json = str(tmp_path / "technologies.json")
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        from phases.phase4_intelligence import run_phase4
        results = await run_phase4("example.com", cfg)
        assert results == []

    @pytest.mark.asyncio
    async def test_results_sorted_critical_first(self, cfg: FrameworkConfig, tmp_path: Path):
        out = tmp_path / "asset_intelligence.json"
        cfg.output.asset_intelligence_json = str(out)
        cfg.output.live_hosts_json = str(self._live_hosts_json(tmp_path, [
            {"url": "https://admin.example.com", "host": "admin.example.com",
             "status_code": 401, "title": "Login", "redirect_chain": [], "technologies": []},
            {"url": "https://ci.example.com",    "host": "ci.example.com",
             "status_code": 200, "title": "Dashboard [Jenkins]",
             "redirect_chain": [], "technologies": ["Jenkins"]},
        ]))
        cfg.output.technologies_json = str(self._tech_json(tmp_path, []))
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        from phases.phase4_intelligence import run_phase4
        results = await run_phase4("example.com", cfg)

        if len(results) >= 2:
            risk_order = {
                RiskLevel.CRITICAL: 0, RiskLevel.HIGH: 1,
                RiskLevel.MEDIUM: 2, RiskLevel.LOW: 3, RiskLevel.INFO: 4,
            }
            for i in range(len(results) - 1):
                assert risk_order[results[i].risk_level] <= risk_order[results[i + 1].risk_level]

    @pytest.mark.asyncio
    async def test_json_risk_distribution_correct(self, cfg: FrameworkConfig, tmp_path: Path):
        out = tmp_path / "asset_intelligence.json"
        cfg.output.asset_intelligence_json = str(out)
        cfg.output.live_hosts_json = str(self._live_hosts_json(tmp_path, [
            {"url": "https://jenkins.example.com", "host": "jenkins.example.com",
             "status_code": 200, "title": "Dashboard [Jenkins]",
             "redirect_chain": [], "technologies": ["Jenkins"]},
        ]))
        cfg.output.technologies_json = str(self._tech_json(tmp_path, []))
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        from phases.phase4_intelligence import run_phase4
        await run_phase4("example.com", cfg)

        data = json.loads(out.read_text())
        dist = data["meta"]["risk_distribution"]
        assert "CRITICAL" in dist
        assert dist["CRITICAL"] >= 1
