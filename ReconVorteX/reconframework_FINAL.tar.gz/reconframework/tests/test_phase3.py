"""
tests/test_phase3.py
======================
Unit tests for Phase 3 — Technology Intelligence.

Covers:
  • Signature compilation (no regex errors)
  • TechFingerprinter — header, cookie, HTML, meta, script, URL matching
  • Version extraction
  • Implies resolution
  • Phase 2 tech merging
  • Confidence boosting (multi-rule)
  • min_confidence filtering
  • Phase3Fetcher — cookie parsing, empty-body fallback
  • phase3_technology orchestrator — JSON output, DB persistence
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from core.config import FrameworkConfig, Phase3Config, reset_config
from core.models import TechnologyFingerprint
from plugins.technology.fetcher import _parse_cookies
from plugins.technology.fingerprinter import RawProbeResult, TechFingerprinter, TechMatch
from plugins.technology.signatures import (
    COMPILED_SIGNATURES,
    Signature,
    TechCategory,
    get_compiled_signatures,
)


# ===========================================================================
# Fixtures
# ===========================================================================

@pytest.fixture(autouse=True)
def _reset():
    reset_config()
    yield
    reset_config()


@pytest.fixture
def fp() -> TechFingerprinter:
    return TechFingerprinter()


@pytest.fixture
def cfg() -> FrameworkConfig:
    c = FrameworkConfig()
    c.phase3 = Phase3Config(concurrency=5, timeout_s=5, min_confidence=0.5)
    return c


def _probe(
    url: str = "https://example.com",
    host: str = "example.com",
    headers: dict | None = None,
    body: str = "",
    cookies: dict | None = None,
    phase2_techs: list[str] | None = None,
) -> RawProbeResult:
    return RawProbeResult(
        url=url,
        host=host,
        response_headers=headers or {},
        body_bytes=body.encode(),
        cookies=cookies or {},
        phase2_techs=phase2_techs or [],
    )


# ===========================================================================
# Signature compilation
# ===========================================================================

class TestSignatureCompilation:
    def test_all_signatures_compile_without_error(self):
        """Every pattern in the signature library must be valid regex."""
        sigs = get_compiled_signatures()
        assert len(sigs) > 0
        for sig in sigs:
            assert sig._compiled_html is not None
            assert sig._compiled_meta is not None

    def test_compiled_sigs_singleton_matches_count(self):
        """COMPILED_SIGNATURES singleton should equal fresh compilation count."""
        assert len(COMPILED_SIGNATURES) == len(get_compiled_signatures())

    def test_all_sigs_have_name_and_category(self):
        for sig in COMPILED_SIGNATURES:
            assert sig.name, f"Signature missing name: {sig}"
            assert isinstance(sig.category, TechCategory)

    def test_confidence_base_in_range(self):
        for sig in COMPILED_SIGNATURES:
            assert 0.0 <= sig.confidence_base <= 1.0, (
                f"{sig.name} confidence_base out of range: {sig.confidence_base}"
            )

    def test_no_duplicate_names(self):
        names = [s.name for s in COMPILED_SIGNATURES]
        assert len(names) == len(set(names)), "Duplicate signature names detected"


# ===========================================================================
# Header matching
# ===========================================================================

class TestHeaderMatching:
    def test_nginx_server_header(self, fp):
        probe = _probe(headers={"server": "nginx/1.18.0"})
        matches = {m.name for m in fp.match(probe)}
        assert "Nginx" in matches

    def test_apache_server_header(self, fp):
        probe = _probe(headers={"server": "Apache/2.4.51 (Ubuntu)"})
        matches = {m.name for m in fp.match(probe)}
        assert "Apache" in matches

    def test_iis_server_header(self, fp):
        probe = _probe(headers={"server": "Microsoft-IIS/10.0"})
        matches = {m.name for m in fp.match(probe)}
        assert "IIS" in matches

    def test_php_x_powered_by(self, fp):
        probe = _probe(headers={"x-powered-by": "PHP/8.2.1"})
        matches = {m.name for m in fp.match(probe)}
        assert "PHP" in matches

    def test_aspnet_header(self, fp):
        probe = _probe(headers={
            "x-powered-by": "ASP.NET",
            "x-aspnet-version": "4.0.30319",
        })
        matches = {m.name for m in fp.match(probe)}
        assert "ASP.NET" in matches

    def test_express_x_powered_by(self, fp):
        probe = _probe(headers={"x-powered-by": "Express"})
        matches = {m.name for m in fp.match(probe)}
        assert "Express" in matches

    def test_grafana_custom_header(self, fp):
        probe = _probe(headers={"x-grafana-org-id": "1"})
        matches = {m.name for m in fp.match(probe)}
        assert "Grafana" in matches

    def test_jenkins_custom_header(self, fp):
        probe = _probe(headers={"x-jenkins": "2.401.1"})
        matches = {m.name for m in fp.match(probe)}
        assert "Jenkins" in matches

    def test_cloudflare_cf_ray_header(self, fp):
        probe = _probe(headers={"cf-ray": "abc123-LHR", "server": "cloudflare"})
        matches = {m.name for m in fp.match(probe)}
        assert "Cloudflare" in matches

    def test_case_insensitive_header_keys(self, fp):
        """Header names should be matched case-insensitively."""
        probe = _probe(headers={"Server": "nginx/1.18.0"})
        matches = {m.name for m in fp.match(probe)}
        assert "Nginx" in matches


# ===========================================================================
# Cookie matching
# ===========================================================================

class TestCookieMatching:
    def test_wordpress_cookie(self, fp):
        probe = _probe(cookies={"wordpress_logged_in_abc": "1"})
        matches = {m.name for m in fp.match(probe)}
        assert "WordPress" in matches

    def test_laravel_session_cookie(self, fp):
        probe = _probe(cookies={"laravel_session": "xyz"})
        matches = {m.name for m in fp.match(probe)}
        assert "Laravel" in matches

    def test_django_csrf_cookie(self, fp):
        probe = _probe(cookies={"csrftoken": "abc"})
        matches = {m.name for m in fp.match(probe)}
        assert "Django" in matches

    def test_phpsessid_cookie(self, fp):
        probe = _probe(cookies={"PHPSESSID": "sess123"})
        matches = {m.name for m in fp.match(probe)}
        assert "PHP" in matches

    def test_phpmyadmin_cookie(self, fp):
        probe = _probe(cookies={"phpMyAdmin": "abc"})
        matches = {m.name for m in fp.match(probe)}
        assert "phpMyAdmin" in matches


# ===========================================================================
# HTML body matching
# ===========================================================================

class TestHtmlBodyMatching:
    def test_wordpress_wp_content(self, fp):
        probe = _probe(body='<link href="/wp-content/themes/twenty/style.css">')
        matches = {m.name for m in fp.match(probe)}
        assert "WordPress" in matches

    def test_wordpress_wp_includes(self, fp):
        probe = _probe(body='<script src="/wp-includes/js/jquery.js"></script>')
        matches = {m.name for m in fp.match(probe)}
        assert "WordPress" in matches

    def test_drupal_settings(self, fp):
        probe = _probe(body="var drupalSettings = {};")
        matches = {m.name for m in fp.match(probe)}
        assert "Drupal" in matches

    def test_joomla_media_path(self, fp):
        probe = _probe(body='<script src="/media/jui/js/jquery.min.js"></script>')
        matches = {m.name for m in fp.match(probe)}
        assert "Joomla" in matches

    def test_react_data_reactroot(self, fp):
        probe = _probe(body='<div id="root" data-reactroot=""></div>')
        matches = {m.name for m in fp.match(probe)}
        assert "React" in matches

    def test_angular_ng_version(self, fp):
        probe = _probe(body='<app-root ng-version="17.0.0"></app-root>')
        matches = {m.name for m in fp.match(probe)}
        assert "Angular" in matches

    def test_vue_v_bind(self, fp):
        probe = _probe(body='<div v-bind:class="active"></div><script src="vue.min.js"></script>')
        matches = {m.name for m in fp.match(probe)}
        assert "Vue.js" in matches

    def test_jenkins_html(self, fp):
        probe = _probe(body='<title>Dashboard [Jenkins]</title><div id="jenkins"></div>')
        matches = {m.name for m in fp.match(probe)}
        assert "Jenkins" in matches

    def test_grafana_html(self, fp):
        probe = _probe(body='<div app="grafana"></div>')
        matches = {m.name for m in fp.match(probe)}
        assert "Grafana" in matches

    def test_nextjs_data(self, fp):
        probe = _probe(body='<script id="__NEXT_DATA__" type="application/json">{}</script>')
        matches = {m.name for m in fp.match(probe)}
        assert "Next.js" in matches

    def test_no_false_positives_on_empty_body(self, fp):
        """Empty body + no headers should produce zero matches."""
        probe = _probe()
        assert fp.match(probe) == []

    def test_swagger_ui_detection(self, fp):
        probe = _probe(
            url="https://api.example.com/swagger-ui/index.html",
            body='<div id="swagger-ui"></div>',
        )
        matches = {m.name for m in fp.match(probe)}
        assert "Swagger UI" in matches


# ===========================================================================
# Meta tag matching
# ===========================================================================

class TestMetaTagMatching:
    def test_wordpress_meta_generator(self, fp):
        probe = _probe(body='<meta name="generator" content="WordPress 6.4.2" />')
        matches = {m.name for m in fp.match(probe)}
        assert "WordPress" in matches

    def test_drupal_meta_generator(self, fp):
        probe = _probe(body='<meta name="generator" content="Drupal 10 (https://www.drupal.org)">')
        matches = {m.name for m in fp.match(probe)}
        assert "Drupal" in matches

    def test_joomla_meta_generator(self, fp):
        probe = _probe(body='<meta name="generator" content="Joomla! - Open Source Content Management" />')
        matches = {m.name for m in fp.match(probe)}
        assert "Joomla" in matches


# ===========================================================================
# URL pattern matching
# ===========================================================================

class TestUrlPatternMatching:
    def test_jenkins_url(self, fp):
        probe = _probe(url="https://ci.example.com/jenkins/")
        matches = {m.name for m in fp.match(probe)}
        assert "Jenkins" in matches

    def test_grafana_url(self, fp):
        probe = _probe(url="https://monitor.example.com/grafana")
        matches = {m.name for m in fp.match(probe)}
        assert "Grafana" in matches

    def test_phpmyadmin_url(self, fp):
        probe = _probe(url="https://db.example.com/phpmyadmin/")
        matches = {m.name for m in fp.match(probe)}
        assert "phpMyAdmin" in matches

    def test_graphql_url(self, fp):
        probe = _probe(url="https://api.example.com/graphql")
        matches = {m.name for m in fp.match(probe)}
        assert "GraphQL" in matches


# ===========================================================================
# Implies resolution
# ===========================================================================

class TestImpliesResolution:
    def test_wordpress_implies_php(self, fp):
        probe = _probe(body='/wp-content/themes/hello')
        matches = {m.name for m in fp.match(probe)}
        # WordPress detected → PHP implied
        assert "WordPress" in matches
        assert "PHP" in matches

    def test_nextjs_implies_react(self, fp):
        probe = _probe(body='<script id="__NEXT_DATA__" type="application/json">{}</script>')
        matches = {m.name for m in fp.match(probe)}
        assert "Next.js" in matches
        assert "React" in matches

    def test_implied_confidence_is_lower(self, fp):
        """Implied tech should have lower confidence than the tech that implies it."""
        probe = _probe(body='/wp-content/themes/ /wp-includes/')
        matches = {m.name: m.confidence for m in fp.match(probe)}
        if "WordPress" in matches and "PHP" in matches:
            assert matches["PHP"] < matches["WordPress"]

    def test_implied_by_field_set(self, fp):
        probe = _probe(body='__NEXT_DATA__ _next/static')
        matches = {m.name: m for m in fp.match(probe)}
        if "Node.js" in matches and matches["Node.js"].implied_by:
            assert matches["Node.js"].implied_by in ("Next.js", "Express", "Nuxt.js")


# ===========================================================================
# Phase 2 tech merging
# ===========================================================================

class TestPhase2TechMerging:
    def test_phase2_tech_added_at_baseline_confidence(self, fp):
        probe = _probe(phase2_techs=["Bootstrap", "jQuery"])
        matches = {m.name: m for m in fp.match(probe)}
        # Even with no HTML evidence, Phase 2 names appear
        assert "Bootstrap" in matches
        assert "jQuery" in matches

    def test_phase2_tech_confidence_boosted_when_confirmed(self, fp):
        """If Phase 3 also detects Bootstrap via HTML, confidence > baseline."""
        probe = _probe(
            body='<link href="bootstrap.min.css">',
            phase2_techs=["Bootstrap"],
        )
        matches = {m.name: m for m in fp.match(probe)}
        assert "Bootstrap" in matches
        # Confirmed by both Phase 2 and HTML — higher than plain baseline
        assert matches["Bootstrap"].confidence > 0.60

    def test_phase2_tech_rule_recorded(self, fp):
        probe = _probe(phase2_techs=["SomeObscureTech"])
        matches = {m.name: m for m in fp.match(probe)}
        if "SomeObscureTech" in matches:
            assert "phase2:httpx-tech-detect" in matches["SomeObscureTech"].matched_rules


# ===========================================================================
# Confidence scoring
# ===========================================================================

class TestConfidenceScoring:
    def test_multi_rule_boosts_confidence(self, fp):
        """Multiple independent rule types firing should boost confidence."""
        # WordPress: header + HTML + cookie all firing
        probe = _probe(
            headers={"link": 'rel="https://api.w.org/"'},
            body="/wp-content/themes/hello /wp-includes/js",
            cookies={"wordpress_logged_in_abc": "1"},
        )
        matches = {m.name: m for m in fp.match(probe)}
        assert "WordPress" in matches
        # Should be higher than confidence_base alone
        assert matches["WordPress"].confidence >= 0.90

    def test_confidence_never_exceeds_0_99(self, fp):
        """Confidence must be capped at 0.99 regardless of match count."""
        probe = _probe(
            headers={"server": "nginx/1.18", "x-powered-by": "PHP/8.0"},
            body="nginx nginx nginx nginx nginx nginx",
        )
        matches = fp.match(probe)
        for m in matches:
            assert m.confidence <= 0.99, f"{m.name} confidence {m.confidence} > 0.99"

    def test_min_confidence_filter(self):
        """Results below min_confidence must be excluded by the orchestrator."""
        # Simulate orchestrator filtering
        from plugins.technology.fingerprinter import TechMatch
        all_matches = [
            TechMatch("Tech A", TechCategory.OTHER, 0.8, ["html:foo"]),
            TechMatch("Tech B", TechCategory.OTHER, 0.3, ["url:bar"]),  # below 0.5
        ]
        filtered = [m for m in all_matches if m.confidence >= 0.5]
        assert len(filtered) == 1
        assert filtered[0].name == "Tech A"


# ===========================================================================
# Version extraction
# ===========================================================================

class TestVersionExtraction:
    def test_wordpress_version_from_meta(self, fp):
        probe = _probe(body='<meta name="generator" content="WordPress 6.4.2" />')
        matches = {m.name: m for m in fp.match(probe)}
        if "WordPress" in matches:
            assert matches["WordPress"].version == "6.4.2"

    def test_php_version_from_header(self, fp):
        probe = _probe(headers={"x-powered-by": "PHP/8.2.1"})
        matches = {m.name: m for m in fp.match(probe)}
        if "PHP" in matches:
            assert matches["PHP"].version == "8.2.1"

    def test_nginx_version_from_server_header(self, fp):
        probe = _probe(headers={"server": "nginx/1.24.0"})
        matches = {m.name: m for m in fp.match(probe)}
        if "Nginx" in matches:
            assert matches["Nginx"].version == "1.24.0"

    def test_no_version_when_absent(self, fp):
        probe = _probe(headers={"server": "nginx"})
        matches = {m.name: m for m in fp.match(probe)}
        if "Nginx" in matches:
            # No version string present — should be None
            assert matches["Nginx"].version is None


# ===========================================================================
# Cookie header parser
# ===========================================================================

class TestParseCookies:
    def test_simple_cookie(self):
        result = _parse_cookies("PHPSESSID=abc123")
        assert "PHPSESSID" in result

    def test_multiple_cookies(self):
        result = _parse_cookies("session=xyz; laravel_session=abc")
        assert "session" in result or "laravel_session" in result

    def test_empty_string(self):
        result = _parse_cookies("")
        assert result == {}

    def test_malformed_does_not_raise(self):
        # Should not raise even if parsing fails
        result = _parse_cookies("not=valid=cookie;;=")
        assert isinstance(result, dict)


# ===========================================================================
# Phase 3 orchestrator
# ===========================================================================

class TestPhase3Orchestrator:
    def _hosts_json(self, tmp_path: Path, hosts: list[dict]) -> Path:
        p = tmp_path / "live_hosts.json"
        p.write_text(json.dumps({"meta": {"total": len(hosts)}, "hosts": hosts}))
        return p

    @pytest.mark.asyncio
    async def test_writes_technologies_json(self, cfg: FrameworkConfig, tmp_path: Path):
        out = tmp_path / "technologies.json"
        cfg.output.technologies_json = str(out)
        cfg.output.live_hosts_json = str(
            self._hosts_json(tmp_path, [
                {"url": "https://example.com", "host": "example.com", "technologies": ["jQuery"]},
            ])
        )
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        # Mock the fetcher so we don't make real network requests
        mock_probe = RawProbeResult(
            url="https://example.com",
            host="example.com",
            response_headers={"server": "nginx/1.18.0"},
            body_bytes=b"<title>Test</title>",
            cookies={},
            phase2_techs=["jQuery"],
        )

        with patch(
            "phases.phase3_technology.Phase3Fetcher",
            return_value=MagicMock(
                __aenter__=AsyncMock(return_value=MagicMock(
                    fetch_all=AsyncMock(return_value=[mock_probe])
                )),
                __aexit__=AsyncMock(return_value=False),
            ),
        ):
            from phases.phase3_technology import run_phase3
            results = await run_phase3("example.com", cfg)

        assert out.exists()
        data = json.loads(out.read_text())
        assert "hosts" in data
        assert data["meta"]["total_hosts"] == 1
        assert len(results) == 1

    @pytest.mark.asyncio
    async def test_nginx_detected_in_output(self, cfg: FrameworkConfig, tmp_path: Path):
        out = tmp_path / "technologies.json"
        cfg.output.technologies_json = str(out)
        cfg.output.live_hosts_json = str(
            self._hosts_json(tmp_path, [
                {"url": "https://example.com", "host": "example.com", "technologies": []},
            ])
        )
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        mock_probe = RawProbeResult(
            url="https://example.com",
            host="example.com",
            response_headers={"server": "nginx/1.24.0"},
            body_bytes=b"",
            cookies={},
            phase2_techs=[],
        )

        with patch(
            "phases.phase3_technology.Phase3Fetcher",
            return_value=MagicMock(
                __aenter__=AsyncMock(return_value=MagicMock(
                    fetch_all=AsyncMock(return_value=[mock_probe])
                )),
                __aexit__=AsyncMock(return_value=False),
            ),
        ):
            from phases.phase3_technology import run_phase3
            results = await run_phase3("example.com", cfg)

        assert results[0].web_server == "Nginx"
        data = json.loads(out.read_text())
        assert "Nginx" in data["technology_frequency"]

    @pytest.mark.asyncio
    async def test_empty_host_list_returns_empty(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.output.live_hosts_json = str(tmp_path / "live_hosts.json")
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        from phases.phase3_technology import run_phase3
        results = await run_phase3("example.com", cfg, live_hosts=[])
        assert results == []

    @pytest.mark.asyncio
    async def test_phase2_techs_merged_into_output(self, cfg: FrameworkConfig, tmp_path: Path):
        """Technologies detected by Phase 2 must appear in Phase 3 output."""
        out = tmp_path / "technologies.json"
        cfg.output.technologies_json = str(out)
        cfg.output.live_hosts_json = str(
            self._hosts_json(tmp_path, [
                {"url": "https://example.com", "host": "example.com",
                 "technologies": ["Bootstrap", "jQuery"]},
            ])
        )
        cfg.database.path = str(tmp_path / "recon.db")
        reset_config()

        mock_probe = RawProbeResult(
            url="https://example.com",
            host="example.com",
            response_headers={},
            body_bytes=b"",
            cookies={},
            phase2_techs=["Bootstrap", "jQuery"],
        )

        with patch(
            "phases.phase3_technology.Phase3Fetcher",
            return_value=MagicMock(
                __aenter__=AsyncMock(return_value=MagicMock(
                    fetch_all=AsyncMock(return_value=[mock_probe])
                )),
                __aexit__=AsyncMock(return_value=False),
            ),
        ):
            from phases.phase3_technology import run_phase3
            results = await run_phase3("example.com", cfg)

        techs = results[0].technologies
        assert "Bootstrap" in techs
        assert "jQuery" in techs
