"""
tests/test_phase11.py
=======================
Unit tests for Phase 11 — Risk Scoring Engine.

Covers:
  • HostScore accumulator — add(), finalise(), risk tier thresholds
  • _score_phase4 — risk level → points, reason text
  • _score_phase7 — phase11_score_contributions passthrough
  • _score_phase8 — per-type JS scoring, repeat occurrence discount
  • _score_phase9 — confidence band to score mapping
  • _score_phase10 — phase11_score_contributions passthrough
  • run_phase11 orchestrator — multi-source merge, ranking, JSON schema,
                               zero-score hosts excluded, max_targets cap
"""

from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path

import pytest

from core.config import FrameworkConfig, Phase11Config, reset_config
from core.models import RiskLevel
from phases.phase11_scoring import (
    HostScore,
    _score_phase4,
    _score_phase7,
    _score_phase8,
    _score_phase9,
    _score_phase10,
    run_phase11,
)


# ===========================================================================
# Fixtures
# ===========================================================================

@pytest.fixture(autouse=True)
def _reset():
    reset_config()
    yield
    reset_config()


@pytest.fixture
def cfg() -> FrameworkConfig:
    c = FrameworkConfig()
    c.phase11 = Phase11Config(
        tier_critical=30, tier_high=20, tier_medium=10, tier_low=5,
        p4_critical=20, p4_high=15, p4_medium=8, p4_low=3,
        p8_aws_key=15, p8_credential=15, p8_jwt=10,
        p8_secret_assignment=10, p8_secret_entropy=8,
        p8_internal_url=8, p8_source_map=5, p8_graphql=5,
        p8_endpoint=3, p8_api_route=3, p8_package_ref=1,
        p8_commented_code=4,
        p9_high_conf=20, p9_med_conf=15, p9_low_conf=10,
        max_targets=0,
    )
    return c


def _get_fn(scores: dict) -> callable:
    def get(host: str) -> HostScore:
        if host not in scores:
            scores[host] = HostScore(host=host)
        return scores[host]
    return get


# ===========================================================================
# HostScore
# ===========================================================================

class TestHostScore:
    def test_add_accumulates_total(self):
        hs = HostScore("example.com")
        hs.add("phase4", 20, "reason A")
        hs.add("phase7", 10, "reason B")
        assert hs.total == 30

    def test_add_zero_points_ignored(self):
        hs = HostScore("example.com")
        hs.add("phase4", 0, "zero reason")
        assert hs.total == 0
        assert len(hs.reasons) == 0

    def test_add_negative_points_ignored(self):
        hs = HostScore("example.com")
        hs.add("phase4", -5, "negative")
        assert hs.total == 0

    def test_breakdown_per_phase(self):
        hs = HostScore("example.com")
        hs.add("phase4",  20, "r1")
        hs.add("phase7",  10, "r2")
        hs.add("phase10",  6, "r3")
        assert hs.breakdown["phase4"]  == 20
        assert hs.breakdown["phase7"]  == 10
        assert hs.breakdown["phase10"] == 6

    def test_reasons_list_populated(self):
        hs = HostScore("example.com")
        hs.add("phase4", 10, "reason one")
        hs.add("phase7",  5, "reason two")
        assert "reason one" in hs.reasons
        assert "reason two" in hs.reasons

    def test_finalise_critical(self, cfg):
        hs = HostScore("example.com")
        hs.add("phase4", 30, "r")
        hs.finalise(cfg.phase11)
        assert hs.risk == RiskLevel.CRITICAL

    def test_finalise_high(self, cfg):
        hs = HostScore("example.com")
        hs.add("phase4", 25, "r")
        hs.finalise(cfg.phase11)
        assert hs.risk == RiskLevel.HIGH

    def test_finalise_medium(self, cfg):
        hs = HostScore("example.com")
        hs.add("phase4", 12, "r")
        hs.finalise(cfg.phase11)
        assert hs.risk == RiskLevel.MEDIUM

    def test_finalise_low(self, cfg):
        hs = HostScore("example.com")
        hs.add("phase4", 7, "r")
        hs.finalise(cfg.phase11)
        assert hs.risk == RiskLevel.LOW

    def test_finalise_info(self, cfg):
        hs = HostScore("example.com")
        hs.add("phase4", 2, "r")
        hs.finalise(cfg.phase11)
        assert hs.risk == RiskLevel.INFO

    def test_exactly_at_threshold_critical(self, cfg):
        hs = HostScore("example.com")
        hs.add("phase4", 30, "r")   # exactly tier_critical
        hs.finalise(cfg.phase11)
        assert hs.risk == RiskLevel.CRITICAL


# ===========================================================================
# _score_phase4
# ===========================================================================

class TestScorePhase4:
    def _write_intel(self, tmp_path: Path, findings: list) -> None:
        p = tmp_path / "asset_intelligence.json"
        p.write_text(json.dumps({"findings": findings}))

    def test_critical_asset_scores_correctly(self, cfg, tmp_path):
        self._write_intel(tmp_path, [{
            "host": "jenkins.example.com",
            "risk_level": "CRITICAL",
            "tags": ["ci-cd", "jenkins"],
            "reasons": ["Jenkins CI detected"],
        }])
        cfg.output.asset_intelligence_json = str(tmp_path / "asset_intelligence.json")
        scores: dict = {}
        _score_phase4(cfg, cfg.phase11, _get_fn(scores))
        assert "jenkins.example.com" in scores
        assert scores["jenkins.example.com"].breakdown["phase4"] == 20

    def test_high_asset_scores_correctly(self, cfg, tmp_path):
        self._write_intel(tmp_path, [{
            "host": "admin.example.com",
            "risk_level": "HIGH",
            "tags": ["admin-panel"],
            "reasons": ["Admin panel detected"],
        }])
        cfg.output.asset_intelligence_json = str(tmp_path / "asset_intelligence.json")
        scores: dict = {}
        _score_phase4(cfg, cfg.phase11, _get_fn(scores))
        assert scores["admin.example.com"].breakdown["phase4"] == 15

    def test_medium_asset_scores_correctly(self, cfg, tmp_path):
        self._write_intel(tmp_path, [{
            "host": "blog.example.com",
            "risk_level": "MEDIUM",
            "tags": ["cms"],
            "reasons": ["WordPress detected"],
        }])
        cfg.output.asset_intelligence_json = str(tmp_path / "asset_intelligence.json")
        scores: dict = {}
        _score_phase4(cfg, cfg.phase11, _get_fn(scores))
        assert scores["blog.example.com"].breakdown["phase4"] == 8

    def test_missing_file_is_skipped(self, cfg, tmp_path):
        cfg.output.asset_intelligence_json = str(tmp_path / "nonexistent.json")
        scores: dict = {}
        _score_phase4(cfg, cfg.phase11, _get_fn(scores))
        assert scores == {}

    def test_reason_text_contains_risk_level(self, cfg, tmp_path):
        self._write_intel(tmp_path, [{
            "host": "admin.example.com",
            "risk_level": "CRITICAL",
            "tags": ["admin"],
            "reasons": ["Admin panel"],
        }])
        cfg.output.asset_intelligence_json = str(tmp_path / "asset_intelligence.json")
        scores: dict = {}
        _score_phase4(cfg, cfg.phase11, _get_fn(scores))
        reasons = scores["admin.example.com"].reasons
        assert any("CRITICAL" in r for r in reasons)


# ===========================================================================
# _score_phase7
# ===========================================================================

class TestScorePhase7:
    def _write_endpoints(self, tmp_path: Path, contribs: dict) -> None:
        p = tmp_path / "sensitive_endpoints.json"
        p.write_text(json.dumps({
            "phase11_score_contributions": contribs,
            "findings": [],
        }))

    def test_contributions_applied(self, cfg, tmp_path):
        self._write_endpoints(tmp_path, {"api.example.com": 17})
        cfg.output.sensitive_endpoints_txt = str(tmp_path / "sensitive_endpoints.txt")
        scores: dict = {}
        _score_phase7(cfg, cfg.phase11, _get_fn(scores))
        assert scores["api.example.com"].breakdown["phase7"] == 17

    def test_zero_contribution_skipped(self, cfg, tmp_path):
        self._write_endpoints(tmp_path, {"boring.example.com": 0})
        cfg.output.sensitive_endpoints_txt = str(tmp_path / "sensitive_endpoints.txt")
        scores: dict = {}
        _score_phase7(cfg, cfg.phase11, _get_fn(scores))
        assert "boring.example.com" not in scores

    def test_missing_file_is_skipped(self, cfg, tmp_path):
        cfg.output.sensitive_endpoints_txt = str(tmp_path / "no.txt")
        scores: dict = {}
        _score_phase7(cfg, cfg.phase11, _get_fn(scores))
        assert scores == {}


# ===========================================================================
# _score_phase8
# ===========================================================================

class TestScorePhase8:
    def _write_js(self, tmp_path: Path, findings: list) -> None:
        p = tmp_path / "js_analysis.json"
        p.write_text(json.dumps({"findings": findings}))

    def test_aws_key_scores_correctly(self, cfg, tmp_path):
        self._write_js(tmp_path, [{
            "js_url": "https://example.com/app.js",
            "finding_type": "aws_key",
            "value": "AKIAIOSFODNN7EXAMPLE",
        }])
        cfg.output.js_analysis_json = str(tmp_path / "js_analysis.json")
        scores: dict = {}
        _score_phase8(cfg, cfg.phase11, _get_fn(scores))
        assert "example.com" in scores
        assert scores["example.com"].breakdown["phase8"] == 15

    def test_credential_scores_correctly(self, cfg, tmp_path):
        self._write_js(tmp_path, [{
            "js_url": "https://example.com/config.js",
            "finding_type": "credential",
            "value": "user=admin, pass=secret",
        }])
        cfg.output.js_analysis_json = str(tmp_path / "js_analysis.json")
        scores: dict = {}
        _score_phase8(cfg, cfg.phase11, _get_fn(scores))
        assert scores["example.com"].breakdown["phase8"] == 15

    def test_multiple_finding_types_accumulated(self, cfg, tmp_path):
        self._write_js(tmp_path, [
            {"js_url": "https://example.com/app.js", "finding_type": "aws_key", "value": "K1"},
            {"js_url": "https://example.com/app.js", "finding_type": "jwt", "value": "eyJ..."},
        ])
        cfg.output.js_analysis_json = str(tmp_path / "js_analysis.json")
        scores: dict = {}
        _score_phase8(cfg, cfg.phase11, _get_fn(scores))
        # aws_key=15 + jwt=10 = 25
        assert scores["example.com"].breakdown["phase8"] == 25

    def test_repeated_same_type_discounted(self, cfg, tmp_path):
        self._write_js(tmp_path, [
            {"js_url": "https://example.com/a.js", "finding_type": "endpoint", "value": "/api/1"},
            {"js_url": "https://example.com/b.js", "finding_type": "endpoint", "value": "/api/2"},
            {"js_url": "https://example.com/c.js", "finding_type": "endpoint", "value": "/api/3"},
        ])
        cfg.output.js_analysis_json = str(tmp_path / "js_analysis.json")
        scores: dict = {}
        _score_phase8(cfg, cfg.phase11, _get_fn(scores))
        # First endpoint=3, then 2 extras at 20% each = 3 + 0 + 0 = 3 (int(0.6)=0 each)
        # With 3 endpoints: 3 + int(2*3*0.2)=1 = 4
        pts = scores["example.com"].breakdown["phase8"]
        assert pts >= 3   # at minimum the base score

    def test_unknown_finding_type_skipped(self, cfg, tmp_path):
        self._write_js(tmp_path, [{
            "js_url": "https://example.com/app.js",
            "finding_type": "totally_unknown_type",
            "value": "something",
        }])
        cfg.output.js_analysis_json = str(tmp_path / "js_analysis.json")
        scores: dict = {}
        _score_phase8(cfg, cfg.phase11, _get_fn(scores))
        assert "example.com" not in scores

    def test_missing_file_skipped(self, cfg, tmp_path):
        cfg.output.js_analysis_json = str(tmp_path / "no.json")
        scores: dict = {}
        _score_phase8(cfg, cfg.phase11, _get_fn(scores))
        assert scores == {}


# ===========================================================================
# _score_phase9
# ===========================================================================

class TestScorePhase9:
    def _write_takeovers(self, tmp_path: Path, takeovers: list) -> None:
        p = tmp_path / "takeovers.json"
        p.write_text(json.dumps({"takeovers": takeovers}))

    def test_high_confidence_scores_max(self, cfg, tmp_path):
        self._write_takeovers(tmp_path, [{
            "host": "sub.example.com",
            "service": "GitHub Pages",
            "confidence": 0.95,
            "method": "subzy",
        }])
        cfg.output.takeovers_json = str(tmp_path / "takeovers.json")
        scores: dict = {}
        _score_phase9(cfg, cfg.phase11, _get_fn(scores))
        assert scores["sub.example.com"].breakdown["phase9"] == 20

    def test_medium_confidence_scores_mid(self, cfg, tmp_path):
        self._write_takeovers(tmp_path, [{
            "host": "sub.example.com",
            "service": "Heroku",
            "confidence": 0.75,
            "method": "http_check",
        }])
        cfg.output.takeovers_json = str(tmp_path / "takeovers.json")
        scores: dict = {}
        _score_phase9(cfg, cfg.phase11, _get_fn(scores))
        assert scores["sub.example.com"].breakdown["phase9"] == 15

    def test_low_confidence_scores_min(self, cfg, tmp_path):
        self._write_takeovers(tmp_path, [{
            "host": "sub.example.com",
            "service": "Netlify",
            "confidence": 0.60,
            "method": "http_check",
        }])
        cfg.output.takeovers_json = str(tmp_path / "takeovers.json")
        scores: dict = {}
        _score_phase9(cfg, cfg.phase11, _get_fn(scores))
        assert scores["sub.example.com"].breakdown["phase9"] == 10

    def test_reason_includes_service_and_confidence(self, cfg, tmp_path):
        self._write_takeovers(tmp_path, [{
            "host": "sub.example.com",
            "service": "Vercel",
            "confidence": 0.90,
            "method": "nuclei",
        }])
        cfg.output.takeovers_json = str(tmp_path / "takeovers.json")
        scores: dict = {}
        _score_phase9(cfg, cfg.phase11, _get_fn(scores))
        reasons = scores["sub.example.com"].reasons
        assert any("Vercel" in r for r in reasons)

    def test_missing_file_skipped(self, cfg, tmp_path):
        cfg.output.takeovers_json = str(tmp_path / "no.json")
        scores: dict = {}
        _score_phase9(cfg, cfg.phase11, _get_fn(scores))
        assert scores == {}


# ===========================================================================
# _score_phase10
# ===========================================================================

class TestScorePhase10:
    def _write_nuclei(self, tmp_path: Path, contribs: dict, findings=None) -> None:
        p = tmp_path / "nuclei_results.json"
        p.write_text(json.dumps({
            "phase11_score_contributions": contribs,
            "findings": findings or [],
        }))

    def test_contributions_applied(self, cfg, tmp_path):
        self._write_nuclei(tmp_path, {"db.example.com": 21})
        cfg.output.nuclei_results_json = str(tmp_path / "nuclei_results.json")
        scores: dict = {}
        _score_phase10(cfg, cfg.phase11, _get_fn(scores))
        assert scores["db.example.com"].breakdown["phase10"] == 21

    def test_zero_contribution_skipped(self, cfg, tmp_path):
        self._write_nuclei(tmp_path, {"www.example.com": 0})
        cfg.output.nuclei_results_json = str(tmp_path / "nuclei_results.json")
        scores: dict = {}
        _score_phase10(cfg, cfg.phase11, _get_fn(scores))
        assert "www.example.com" not in scores

    def test_missing_file_skipped(self, cfg, tmp_path):
        cfg.output.nuclei_results_json = str(tmp_path / "no.json")
        scores: dict = {}
        _score_phase10(cfg, cfg.phase11, _get_fn(scores))
        assert scores == {}


# ===========================================================================
# run_phase11 orchestrator
# ===========================================================================

class TestPhase11Orchestrator:
    def _setup_outputs(self, tmp_path: Path, cfg: FrameworkConfig) -> None:
        cfg.output.asset_intelligence_json  = str(tmp_path / "asset_intelligence.json")
        cfg.output.sensitive_endpoints_txt  = str(tmp_path / "sensitive_endpoints.txt")
        cfg.output.js_analysis_json         = str(tmp_path / "js_analysis.json")
        cfg.output.takeovers_json           = str(tmp_path / "takeovers.json")
        cfg.output.nuclei_results_json      = str(tmp_path / "nuclei_results.json")
        cfg.output.high_value_targets_json  = str(tmp_path / "high_value_targets.json")
        cfg.database.path                   = str(tmp_path / "recon.db")

    def _write_p4(self, tmp_path: Path, findings: list) -> None:
        (tmp_path / "asset_intelligence.json").write_text(
            json.dumps({"findings": findings})
        )

    def _write_p9(self, tmp_path: Path, takeovers: list) -> None:
        (tmp_path / "takeovers.json").write_text(
            json.dumps({"takeovers": takeovers})
        )

    def _write_p10(self, tmp_path: Path, contribs: dict) -> None:
        (tmp_path / "nuclei_results.json").write_text(
            json.dumps({"phase11_score_contributions": contribs, "findings": []})
        )

    @pytest.mark.asyncio
    async def test_writes_high_value_targets_json(self, cfg: FrameworkConfig, tmp_path: Path):
        self._setup_outputs(tmp_path, cfg)
        reset_config()
        self._write_p4(tmp_path, [{
            "host": "jenkins.example.com",
            "risk_level": "CRITICAL",
            "tags": ["jenkins"],
            "reasons": ["Jenkins CI"],
        }])

        results = await run_phase11("example.com", cfg)

        out = tmp_path / "high_value_targets.json"
        assert out.exists()
        data = json.loads(out.read_text())
        assert "targets" in data
        assert "meta" in data

    @pytest.mark.asyncio
    async def test_ranked_by_score_descending(self, cfg: FrameworkConfig, tmp_path: Path):
        self._setup_outputs(tmp_path, cfg)
        reset_config()
        self._write_p4(tmp_path, [
            {"host": "low.example.com",  "risk_level": "LOW",      "tags": [], "reasons": ["r"]},
            {"host": "high.example.com", "risk_level": "HIGH",     "tags": [], "reasons": ["r"]},
            {"host": "crit.example.com", "risk_level": "CRITICAL", "tags": [], "reasons": ["r"]},
        ])

        results = await run_phase11("example.com", cfg)

        scores = [r.total for r in results]
        assert scores == sorted(scores, reverse=True)

    @pytest.mark.asyncio
    async def test_zero_score_hosts_excluded(self, cfg: FrameworkConfig, tmp_path: Path):
        self._setup_outputs(tmp_path, cfg)
        reset_config()
        # Write empty data — no hosts score any points
        (tmp_path / "asset_intelligence.json").write_text(json.dumps({"findings": []}))

        results = await run_phase11("example.com", cfg)
        assert results == []

    @pytest.mark.asyncio
    async def test_multi_phase_scores_merged(self, cfg: FrameworkConfig, tmp_path: Path):
        self._setup_outputs(tmp_path, cfg)
        reset_config()

        # Phase 4: HIGH → +15
        self._write_p4(tmp_path, [{
            "host": "admin.example.com",
            "risk_level": "HIGH",
            "tags": ["admin"],
            "reasons": ["Admin panel"],
        }])
        # Phase 9: high conf → +20
        self._write_p9(tmp_path, [{
            "host": "admin.example.com",
            "service": "GitHub Pages",
            "confidence": 0.90,
            "method": "subzy",
        }])
        # Phase 10: +10
        self._write_p10(tmp_path, {"admin.example.com": 10})

        results = await run_phase11("example.com", cfg)
        host_scores = {r.host: r for r in results}

        assert "admin.example.com" in host_scores
        hs = host_scores["admin.example.com"]
        assert hs.total == 45   # 15 + 20 + 10
        assert hs.risk == RiskLevel.CRITICAL

    @pytest.mark.asyncio
    async def test_source_breakdown_in_output(self, cfg: FrameworkConfig, tmp_path: Path):
        self._setup_outputs(tmp_path, cfg)
        reset_config()
        self._write_p4(tmp_path, [{
            "host": "jenkins.example.com",
            "risk_level": "CRITICAL",
            "tags": [],
            "reasons": ["Jenkins"],
        }])
        self._write_p10(tmp_path, {"jenkins.example.com": 15})

        await run_phase11("example.com", cfg)

        data = json.loads((tmp_path / "high_value_targets.json").read_text())
        target = data["targets"][0]
        assert "source_breakdown" in target
        assert "phase4" in target["source_breakdown"]
        assert "phase10" in target["source_breakdown"]

    @pytest.mark.asyncio
    async def test_max_targets_cap(self, cfg: FrameworkConfig, tmp_path: Path):
        cfg.phase11.max_targets = 2
        self._setup_outputs(tmp_path, cfg)
        reset_config()
        self._write_p4(tmp_path, [
            {"host": f"host{i}.example.com", "risk_level": "HIGH",
             "tags": [], "reasons": ["r"]}
            for i in range(5)
        ])

        results = await run_phase11("example.com", cfg)
        assert len(results) <= 2

    @pytest.mark.asyncio
    async def test_risk_distribution_in_json(self, cfg: FrameworkConfig, tmp_path: Path):
        self._setup_outputs(tmp_path, cfg)
        reset_config()
        self._write_p4(tmp_path, [
            {"host": "crit.example.com",   "risk_level": "CRITICAL", "tags": [], "reasons": ["r"]},
            {"host": "high.example.com",   "risk_level": "HIGH",     "tags": [], "reasons": ["r"]},
            {"host": "medium.example.com", "risk_level": "MEDIUM",   "tags": [], "reasons": ["r"]},
        ])
        # p4_critical=20 → need +11 to reach tier_critical=30
        # p4_high=15     → need +6 to reach tier_high=20
        self._write_p10(tmp_path, {
            "crit.example.com": 11,
            "high.example.com": 6,
        })

        await run_phase11("example.com", cfg)

        data = json.loads((tmp_path / "high_value_targets.json").read_text())
        dist = data["meta"]["risk_distribution"]
        assert dist.get("CRITICAL", 0) >= 1
        assert dist.get("HIGH", 0) >= 1
