# conftest.py — shared fixtures for all ReconFramework tests

import asyncio
import pytest
import pytest_asyncio
from pathlib import Path
import tempfile

from core.config import load_config, reset_config, FrameworkConfig
from core.database import Database


# ---------------------------------------------------------------------------
# Event loop
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session")
def event_loop_policy():
    return asyncio.DefaultEventLoopPolicy()


# ---------------------------------------------------------------------------
# Isolated temp directory per test
# ---------------------------------------------------------------------------

@pytest.fixture()
def tmp_output(tmp_path: Path) -> Path:
    """Return a temporary output directory."""
    out = tmp_path / "output"
    out.mkdir()
    return out


# ---------------------------------------------------------------------------
# Config fixture with temp paths
# ---------------------------------------------------------------------------

@pytest.fixture()
def test_config(tmp_output: Path) -> FrameworkConfig:
    reset_config()
    cfg = load_config("config.yaml")
    # Override all paths to use temp dir
    cfg.output.base_dir = str(tmp_output)
    cfg.output.subdomains_txt = str(tmp_output / "subdomains.txt")
    cfg.output.subdomains_json = str(tmp_output / "subdomains.json")
    cfg.database.path = str(tmp_output / "test.db")
    cfg.logging.file = str(tmp_output / "recon.log")
    cfg.logging.audit_file = str(tmp_output / "audit.log")
    return cfg


# ---------------------------------------------------------------------------
# Database fixture
# ---------------------------------------------------------------------------

@pytest_asyncio.fixture()
async def test_db(test_config: FrameworkConfig) -> Database:
    db = Database(test_config.database.path)
    await db.connect()
    yield db
    await db.close()
