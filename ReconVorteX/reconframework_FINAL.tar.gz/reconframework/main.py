"""
main.py
=======
ReconFramework CLI entry-point.

Commands:
    recon phase1 <domain>   — Phase 1: Subdomain Discovery
    recon phase2 <domain>   — Phase 2: Live Host Discovery
    recon run    <domain>   — Full pipeline (all completed phases)
    recon db     <domain>   — Query the local database
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel

from core.config import get_config
from core.logger import setup_logging

app = typer.Typer(
    name="recon",
    help="[bold cyan]ReconFramework[/bold cyan] — Professional Bug Bounty Reconnaissance Platform",
    rich_markup_mode="rich",
    add_completion=False,
)

console = Console()


# ---------------------------------------------------------------------------
# Bootstrap
# ---------------------------------------------------------------------------

def _bootstrap(config_path: str, debug: bool) -> None:
    """Load config and initialise logging."""
    cfg = get_config(config_path)
    level = "DEBUG" if debug else cfg.logging.level
    setup_logging(
        level=level,
        log_file=cfg.logging.file,
        audit_file=cfg.logging.audit_file,
        fmt=cfg.logging.format,
    )


# ---------------------------------------------------------------------------
# phase1
# ---------------------------------------------------------------------------

@app.command()
def phase1(
    domain: str  = typer.Argument(..., help="Target domain, e.g. example.com"),
    config: str  = typer.Option("config.yaml", "--config", "-c", help="Path to config.yaml"),
    debug: bool  = typer.Option(False, "--debug", "-d", help="Enable debug logging"),
) -> None:
    """
    [bold]Phase 1[/bold] — Multi-Source Subdomain Discovery.

    Runs all configured discovery plugins (Subfinder, crt.sh, AlienVault, …)
    in parallel and writes results to [cyan]output/[/cyan].
    """
    _bootstrap(config, debug)

    async def _run() -> None:
        from phases.phase1_discovery import Phase1Discovery
        cfg = get_config(config)
        result = await Phase1Discovery(cfg).run(domain)
        if result.errors:
            console.print(f"[yellow]Completed with {len(result.errors)} error(s).[/yellow]")
        raise typer.Exit(code=0)

    asyncio.run(_run())


# ---------------------------------------------------------------------------
# phase2
# ---------------------------------------------------------------------------

@app.command()
def phase2(
    domain: str  = typer.Argument(..., help="Target domain, e.g. example.com"),
    config: str  = typer.Option("config.yaml", "--config", "-c", help="Path to config.yaml"),
    debug: bool  = typer.Option(False, "--debug", "-d", help="Enable debug logging"),
) -> None:
    """
    [bold]Phase 2[/bold] — Live Host Discovery.

    Probes every subdomain discovered in Phase 1 via httpx (binary preferred)
    or aiohttp (pure-Python fallback). Records status codes, titles, redirect
    chains, IPs, and detected technologies.

    Reads  : [cyan]output/subdomains.json[/cyan]
    Writes : [cyan]output/live_hosts.json[/cyan]
    """
    _bootstrap(config, debug)

    async def _run() -> None:
        from phases.phase2_live_hosts import run_phase2
        cfg = get_config(config)
        live = await run_phase2(domain, cfg)
        console.print(
            Panel(
                f"[bold green]{len(live)}[/bold green] live hosts written to "
                f"[cyan]{cfg.output.live_hosts_json}[/cyan]",
                title="Phase 2 Complete",
                border_style="cyan",
            )
        )
        raise typer.Exit(code=0)

    asyncio.run(_run())


# ---------------------------------------------------------------------------
# run (full pipeline)
# ---------------------------------------------------------------------------

@app.command()
def phase3(
    domain: str  = typer.Argument(..., help="Target domain, e.g. example.com"),
    config: str  = typer.Option("config.yaml", "--config", "-c", help="Path to config.yaml"),
    debug: bool  = typer.Option(False, "--debug", "-d", help="Enable debug logging"),
) -> None:
    """
    [bold]Phase 3[/bold] — Technology Intelligence.

    Re-probes every live host from Phase 2, parses response headers and HTML
    to fingerprint CMS, frameworks, admin panels, CI/CD tools, and more.
    Phase 2 tech hints are used as a starting point and enriched.

    Reads  : [cyan]output/live_hosts.json[/cyan]
    Writes : [cyan]output/technologies.json[/cyan]
    """
    _bootstrap(config, debug)

    async def _run() -> None:
        from phases.phase3_technology import run_phase3
        cfg = get_config(config)
        results = await run_phase3(domain, cfg)
        console.print(
            Panel(
                f"[bold green]{len(results)}[/bold green] hosts fingerprinted → "
                f"[cyan]{cfg.output.technologies_json}[/cyan]",
                title="Phase 3 Complete",
                border_style="cyan",
            )
        )
        raise typer.Exit(code=0)

    asyncio.run(_run())



@app.command()
def run(
    domain:      str  = typer.Argument(..., help="Target domain, e.g. example.com"),
    config:      str  = typer.Option("config.yaml", "--config", "-c"),
    phases_list: str  = typer.Option("all", "--phases", "-p",
                                      help="Comma-separated phase numbers or 'all'. E.g. --phases 1,2"),
    debug:       bool = typer.Option(False, "--debug", "-d"),
) -> None:
    """
    [bold]Full Pipeline[/bold] — run all (or selected) completed phases sequentially.

    Example: [cyan]recon run example.com --phases 1,2[/cyan]
    """
    _bootstrap(config, debug)
    cfg = get_config(config)

    # Resolve which phases to run
    if phases_list.lower() == "all":
        selected = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11}
    else:
        try:
            selected = {int(p.strip()) for p in phases_list.split(",")}
        except ValueError:
            console.print("[red]--phases must be comma-separated integers or 'all'[/red]")
            raise typer.Exit(1)

    console.print(
        Panel(
            f"[bold]Target:[/bold] [cyan]{domain}[/cyan]\n"
            f"[bold]Phases:[/bold] {sorted(selected)}\n"
            f"[bold]Config:[/bold] {config}",
            title="[bold cyan]ReconFramework[/bold cyan]",
            border_style="cyan",
        )
    )

    async def _run() -> None:
        from phases.phase1_discovery import Phase1Discovery
        from phases.phase2_live_hosts import run_phase2
        from phases.phase3_technology import run_phase3
        from phases.phase4_intelligence import run_phase4

        subdomains: list[str] = []
        p6 = None

        if 1 in selected:
            result = await Phase1Discovery(cfg).run(domain)
            subdomains = [s.host for s in result.subdomains]
            console.print(f"  ✔ Phase 1: [green]{result.unique_discovered}[/green] unique subdomains")

        if 2 in selected:
            live = await run_phase2(domain, cfg, subdomains=subdomains or None)
            console.print(f"  ✔ Phase 2: [green]{len(live)}[/green] live hosts")

        if 3 in selected:
            techs = await run_phase3(domain, cfg)
            console.print(f"  ✔ Phase 3: [green]{len(techs)}[/green] hosts fingerprinted")

        if 4 in selected:
            intel = await run_phase4(domain, cfg)
            critical = sum(1 for r in intel if r.risk_level.value == "CRITICAL")
            console.print(
                f"  ✔ Phase 4: [green]{len(intel)}[/green] assets flagged "
                f"[bold red]({critical} CRITICAL)[/bold red]"
            )

        if 6 in selected:
            from phases.phase6_urls import run_phase6
            p6 = await run_phase6(domain, cfg)
            console.print(f"  ✔ Phase 6: [green]{p6.total_kept:,}[/green] URLs collected")

        if 5 in selected:
            from phases.phase5_screenshots import run_phase5
            p5 = await run_phase5(domain, cfg)
            console.print(
                f"  ✔ Phase 5: [green]{p5.total_success}[/green] screenshots"
                + (f" → [cyan]{p5.gallery_path}[/cyan]" if p5.gallery_path else "")
            )

        if 7 in selected:
            from phases.phase7_endpoints import run_phase7
            p7_urls: list[str] | None = p6.urls if p6 else None
            p7 = await run_phase7(domain, cfg, urls=p7_urls)
            critical7 = sum(1 for f in p7 if f.severity.value == "CRITICAL")
            console.print(
                f"  ✔ Phase 7: [green]{len(p7)}[/green] sensitive endpoints "
                f"[bold red]({critical7} CRITICAL)[/bold red]"
            )

        if 8 in selected:
            from phases.phase8_js import run_phase8
            p8_urls = p6.urls if p6 else None
            p8 = await run_phase8(domain, cfg, phase6_urls=p8_urls)
            hv8 = sum(1 for f in p8
                      if f.finding_type in {"aws_key","credential","jwt","secret_assignment","secret_entropy","internal_url"})
            console.print(
                f"  ✔ Phase 8: [green]{len(p8)}[/green] JS findings "
                f"[bold red]({hv8} high-value)[/bold red]"
            )

        if 9 in selected:
            from phases.phase9_takeover import run_phase9
            p1_hosts: list[str] | None = subdomains or None
            p9 = await run_phase9(domain, cfg, subdomains=p1_hosts)
            high9 = sum(1 for f in p9 if f.confidence >= 0.85)
            console.print(
                f"  ✔ Phase 9: [green]{len(p9)}[/green] takeover candidates "
                f"[bold red]({high9} high-confidence)[/bold red]"
            )

        if 10 in selected:
            from phases.phase10_scan import run_phase10
            p10 = await run_phase10(domain, cfg)
            crit10 = sum(1 for f in p10 if f.severity == "critical")
            high10 = sum(1 for f in p10 if f.severity == "high")
            console.print(
                f"  ✔ Phase 10: [green]{len(p10)}[/green] findings "
                f"[bold red]({crit10} CRITICAL  {high10} HIGH)[/bold red]"
            )

        if 11 in selected:
            from phases.phase11_scoring import run_phase11
            p11 = await run_phase11(domain, cfg)
            crit11 = sum(1 for h in p11 if h.risk.value == "CRITICAL")
            high11 = sum(1 for h in p11 if h.risk.value == "HIGH")
            console.print(
                f"  ✔ Phase 11: [green]{len(p11)}[/green] high-value targets ranked "
                f"[bold red]({crit11} CRITICAL  {high11} HIGH)[/bold red]"
            )

    asyncio.run(_run())


@app.command()
def phase11(
    domain: str  = typer.Argument(..., help="Target domain, e.g. example.com"),
    config: str  = typer.Option("config.yaml", "--config", "-c"),
    debug:  bool = typer.Option(False, "--debug", "-d"),
) -> None:
    """
    [bold]Phase 11[/bold] — Risk Scoring Engine.

    Aggregates findings from Phases 4, 7, 8, 9, and 10 into a single
    composite score per host. Assigns CRITICAL / HIGH / MEDIUM / LOW
    tiers based on configurable thresholds and ranks all targets.

    Reads  : [cyan]output/asset_intelligence.json[/cyan]
             [cyan]output/sensitive_endpoints.json[/cyan]
             [cyan]output/js_analysis.json[/cyan]
             [cyan]output/takeovers.json[/cyan]
             [cyan]output/nuclei_results.json[/cyan]
    Writes : [cyan]output/high_value_targets.json[/cyan]
    """
    _bootstrap(config, debug)

    async def _run() -> None:
        from phases.phase11_scoring import run_phase11
        cfg      = get_config(config)
        results  = await run_phase11(domain, cfg)
        critical = sum(1 for h in results if h.risk.value == "CRITICAL")
        high     = sum(1 for h in results if h.risk.value == "HIGH")
        console.print(
            Panel(
                f"[bold green]{len(results)}[/bold green] high-value targets ranked\n"
                f"[bold red]{critical} CRITICAL  {high} HIGH[/bold red]\n"
                f"→ [cyan]{cfg.output.high_value_targets_json}[/cyan]",
                title="Phase 11 Complete ✅ — Pipeline Finished",
                border_style="cyan",
            )
        )
        raise typer.Exit(code=0)

    asyncio.run(_run())


@app.command()
def phase10(
    domain: str  = typer.Argument(..., help="Target domain, e.g. example.com"),
    config: str  = typer.Option("config.yaml", "--config", "-c"),
    debug:  bool = typer.Option(False, "--debug", "-d"),
) -> None:
    """
    [bold]Phase 10[/bold] — Safe Vulnerability Scanning.

    Runs Nuclei safe templates (misconfig, exposure, exposed-panels, CVEs,
    security-headers) against all Phase 2 live hosts. A pure-Python header
    checker runs in parallel as a permanent fallback regardless of Nuclei
    availability, covering HSTS, CSP, CORS, clickjacking, cookie flags,
    and technology disclosure.

    Reads  : [cyan]output/live_hosts.json[/cyan]
    Writes : [cyan]output/nuclei_results.json[/cyan]
    """
    _bootstrap(config, debug)

    async def _run() -> None:
        from phases.phase10_scan import run_phase10
        cfg      = get_config(config)
        results  = await run_phase10(domain, cfg)
        critical = sum(1 for f in results if f.severity == "critical")
        high     = sum(1 for f in results if f.severity == "high")
        console.print(
            Panel(
                f"[bold green]{len(results)}[/bold green] findings\n"
                f"[bold red]{critical} CRITICAL  {high} HIGH[/bold red]\n"
                f"→ [cyan]{cfg.output.nuclei_results_json}[/cyan]",
                title="Phase 10 Complete",
                border_style="cyan",
            )
        )
        raise typer.Exit(code=0)

    asyncio.run(_run())


@app.command()
def phase9(
    domain: str  = typer.Argument(..., help="Target domain, e.g. example.com"),
    config: str  = typer.Option("config.yaml", "--config", "-c"),
    debug:  bool = typer.Option(False, "--debug", "-d"),
) -> None:
    """
    [bold]Phase 9[/bold] — Subdomain Takeover Detection.

    Runs three methods in parallel:
      • Pure-Python HTTP fingerprint checker (always on)
      • Subzy binary               (if installed)
      • Nuclei takeover templates  (if installed)

    Reads  : [cyan]output/subdomains.json[/cyan]
    Writes : [cyan]output/takeovers.json[/cyan]
    """
    _bootstrap(config, debug)

    async def _run() -> None:
        from phases.phase9_takeover import run_phase9
        cfg      = get_config(config)
        findings = await run_phase9(domain, cfg)
        high     = sum(1 for f in findings if f.confidence >= 0.85)
        console.print(
            Panel(
                f"[bold green]{len(findings)}[/bold green] takeover candidates found\n"
                f"[bold red]{high}[/bold red] high-confidence (≥ 0.85)\n"
                f"→ [cyan]{cfg.output.takeovers_json}[/cyan]",
                title="Phase 9 Complete",
                border_style="cyan",
            )
        )
        raise typer.Exit(code=0)

    asyncio.run(_run())


@app.command()
def phase8(
    domain: str  = typer.Argument(..., help="Target domain, e.g. example.com"),
    config: str  = typer.Option("config.yaml", "--config", "-c"),
    debug:  bool = typer.Option(False, "--debug", "-d"),
) -> None:
    """
    [bold]Phase 8[/bold] — JavaScript Intelligence.

    Discovers JS files from Phase 6 URL list + Phase 2 live host script tags.
    Extracts endpoints, API routes, AWS keys, GraphQL ops, JWT tokens,
    internal URLs, source maps, secrets (regex + entropy + AST-like analysis).

    Reads  : [cyan]output/urls.json[/cyan]  +  [cyan]output/live_hosts.json[/cyan]
    Writes : [cyan]output/js_analysis.json[/cyan]
    """
    _bootstrap(config, debug)

    async def _run() -> None:
        from phases.phase8_js import run_phase8
        cfg     = get_config(config)
        results = await run_phase8(domain, cfg)
        hv      = sum(1 for f in results
                      if f.finding_type in {"aws_key","credential","jwt",
                                            "secret_assignment","secret_entropy","internal_url"})
        console.print(
            Panel(
                f"[bold green]{len(results)}[/bold green] findings from JS analysis\n"
                f"[bold red]{hv}[/bold red] high-value (secrets/credentials/internal URLs)\n"
                f"→ [cyan]{cfg.output.js_analysis_json}[/cyan]",
                title="Phase 8 Complete",
                border_style="cyan",
            )
        )
        raise typer.Exit(code=0)

    asyncio.run(_run())


@app.command()
def phase7(
    domain: str  = typer.Argument(..., help="Target domain, e.g. example.com"),
    config: str  = typer.Option("config.yaml", "--config", "-c"),
    debug:  bool = typer.Option(False, "--debug", "-d"),
) -> None:
    """
    [bold]Phase 7[/bold] — Sensitive Endpoint Discovery.

    Pattern-matches the Phase 6 URL list against 50+ sensitive endpoint
    signatures across 15 categories (secrets, source control, API docs,
    admin panels, CI/CD, JWT, package managers, framework internals…).
    Zero network requests — fast offline analysis.

    Reads  : [cyan]output/urls.json[/cyan]
    Writes : [cyan]output/sensitive_endpoints.txt[/cyan]  +  [cyan]output/sensitive_endpoints.json[/cyan]
    """
    _bootstrap(config, debug)

    async def _run() -> None:
        from phases.phase7_endpoints import run_phase7
        cfg     = get_config(config)
        results = await run_phase7(domain, cfg)
        critical = sum(1 for f in results if f.severity.value == "CRITICAL")
        high     = sum(1 for f in results if f.severity.value == "HIGH")
        console.print(
            Panel(
                f"[bold green]{len(results)}[/bold green] sensitive endpoints found\n"
                f"[bold red]{critical} CRITICAL[/bold red]  "
                f"[red]{high} HIGH[/red]\n"
                f"→ [cyan]{cfg.output.sensitive_endpoints_txt}[/cyan]",
                title="Phase 7 Complete",
                border_style="cyan",
            )
        )
        raise typer.Exit(code=0)

    asyncio.run(_run())


@app.command()
def phase5(
    domain: str  = typer.Argument(..., help="Target domain, e.g. example.com"),
    config: str  = typer.Option("config.yaml", "--config", "-c"),
    debug:  bool = typer.Option(False, "--debug", "-d"),
) -> None:
    """
    [bold]Phase 5[/bold] — Screenshot Collection.

    Prioritises CRITICAL/HIGH assets from Phase 4, then fills remaining
    slots from Phase 2 live hosts up to [cyan]max_hosts[/cyan].
    Runs Gowitness and generates a self-contained HTML gallery.

    Reads  : [cyan]output/asset_intelligence.json[/cyan]  +  [cyan]output/live_hosts.json[/cyan]
    Writes : [cyan]output/screenshots/*.png[/cyan]  +  [cyan]output/screenshots/index.html[/cyan]
    """
    _bootstrap(config, debug)

    async def _run() -> None:
        from phases.phase5_screenshots import run_phase5
        cfg    = get_config(config)
        result = await run_phase5(domain, cfg)
        console.print(
            Panel(
                f"[bold green]{result.total_success}[/bold green] screenshots captured\n"
                + (f"Gallery → [cyan]{result.gallery_path}[/cyan]"
                   if result.gallery_path else "[dim]No gallery (no screenshots)[/dim]"),
                title="Phase 5 Complete",
                border_style="cyan",
            )
        )
        raise typer.Exit(code=0)

    asyncio.run(_run())


@app.command()
def phase6(
    domain: str  = typer.Argument(..., help="Target domain, e.g. example.com"),
    config: str  = typer.Option("config.yaml", "--config", "-c"),
    debug:  bool = typer.Option(False, "--debug", "-d"),
) -> None:
    """
    [bold]Phase 6[/bold] — Historical URL Collection.

    Queries GAU binary, Wayback Machine CDX API, and Common Crawl in
    parallel. Smart-filters results to security-relevant URLs only
    (interesting extensions, parameter-bearing, sensitive path segments).

    Writes : [cyan]output/urls.txt[/cyan]  +  [cyan]output/urls.json[/cyan]
    """
    _bootstrap(config, debug)

    async def _run() -> None:
        from phases.phase6_urls import run_phase6
        cfg = get_config(config)
        result = await run_phase6(domain, cfg)
        console.print(
            Panel(
                f"[bold green]{result.total_kept:,}[/bold green] URLs collected "
                f"([dim]from {result.total_raw:,} raw[/dim])\n"
                f"→ [cyan]{cfg.output.urls_txt}[/cyan]",
                title="Phase 6 Complete",
                border_style="cyan",
            )
        )
        raise typer.Exit(code=0)

    asyncio.run(_run())


# ---------------------------------------------------------------------------
# phase4 — standalone command
# ---------------------------------------------------------------------------

@app.command()
def phase4(
    domain: str  = typer.Argument(..., help="Target domain, e.g. example.com"),
    config: str  = typer.Option("config.yaml", "--config", "-c"),
    debug:  bool = typer.Option(False, "--debug", "-d"),
) -> None:
    """
    [bold]Phase 4[/bold] — Asset Intelligence Engine.

    Analyses every live host across hostname patterns, page titles,
    detected technologies, and HTTP behaviour to classify risk level
    (CRITICAL → LOW), assign confidence scores, and tag each asset.

    Reads  : [cyan]output/live_hosts.json[/cyan]  +  [cyan]output/technologies.json[/cyan]
    Writes : [cyan]output/asset_intelligence.json[/cyan]
    """
    _bootstrap(config, debug)

    async def _run() -> None:
        from phases.phase4_intelligence import run_phase4
        cfg = get_config(config)
        results  = await run_phase4(domain, cfg)
        critical = sum(1 for r in results if r.risk_level.value == "CRITICAL")
        high     = sum(1 for r in results if r.risk_level.value == "HIGH")
        console.print(
            Panel(
                f"[bold green]{len(results)}[/bold green] assets flagged  "
                f"[bold red]({critical} CRITICAL  {high} HIGH)[/bold red]\n"
                f"→ [cyan]{cfg.output.asset_intelligence_json}[/cyan]",
                title="Phase 4 Complete",
                border_style="cyan",
            )
        )
        raise typer.Exit(code=0)

    asyncio.run(_run())


# ---------------------------------------------------------------------------
# db — quick database query
# ---------------------------------------------------------------------------

@app.command()
def db(
    domain: str = typer.Argument(..., help="Domain to query"),
    table:  str = typer.Option("subdomains", "--table", "-t",
                                help="Table to query: subdomains | live_hosts"),
    config: str = typer.Option("config.yaml", "--config", "-c"),
) -> None:
    """Query local SQLite database for discovered assets."""
    _bootstrap(config, False)

    async def _query() -> None:
        from core.database import Database
        cfg = get_config(config)
        async with Database(cfg.database.path) as database:
            if table == "subdomains":
                rows = await database.get_subdomains(domain)
                console.print(f"\n[bold cyan]Subdomains[/bold cyan] for [bold]{domain}[/bold]: {len(rows)}\n")
                for s in sorted(rows, key=lambda x: x.host):
                    srcs = ", ".join(s.sources)
                    console.print(f"  [bright_white]{s.host}[/bright_white]  [dim]{srcs}[/dim]")
            else:
                console.print(f"[yellow]Table '{table}' query not yet implemented.[/yellow]")

    asyncio.run(_query())


# ---------------------------------------------------------------------------
# Entry
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    app()
