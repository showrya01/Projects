"""
core/config.py
==============
Centralised configuration loader.

Priority (highest → lowest):
  1. Environment variables (RF_ prefix)
  2. config.yaml
  3. Hard-coded defaults
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _env(key: str, default: Any = None) -> Any:
    """Read an environment variable with the RF_ prefix."""
    return os.environ.get(f"RF_{key.upper()}", default)


# ---------------------------------------------------------------------------
# Sub-configs (plain dataclasses for speed + clarity)
# ---------------------------------------------------------------------------

@dataclass
class OutputConfig:
    base_dir: str = "output"
    subdomains_txt: str = "output/subdomains.txt"
    subdomains_json: str = "output/subdomains.json"
    live_hosts_json: str = "output/live_hosts.json"
    technologies_json: str = "output/technologies.json"
    asset_intelligence_json: str = "output/asset_intelligence.json"
    screenshots_dir: str = "output/screenshots"
    urls_txt: str = "output/urls.txt"
    sensitive_endpoints_txt: str = "output/sensitive_endpoints.txt"
    js_analysis_json: str = "output/js_analysis.json"
    takeovers_json: str = "output/takeovers.json"
    nuclei_results_json: str = "output/nuclei_results.json"
    high_value_targets_json: str = "output/high_value_targets.json"
    report_html: str = "output/report.html"


@dataclass
class DatabaseConfig:
    path: str = "output/recon.db"


@dataclass
class LoggingConfig:
    level: str = "INFO"
    file: str = "output/recon.log"
    audit_file: str = "output/audit.log"
    format: str = "json"   # json | console


@dataclass
class Phase1Config:
    # Tool binaries
    subfinder_bin: str = "subfinder"
    amass_bin: str = "amass"
    assetfinder_bin: str = "assetfinder"
    findomain_bin: str = "findomain"

    # Passive HTTP URLs
    crtsh_url: str = "https://crt.sh/?q={domain}&output=json"
    alienvault_url: str = "https://otx.alienvault.com/api/v1/indicators/domain/{domain}/passive_dns"
    chaos_url: str = "https://chaos-data.projectdiscovery.io/{domain}.txt"
    hackertarget_url: str = "https://api.hackertarget.com/hostsearch/?q={domain}"
    rapiddns_url: str = "https://rapiddns.io/subdomain/{domain}?full=1"

    # API Keys
    chaos_key: str = field(default_factory=lambda: _env("CHAOS_KEY", ""))

    # Concurrency / timeouts
    max_concurrent_tools: int = 4
    max_concurrent_http: int = 10
    http_timeout: int = 30
    tool_timeout: int = 300

    # Retry
    retry_attempts: int = 3
    retry_wait_min: int = 1
    retry_wait_max: int = 5

    sources: list[str] = field(default_factory=lambda: [
        "subfinder", "amass", "assetfinder", "findomain",
        "crtsh", "alienvault", "chaos", "hackertarget", "rapiddns",
    ])


@dataclass
class Phase2Config:
    # Tool binary
    httpx_bin: str = "httpx"

    # Concurrency / timeouts
    concurrency: int = 150
    timeout_s: int = 10
    max_redirects: int = 5

    # Probing
    probe_schemes: list[str] = field(default_factory=lambda: ["https", "http"])
    user_agent: str = "Mozilla/5.0 (compatible; ReconFramework/1.0)"

    # httpx binary extra flags
    httpx_extra_flags: list[str] = field(default_factory=lambda: [
        "-title", "-tech-detect", "-ip", "-cdn",
        "-status-code", "-web-server", "-content-length",
        "-follow-redirects",
    ])

    # Filters
    exclude_status_codes: list[int] = field(default_factory=lambda: [400, 502, 503])
    include_failed: bool = False


@dataclass
class Phase2Config:
    # Binary
    httpx_bin: str = "httpx"

    # Concurrency / timeouts
    concurrency: int = 150
    timeout_s: int = 10

    # Redirect policy
    max_redirects: int = 5
    follow_redirects: bool = True

    # Protocol probing
    probe_http: bool = True
    probe_https: bool = True

    # httpx binary flags
    httpx_flags: list[str] = field(default_factory=lambda: [
        "-title", "-tech-detect", "-status-code",
        "-content-length", "-web-server", "-ip",
        "-follow-redirects", "-random-agent",
    ])

    # aiohttp fallback
    fallback_user_agent: str = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    )
    max_body_bytes: int = 65536

    # Status codes treated as "live"
    live_status_codes: list[int] = field(default_factory=lambda: [
        200, 201, 204,
        301, 302, 303, 307, 308,
        400, 401, 403, 404, 405,
        500, 502, 503,
    ])

    # Retry (fallback only)
    retry_attempts: int = 2
    retry_wait_min: float = 0.5
    retry_wait_max: float = 2.0


@dataclass
class Phase11Config:
    # Risk tier thresholds
    tier_critical: int = 30
    tier_high:     int = 20
    tier_medium:   int = 10
    tier_low:      int = 5

    # Phase 4 (Asset Intelligence) contributions
    p4_critical: int = 20
    p4_high:     int = 15
    p4_medium:   int = 8
    p4_low:      int = 3

    # Phase 8 (JS Intelligence) per-type contributions
    p8_aws_key:           int = 15
    p8_credential:        int = 15
    p8_jwt:               int = 10
    p8_secret_assignment: int = 10
    p8_secret_entropy:    int = 8
    p8_internal_url:      int = 8
    p8_source_map:        int = 5
    p8_graphql:           int = 5
    p8_endpoint:          int = 3
    p8_api_route:         int = 3
    p8_package_ref:       int = 1
    p8_commented_code:    int = 4

    # Phase 9 (Takeover) by confidence band
    p9_high_conf: int = 20   # >= 0.85
    p9_med_conf:  int = 15   # >= 0.65
    p9_low_conf:  int = 10   # < 0.65

    max_targets: int = 0     # 0 = unlimited


@dataclass
class Phase10Config:
    # Nuclei
    nuclei_bin:      str = "nuclei"
    nuclei_tags:     str = "misconfig,exposure,exposed-panels,cve,security-headers,tech"
    nuclei_severity: str = "info,low,medium,high,critical"

    # Concurrency
    concurrency:  int = 50
    timeout_s:    int = 15
    tool_timeout: int = 600

    # Python header checker
    check_headers:    bool = True
    header_timeout_s: int  = 10
    max_body_bytes:   int  = 32_768

    # Phase 11 score weights
    score_critical: int = 15
    score_high:     int = 10
    score_medium:   int = 6
    score_low:      int = 3
    score_info:     int = 1

    user_agent: str = (
        "Mozilla/5.0 (compatible; ReconFramework/1.0; "
        "+https://github.com/reconframework)"
    )


@dataclass
class Phase9Config:
    # Binaries
    subzy_bin:   str = "subzy"
    nuclei_bin:  str = "nuclei"

    # Concurrency
    concurrency: int = 50
    timeout_s:   int = 10
    tool_timeout: int = 300

    # Nuclei
    nuclei_takeover_tags: str = "takeover"
    nuclei_severity:      str = "info,low,medium,high,critical"

    # HTTP checker
    check_http_body: bool = True
    user_agent: str = "Mozilla/5.0 (compatible; ReconFramework/1.0)"

    # Confidence levels (read-only reference — set in code)
    conf_cname_only:   float = 0.60
    conf_cname_body:   float = 0.90
    conf_subzy:        float = 0.95
    conf_nuclei:       float = 0.97


@dataclass
class Phase8Config:
    # Fetching
    concurrency:           int   = 20
    timeout_s:             int   = 15
    max_js_size_bytes:     int   = 2_097_152   # 2 MB
    max_js_files:          int   = 300
    # Entropy
    entropy_threshold:     float = 4.5
    min_secret_length:     int   = 20
    max_secret_length:     int   = 200
    # Discovery
    scrape_live_hosts:     bool  = True
    max_live_hosts_to_scrape: int = 100
    user_agent: str = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    )


@dataclass
class Phase7Config:
    min_severity:   str   = "LOW"
    max_findings:   int   = 0       # 0 = unlimited
    feed_phase11:   bool  = True
    score_critical: int   = 10
    score_high:     int   = 7
    score_medium:   int   = 4
    score_low:      int   = 2


@dataclass
class Phase5Config:
    # Binary
    gowitness_bin: str = "gowitness"

    # Output
    output_dir:   str = "output/screenshots"
    gallery_file: str = "output/screenshots/index.html"
    gallery_title: str = "ReconFramework — Screenshot Gallery"
    thumbnails_per_row: int = 4

    # Concurrency / timeouts
    threads:   int = 10
    timeout_s: int = 15

    # Host selection
    max_hosts: int = 500
    priority_risk_levels: list[str] = field(default_factory=lambda: ["CRITICAL", "HIGH"])

    # Gowitness flags
    disable_db:          bool = True
    screenshot_format:   str  = "png"
    resolution_x:        int  = 1440
    resolution_y:        int  = 900
    delay:               int  = 0
    user_agent:          str  = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    )


@dataclass
class Phase6Config:
    # Binaries
    gau_bin: str = "gau"

    # Wayback
    wayback_cdx_url: str = "https://web.archive.org/cdx/search/cdx"
    wayback_limit:   int = 50000

    # Common Crawl
    cc_index_url:   str = "https://index.commoncrawl.org/collinfo.json"
    cc_max_indexes: int = 3

    # Concurrency
    http_timeout:       int = 30
    max_concurrent_http: int = 5
    tool_timeout:       int = 300

    # Smart filter
    interesting_extensions: list[str] = field(default_factory=lambda: [
        ".php", ".asp", ".aspx", ".jsp", ".js", ".json", ".xml",
        ".env", ".config", ".conf", ".ini", ".yaml", ".yml", ".toml",
        ".zip", ".tar", ".gz", ".bak", ".backup", ".sql", ".db",
        ".sqlite", ".log", ".txt", ".csv", ".pdf",
    ])
    interesting_params: list[str] = field(default_factory=lambda: [
        "id", "file", "path", "page", "url", "redirect", "return",
        "next", "goto", "dest", "destination", "target", "src",
        "source", "include", "load", "read", "fetch", "view",
        "template", "dir", "folder", "doc", "document", "img",
        "image", "cmd", "exec", "query", "search", "q", "input",
        "data", "payload",
    ])
    exclude_patterns: list[str] = field(default_factory=lambda: [
        "google.com", "facebook.com", "twitter.com",
        "googleapis.com", "gstatic.com", "cloudflare.com",
        "jquery.com", "bootstrap.com", "cdnjs.cloudflare.com",
    ])


@dataclass
class Phase4Config:
    # Score → tier thresholds
    score_critical: int   = 20
    score_high:     int   = 12
    score_medium:   int   = 6
    score_low:      int   = 2

    # Confidence floor
    min_confidence: float = 0.4

    # Analyser toggles
    enable_hostname_analysis:  bool = True
    enable_title_analysis:     bool = True
    enable_tech_analysis:      bool = True
    enable_behavior_analysis:  bool = True


@dataclass
class Phase3Config:
    concurrency: int = 50
    timeout_s: int = 10
    max_body_bytes: int = 131072      # 128 KB
    user_agent: str = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    )
    min_confidence: float = 0.5
    retry_attempts: int = 2
    retry_wait_min: float = 0.5
    retry_wait_max: float = 2.0


@dataclass
class FrameworkConfig:
    name: str = "ReconFramework"
    version: str = "1.0.0"
    author: str = "Bug Bounty Engineer"

    output: OutputConfig = field(default_factory=OutputConfig)
    database: DatabaseConfig = field(default_factory=DatabaseConfig)
    logging: LoggingConfig = field(default_factory=LoggingConfig)
    phase1:  Phase1Config  = field(default_factory=Phase1Config)
    phase2:  Phase2Config  = field(default_factory=Phase2Config)
    phase3:  Phase3Config  = field(default_factory=Phase3Config)
    phase4:  Phase4Config  = field(default_factory=Phase4Config)
    phase5:  Phase5Config  = field(default_factory=Phase5Config)
    phase6:  Phase6Config  = field(default_factory=Phase6Config)
    phase7:  Phase7Config  = field(default_factory=Phase7Config)
    phase8:  Phase8Config  = field(default_factory=Phase8Config)
    phase9:  Phase9Config  = field(default_factory=Phase9Config)
    phase10: Phase10Config = field(default_factory=Phase10Config)
    phase11: Phase11Config = field(default_factory=Phase11Config)
    phase2: Phase2Config = field(default_factory=Phase2Config)


# ---------------------------------------------------------------------------
# Loader
# ---------------------------------------------------------------------------

def _merge(base: dict, override: dict) -> dict:
    """Deep merge override into base."""
    result = dict(base)
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(result.get(k), dict):
            result[k] = _merge(result[k], v)
        else:
            result[k] = v
    return result


def load_config(config_path: str | Path = "config.yaml") -> FrameworkConfig:
    """
    Load configuration from YAML file + environment overrides.

    Returns a fully populated FrameworkConfig instance.
    """
    path = Path(config_path)
    raw: dict = {}

    if path.exists():
        with path.open() as fh:
            raw = yaml.safe_load(fh) or {}

    # --- Output ---
    out_raw = raw.get("output", {})
    output = OutputConfig(**{k: v for k, v in out_raw.items() if hasattr(OutputConfig, k)})

    # --- Database ---
    db_raw = raw.get("database", {})
    database = DatabaseConfig(**{k: v for k, v in db_raw.items() if hasattr(DatabaseConfig, k)})

    # --- Logging ---
    log_raw = raw.get("logging", {})
    logging_cfg = LoggingConfig(**{k: v for k, v in log_raw.items() if hasattr(LoggingConfig, k)})
    # env override
    if env_level := _env("LOG_LEVEL"):
        logging_cfg.level = env_level

    # --- Phase 1 ---
    p1_raw = raw.get("phase1", {})
    phase1 = Phase1Config(**{k: v for k, v in p1_raw.items() if hasattr(Phase1Config, k)})
    # env overrides for binaries
    for attr in ("subfinder_bin", "amass_bin", "assetfinder_bin", "findomain_bin"):
        env_key = attr.replace("_bin", "").upper() + "_BIN"
        if val := _env(env_key):
            setattr(phase1, attr, val)

    # --- Phase 2 ---
    p2_raw = raw.get("phase2", {})
    phase2 = Phase2Config(**{k: v for k, v in p2_raw.items() if hasattr(Phase2Config, k)})
    if env_bin := _env("HTTPX_BIN"):
        phase2.httpx_bin = env_bin

    # --- Phase 3 ---
    p3_raw = raw.get("phase3", {})
    phase3 = Phase3Config(**{k: v for k, v in p3_raw.items() if hasattr(Phase3Config, k)})

    # --- Phase 4 ---
    p4_raw = raw.get("phase4", {})
    phase4 = Phase4Config(**{k: v for k, v in p4_raw.items() if hasattr(Phase4Config, k)})

    # --- Phase 11 ---
    p11_raw = raw.get("phase11", {})
    phase11 = Phase11Config(**{k: v for k, v in p11_raw.items() if hasattr(Phase11Config, k)})

    # --- Phase 10 ---
    p10_raw = raw.get("phase10", {})
    phase10 = Phase10Config(**{k: v for k, v in p10_raw.items() if hasattr(Phase10Config, k)})

    # --- Phase 9 ---
    p9_raw = raw.get("phase9", {})
    phase9 = Phase9Config(**{k: v for k, v in p9_raw.items() if hasattr(Phase9Config, k)})

    # --- Phase 8 ---
    p8_raw = raw.get("phase8", {})
    phase8 = Phase8Config(**{k: v for k, v in p8_raw.items() if hasattr(Phase8Config, k)})

    # --- Phase 7 ---
    p7_raw = raw.get("phase7", {})
    phase7 = Phase7Config(**{k: v for k, v in p7_raw.items() if hasattr(Phase7Config, k)})

    # --- Phase 5 ---
    p5_raw = raw.get("phase5", {})
    phase5 = Phase5Config(**{k: v for k, v in p5_raw.items() if hasattr(Phase5Config, k)})
    if env_bin := _env("GOWITNESS_BIN"):
        phase5.gowitness_bin = env_bin

    # --- Phase 6 ---
    p6_raw = raw.get("phase6", {})
    phase6 = Phase6Config(**{k: v for k, v in p6_raw.items() if hasattr(Phase6Config, k)})
    if env_bin := _env("GAU_BIN"):
        phase6.gau_bin = env_bin

    # --- Framework meta ---
    fw_raw = raw.get("framework", {})
    fw = FrameworkConfig(
        name=fw_raw.get("name", "ReconFramework"),
        version=fw_raw.get("version", "1.0.0"),
        author=fw_raw.get("author", "Bug Bounty Engineer"),
        output=output, database=database, logging=logging_cfg,
        phase1=phase1,  phase2=phase2,  phase3=phase3,
        phase4=phase4,  phase5=phase5,  phase6=phase6,
        phase7=phase7,  phase8=phase8,  phase9=phase9,
        phase10=phase10, phase11=phase11,
    )

    # Ensure output dir exists
    Path(fw.output.base_dir).mkdir(parents=True, exist_ok=True)

    return fw


# Convenience singleton
_config_instance: FrameworkConfig | None = None


def get_config(config_path: str | Path = "config.yaml") -> FrameworkConfig:
    """Return the cached singleton config (thread-safe for reads)."""
    global _config_instance
    if _config_instance is None:
        _config_instance = load_config(config_path)
    return _config_instance


def reset_config() -> None:
    """Reset the singleton — used in tests."""
    global _config_instance
    _config_instance = None
