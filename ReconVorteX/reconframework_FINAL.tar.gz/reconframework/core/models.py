"""
core/models.py
==============
Canonical data models for ReconFramework.

Every phase reads/writes these models so the schema stays consistent
across the entire pipeline. Uses Pydantic v2 native patterns.
"""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_serializer, field_validator, model_validator


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------

class RiskLevel(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH     = "HIGH"
    MEDIUM   = "MEDIUM"
    LOW      = "LOW"
    INFO     = "INFO"
    UNKNOWN  = "UNKNOWN"


class DiscoverySource(str, Enum):
    SUBFINDER    = "subfinder"
    AMASS        = "amass"
    ASSETFINDER  = "assetfinder"
    FINDOMAIN    = "findomain"
    CRTSH        = "crtsh"
    ALIENVAULT   = "alienvault"
    CHAOS        = "chaos"
    HACKERTARGET = "hackertarget"
    RAPIDDNS     = "rapiddns"
    MANUAL       = "manual"
    UNKNOWN      = "unknown"


# ---------------------------------------------------------------------------
# Phase 1 — Subdomain Discovery
# ---------------------------------------------------------------------------

class Subdomain(BaseModel):
    """A single discovered subdomain/hostname."""

    model_config = ConfigDict(populate_by_name=True)

    host: str = Field(..., description="Fully-qualified domain name (lowercase, stripped).")
    sources: list[str] = Field(default_factory=list, description="Which tools/APIs discovered this host.")
    discovered_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    is_wildcard: bool = False

    @field_validator("host", mode="before")
    @classmethod
    def normalise_host(cls, v: str) -> str:
        return v.strip().lower().lstrip("*.")

    @field_serializer("discovered_at")
    def serialise_dt(self, dt: datetime) -> str:
        return dt.isoformat()

    def add_source(self, source: str) -> None:
        if source not in self.sources:
            self.sources.append(source)

    def model_post_init(self, __context: Any) -> None:
        self.sources = sorted(set(self.sources))


class DiscoveryResult(BaseModel):
    """Aggregated output of Phase 1."""

    model_config = ConfigDict(populate_by_name=True)

    domain: str
    subdomains: list[Subdomain] = Field(default_factory=list)
    source_breakdown: dict[str, int] = Field(default_factory=dict)
    total_discovered: int = 0
    unique_discovered: int = 0
    errors: list[dict[str, str]] = Field(default_factory=list)
    started_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    finished_at: datetime | None = None
    duration_seconds: float | None = None

    @field_serializer("started_at", "finished_at")
    def serialise_dt(self, dt: datetime | None) -> str | None:
        return dt.isoformat() if dt else None

    def finalise(self) -> None:
        self.finished_at = datetime.now(timezone.utc)
        if self.started_at and self.finished_at:
            self.duration_seconds = (self.finished_at - self.started_at).total_seconds()
        self.unique_discovered = len(self.subdomains)


# ---------------------------------------------------------------------------
# Phase 2 — Live Host
# ---------------------------------------------------------------------------

class LiveHost(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    url: str
    host: str
    status_code: int | None = None
    title: str | None = None
    redirect_chain: list[str] = Field(default_factory=list)
    ip_address: str | None = None
    asn: str | None = None
    web_server: str | None = None
    content_length: int | None = None
    technologies: list[str] = Field(default_factory=list)
    response_time_ms: float | None = None
    probed_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @field_serializer("probed_at")
    def serialise_dt(self, dt: datetime) -> str:
        return dt.isoformat()


# ---------------------------------------------------------------------------
# Phase 3 — Technology Fingerprint
# ---------------------------------------------------------------------------

class TechnologyFingerprint(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    host: str
    url: str
    technologies: list[str] = Field(default_factory=list)
    cms: str | None = None
    web_server: str | None = None
    language: str | None = None
    frameworks: list[str] = Field(default_factory=list)
    fingerprinted_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @field_serializer("fingerprinted_at")
    def serialise_dt(self, dt: datetime) -> str:
        return dt.isoformat()


# ---------------------------------------------------------------------------
# Phase 4 — Asset Intelligence
# ---------------------------------------------------------------------------

class AssetIntelligence(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    host: str
    url: str
    risk_level: RiskLevel = RiskLevel.UNKNOWN
    reasons: list[str] = Field(default_factory=list)
    confidence: float = Field(0.0, ge=0.0, le=1.0)
    tags: list[str] = Field(default_factory=list)
    analysed_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @field_serializer("analysed_at")
    def serialise_dt(self, dt: datetime) -> str:
        return dt.isoformat()


# ---------------------------------------------------------------------------
# Phase 7 — Sensitive Endpoint
# ---------------------------------------------------------------------------

class SensitiveEndpoint(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    url: str
    pattern: str
    source: str
    discovered_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @field_serializer("discovered_at")
    def serialise_dt(self, dt: datetime) -> str:
        return dt.isoformat()


# ---------------------------------------------------------------------------
# Phase 8 — JS Finding
# ---------------------------------------------------------------------------

class JSFinding(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    js_url: str
    finding_type: str
    value: str
    context: str | None = None
    discovered_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @field_serializer("discovered_at")
    def serialise_dt(self, dt: datetime) -> str:
        return dt.isoformat()


# ---------------------------------------------------------------------------
# Phase 9 — Takeover
# ---------------------------------------------------------------------------

class TakeoverFinding(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    host: str
    cname: str | None = None
    service: str | None = None
    confidence: float = Field(0.0, ge=0.0, le=1.0)
    fingerprint: str | None = None
    discovered_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @field_serializer("discovered_at")
    def serialise_dt(self, dt: datetime) -> str:
        return dt.isoformat()


# ---------------------------------------------------------------------------
# Phase 10 — Nuclei Result
# ---------------------------------------------------------------------------

class NucleiFinding(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    host: str
    template_id: str
    name: str
    severity: str
    matched_at: str | None = None
    description: str | None = None
    tags: list[str] = Field(default_factory=list)
    discovered_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @field_serializer("discovered_at")
    def serialise_dt(self, dt: datetime) -> str:
        return dt.isoformat()


# ---------------------------------------------------------------------------
# Phase 11 — Risk Score
# ---------------------------------------------------------------------------

class RiskScore(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    host: str
    score: int = 0
    risk: RiskLevel = RiskLevel.UNKNOWN
    reasons: list[str] = Field(default_factory=list)
    scored_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @field_serializer("scored_at")
    def serialise_dt(self, dt: datetime) -> str:
        return dt.isoformat()

    @model_validator(mode="after")
    def compute_risk_level(self) -> "RiskScore":
        if self.score >= 20:
            self.risk = RiskLevel.CRITICAL
        elif self.score >= 15:
            self.risk = RiskLevel.HIGH
        elif self.score >= 8:
            self.risk = RiskLevel.MEDIUM
        elif self.score >= 3:
            self.risk = RiskLevel.LOW
        else:
            self.risk = RiskLevel.INFO
        return self
