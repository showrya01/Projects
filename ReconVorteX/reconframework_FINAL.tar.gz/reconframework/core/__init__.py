"""core — shared infrastructure for ReconFramework."""

from core.base_plugin import BasePlugin, PluginContext, PluginResult
from core.config import FrameworkConfig, get_config, load_config
from core.database import Database
from core.logger import get_logger, setup_logging
from core.models import (
    DiscoveryResult,
    DiscoverySource,
    RiskLevel,
    Subdomain,
)

__all__ = [
    "BasePlugin",
    "PluginContext",
    "PluginResult",
    "FrameworkConfig",
    "get_config",
    "load_config",
    "Database",
    "get_logger",
    "setup_logging",
    "DiscoveryResult",
    "DiscoverySource",
    "RiskLevel",
    "Subdomain",
]
