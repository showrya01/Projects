"""
core/logger.py
==============
Structured logging for ReconFramework.

  • Console  → Rich pretty-print (human-readable)
  • File     → JSON lines (machine-readable, grep-friendly)
  • Audit    → Append-only audit trail of all tool invocations

Usage:
    from core.logger import get_logger
    log = get_logger(__name__)
    log.info("discovery_started", domain="example.com", phase=1)
"""

from __future__ import annotations

import json
import logging
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.logging import RichHandler
from rich.theme import Theme

# ---------------------------------------------------------------------------
# Rich theme — dark terminal friendly
# ---------------------------------------------------------------------------

_THEME = Theme({
    "logging.level.debug":   "dim cyan",
    "logging.level.info":    "bright_green",
    "logging.level.warning": "bright_yellow",
    "logging.level.error":   "bright_red",
    "logging.level.critical":"bold bright_red",
    "repr.str":              "bright_white",
    "repr.number":           "bright_cyan",
})

_CONSOLE = Console(theme=_THEME, highlight=True, stderr=True)

# ---------------------------------------------------------------------------
# JSON file handler
# ---------------------------------------------------------------------------

class _JsonlFileHandler(logging.Handler):
    """Appends one JSON object per log record to a file."""

    def __init__(self, filepath: str | Path) -> None:
        super().__init__()
        self._path = Path(filepath)
        self._path.parent.mkdir(parents=True, exist_ok=True)

    def emit(self, record: logging.LogRecord) -> None:
        payload: dict[str, Any] = {
            "ts":      datetime.now(timezone.utc).isoformat(),
            "level":   record.levelname,
            "logger":  record.name,
            "message": record.getMessage(),
        }
        # Attach any extra keys passed via `extra=`
        _skip = {
            "name", "msg", "args", "levelname", "levelno", "pathname",
            "filename", "module", "exc_info", "exc_text", "stack_info",
            "lineno", "funcName", "created", "msecs", "relativeCreated",
            "thread", "threadName", "processName", "process", "message",
            "taskName",
        }
        for k, v in record.__dict__.items():
            if k not in _skip:
                payload[k] = v
        try:
            with self._path.open("a") as fh:
                fh.write(json.dumps(payload, default=str) + "\n")
        except Exception:  # noqa: BLE001
            self.handleError(record)


# ---------------------------------------------------------------------------
# Audit logger (separate stream)
# ---------------------------------------------------------------------------

class _AuditLogger:
    """Immutable, append-only audit trail."""

    def __init__(self, filepath: str | Path) -> None:
        self._path = Path(filepath)
        self._path.parent.mkdir(parents=True, exist_ok=True)

    def log(self, event: str, **kwargs: Any) -> None:
        record = {
            "ts":    datetime.now(timezone.utc).isoformat(),
            "event": event,
            **kwargs,
        }
        with self._path.open("a") as fh:
            fh.write(json.dumps(record, default=str) + "\n")


_audit: _AuditLogger | None = None


def get_audit_logger() -> _AuditLogger:
    if _audit is None:
        raise RuntimeError("Logger not initialised — call setup_logging() first.")
    return _audit


# ---------------------------------------------------------------------------
# Setup (called once from main)
# ---------------------------------------------------------------------------

def setup_logging(
    level: str = "INFO",
    log_file: str | Path = "output/recon.log",
    audit_file: str | Path = "output/audit.log",
    fmt: str = "json",
) -> None:
    """
    Configure the root logger and all handlers.

    Parameters
    ----------
    level:      Logging level string (DEBUG/INFO/WARNING/ERROR).
    log_file:   Path for the JSON lines log file.
    audit_file: Path for the append-only audit file.
    fmt:        'json' or 'console' (console → Rich only, no file).
    """
    global _audit

    numeric = getattr(logging, level.upper(), logging.INFO)
    root = logging.getLogger()
    root.setLevel(numeric)
    root.handlers.clear()

    # Rich console handler
    rich_handler = RichHandler(
        console=_CONSOLE,
        show_path=False,
        show_time=True,
        rich_tracebacks=True,
        markup=True,
    )
    rich_handler.setLevel(numeric)
    root.addHandler(rich_handler)

    # JSON file handler (always on, regardless of fmt)
    file_handler = _JsonlFileHandler(log_file)
    file_handler.setLevel(numeric)
    root.addHandler(file_handler)

    # Suppress noisy third-party loggers
    for noisy in ("asyncio", "aiohttp", "urllib3", "charset_normalizer"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    # Audit logger
    _audit = _AuditLogger(audit_file)


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

def get_logger(name: str) -> logging.Logger:
    """
    Return a standard library Logger.

    Callers can pass structured data via `extra=`:
        log.info("msg", extra={"domain": "example.com", "source": "crtsh"})
    """
    return logging.getLogger(name)
