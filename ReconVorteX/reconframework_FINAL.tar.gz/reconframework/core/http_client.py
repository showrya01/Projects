"""
core/http_client.py
===================
Shared async HTTP client factory for ReconFramework.

Features:
  • Singleton aiohttp.ClientSession per event-loop (reuse connections).
  • Configurable timeout and User-Agent.
  • Automatic retry with exponential back-off (via tenacity).
  • Context-manager interface so callers never leak sockets.
"""

from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from typing import AsyncGenerator

import aiohttp
from tenacity import (
    AsyncRetrying,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

log = logging.getLogger(__name__)

_USER_AGENT = (
    "Mozilla/5.0 (compatible; ReconFramework/1.0; "
    "+https://github.com/you/reconframework)"
)

# Module-level session cache (one per running loop)
_session: aiohttp.ClientSession | None = None


def _build_session(timeout_s: int = 30) -> aiohttp.ClientSession:
    connector = aiohttp.TCPConnector(
        limit=100,          # total pool size
        limit_per_host=10,  # per-host cap
        ssl=False,          # we'll verify manually when needed
        ttl_dns_cache=300,
    )
    timeout = aiohttp.ClientTimeout(total=timeout_s, connect=10)
    return aiohttp.ClientSession(
        connector=connector,
        timeout=timeout,
        headers={"User-Agent": _USER_AGENT},
        trust_env=True,     # respect HTTP_PROXY / HTTPS_PROXY env vars
    )


async def get_session(timeout_s: int = 30) -> aiohttp.ClientSession:
    """Return (or create) the module-level ClientSession."""
    global _session
    if _session is None or _session.closed:
        _session = _build_session(timeout_s)
    return _session


async def close_session() -> None:
    """Gracefully close the shared session."""
    global _session
    if _session and not _session.closed:
        await _session.close()
        await asyncio.sleep(0.25)  # allow SSL shutdown
    _session = None


@asynccontextmanager
async def http_session(timeout_s: int = 30) -> AsyncGenerator[aiohttp.ClientSession, None]:
    """
    Async context-manager that yields the shared session.

    For short-lived scripts; long-running servers should call
    get_session() directly and close_session() at shutdown.
    """
    session = await get_session(timeout_s)
    try:
        yield session
    finally:
        pass  # keep alive; caller decides when to close


async def fetch_json(
    url: str,
    *,
    session: aiohttp.ClientSession | None = None,
    timeout_s: int = 30,
    retries: int = 3,
    wait_min: float = 1.0,
    wait_max: float = 5.0,
    params: dict | None = None,
    headers: dict | None = None,
) -> dict | list | None:
    """
    GET a URL and return parsed JSON.

    Returns None on failure (after all retries exhausted).
    """
    if session is None:
        session = await get_session(timeout_s)

    async def _attempt() -> dict | list:
        async with session.get(url, params=params, headers=headers) as resp:
            resp.raise_for_status()
            return await resp.json(content_type=None)

    try:
        async for attempt in AsyncRetrying(
            stop=stop_after_attempt(retries),
            wait=wait_exponential(min=wait_min, max=wait_max),
            retry=retry_if_exception_type((aiohttp.ClientError, asyncio.TimeoutError)),
            reraise=False,
        ):
            with attempt:
                return await _attempt()
    except Exception as exc:  # noqa: BLE001
        log.warning("fetch_json failed", extra={"url": url, "error": str(exc)})
        return None


async def fetch_text(
    url: str,
    *,
    session: aiohttp.ClientSession | None = None,
    timeout_s: int = 30,
    retries: int = 3,
    wait_min: float = 1.0,
    wait_max: float = 5.0,
    headers: dict | None = None,
) -> str | None:
    """
    GET a URL and return the response body as text.

    Returns None on failure.
    """
    if session is None:
        session = await get_session(timeout_s)

    async def _attempt() -> str:
        async with session.get(url, headers=headers) as resp:
            resp.raise_for_status()
            return await resp.text()

    try:
        async for attempt in AsyncRetrying(
            stop=stop_after_attempt(retries),
            wait=wait_exponential(min=wait_min, max=wait_max),
            retry=retry_if_exception_type((aiohttp.ClientError, asyncio.TimeoutError)),
            reraise=False,
        ):
            with attempt:
                return await _attempt()
    except Exception as exc:  # noqa: BLE001
        log.warning("fetch_text failed", extra={"url": url, "error": str(exc)})
        return None
