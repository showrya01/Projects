"""
core/base_plugin.py
===================
Abstract base class for all ReconFramework plugins.

Every discovery module, scanner, or intelligence gatherer inherits from
BasePlugin and implements the `run()` coroutine.

Plugin contract:
  • Receives a shared PluginContext (domain, config, db, logger).
  • Returns a typed Result (defined per plugin family).
  • Reports errors via the shared error list — never raises uncaught.
  • Emits structured log events so the audit trail is complete.
"""

from __future__ import annotations

import logging
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Generic, TypeVar

from core.config import FrameworkConfig

# Generic result type — each plugin family defines its own
T = TypeVar("T")


# ---------------------------------------------------------------------------
# Plugin Context — injected into every plugin at runtime
# ---------------------------------------------------------------------------

@dataclass
class PluginContext:
    """
    Shared execution context passed to every plugin.

    Attributes
    ----------
    domain:   Primary target domain (e.g. "example.com").
    config:   The global FrameworkConfig singleton.
    errors:   Shared mutable list; plugins append error dicts here.
    metadata: Arbitrary key-value store for inter-plugin communication.
    """

    domain: str
    config: FrameworkConfig
    errors: list[dict[str, str]] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def record_error(self, plugin: str, message: str, exc: Exception | None = None) -> None:
        entry: dict[str, str] = {"plugin": plugin, "message": message}
        if exc:
            entry["exception"] = type(exc).__name__
            entry["detail"] = str(exc)
        self.errors.append(entry)


# ---------------------------------------------------------------------------
# Plugin Result wrapper
# ---------------------------------------------------------------------------

@dataclass
class PluginResult(Generic[T]):
    """
    Uniform result envelope returned by every plugin.

    Attributes
    ----------
    plugin_name:     Human-readable source identifier.
    success:         False if the plugin failed entirely.
    data:            The plugin's payload (type varies by family).
    error:           Error message if success is False.
    duration_seconds: Wall-clock time consumed.
    """

    plugin_name: str
    success: bool
    data: T | None = None
    error: str | None = None
    duration_seconds: float = 0.0


# ---------------------------------------------------------------------------
# Abstract base
# ---------------------------------------------------------------------------

class BasePlugin(ABC, Generic[T]):
    """
    Abstract base for all ReconFramework plugins.

    Subclasses must:
      1. Set ``NAME`` class attribute (unique slug, e.g. "subfinder").
      2. Implement ``async def run(self, ctx: PluginContext) -> PluginResult[T]``.

    Subclasses may:
      • Override ``ENABLED`` to ``False`` to disable by default.
      • Override ``PRIORITY`` (lower = runs earlier in sorted order).
      • Call ``self._log.info(...)`` for structured events.
    """

    NAME: str = "base_plugin"
    ENABLED: bool = True
    PRIORITY: int = 50  # 0 = highest priority

    def __init__(self) -> None:
        self._log = logging.getLogger(f"plugin.{self.NAME}")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @abstractmethod
    async def run(self, ctx: PluginContext) -> PluginResult[T]:
        """Execute the plugin and return a typed PluginResult."""
        ...

    async def execute(self, ctx: PluginContext) -> PluginResult[T]:
        """
        Thin wrapper around ``run()`` that:
          • Measures wall-clock duration.
          • Catches unhandled exceptions and converts to a failed PluginResult.
          • Emits audit log events (start / end / error).
        """
        self._log.info(
            "Plugin started",
            extra={"plugin": self.NAME, "domain": ctx.domain},
        )
        t0 = time.perf_counter()
        try:
            result = await self.run(ctx)
            result.duration_seconds = time.perf_counter() - t0
            self._log.info(
                "Plugin finished",
                extra={
                    "plugin": self.NAME,
                    "domain": ctx.domain,
                    "success": result.success,
                    "duration_s": round(result.duration_seconds, 2),
                },
            )
            return result
        except Exception as exc:  # noqa: BLE001
            elapsed = time.perf_counter() - t0
            ctx.record_error(self.NAME, "Unhandled exception", exc)
            self._log.error(
                "Plugin crashed",
                extra={
                    "plugin": self.NAME,
                    "domain": ctx.domain,
                    "error": str(exc),
                },
                exc_info=True,
            )
            return PluginResult(
                plugin_name=self.NAME,
                success=False,
                error=str(exc),
                duration_seconds=elapsed,
            )

    # ------------------------------------------------------------------
    # Helpers available to subclasses
    # ------------------------------------------------------------------

    def _ok(self, data: T, *, duration: float = 0.0) -> PluginResult[T]:
        return PluginResult(
            plugin_name=self.NAME,
            success=True,
            data=data,
            duration_seconds=duration,
        )

    def _fail(self, error: str, *, duration: float = 0.0) -> PluginResult[T]:
        return PluginResult(
            plugin_name=self.NAME,
            success=False,
            error=error,
            duration_seconds=duration,
        )

    def __repr__(self) -> str:
        return f"<Plugin name={self.NAME!r} enabled={self.ENABLED} priority={self.PRIORITY}>"
