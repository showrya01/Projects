"""
core/database.py
================
Async SQLite persistence layer for ReconFramework.

Design goals:
  • Single connection pool (aiosqlite) per process.
  • Schema is version-controlled with a migrations list.
  • Each phase upserts its own table — no coupling between phases.
  • All public methods are async and safe to call concurrently.
"""

from __future__ import annotations

import json
import logging
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, AsyncGenerator

import aiosqlite

from core.models import DiscoveryResult, LiveHost, Subdomain

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Schema migrations (ordered list — append only)
# ---------------------------------------------------------------------------

_MIGRATIONS: list[str] = [
    # --- M001: Phase 1 ---
    """
    CREATE TABLE IF NOT EXISTS subdomains (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        host        TEXT    NOT NULL UNIQUE,
        domain      TEXT    NOT NULL,
        sources     TEXT    NOT NULL DEFAULT '[]',   -- JSON array
        is_wildcard INTEGER NOT NULL DEFAULT 0,
        discovered_at TEXT  NOT NULL,
        created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
    )
    """,
    """
    CREATE INDEX IF NOT EXISTS idx_subdomains_domain ON subdomains(domain)
    """,
    # --- M002: Phase 2 ---
    """
    CREATE TABLE IF NOT EXISTS live_hosts (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        host            TEXT    NOT NULL,
        url             TEXT    NOT NULL UNIQUE,
        status_code     INTEGER,
        title           TEXT,
        redirect_chain  TEXT    DEFAULT '[]',
        ip_address      TEXT,
        asn             TEXT,
        web_server      TEXT,
        content_length  INTEGER,
        technologies    TEXT    DEFAULT '[]',
        response_time_ms REAL,
        probed_at       TEXT    NOT NULL,
        created_at      TEXT    NOT NULL DEFAULT (datetime('now'))
    )
    """,
    """
    CREATE INDEX IF NOT EXISTS idx_live_hosts_host ON live_hosts(host)
    """,
    # --- M003: Phase 3 ---
    """
    CREATE TABLE IF NOT EXISTS technologies (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        host            TEXT    NOT NULL,
        url             TEXT    NOT NULL UNIQUE,
        technologies    TEXT    DEFAULT '[]',
        cms             TEXT,
        web_server      TEXT,
        language        TEXT,
        frameworks      TEXT    DEFAULT '[]',
        fingerprinted_at TEXT   NOT NULL,
        created_at      TEXT    NOT NULL DEFAULT (datetime('now'))
    )
    """,
    # --- M004: Phase 4 ---
    """
    CREATE TABLE IF NOT EXISTS asset_intelligence (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        host        TEXT    NOT NULL,
        url         TEXT    NOT NULL UNIQUE,
        risk_level  TEXT    NOT NULL DEFAULT 'UNKNOWN',
        reasons     TEXT    DEFAULT '[]',
        confidence  REAL    NOT NULL DEFAULT 0.0,
        tags        TEXT    DEFAULT '[]',
        analysed_at TEXT    NOT NULL,
        created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
    )
    """,
    # --- M005: Findings / scores ---
    """
    CREATE TABLE IF NOT EXISTS nuclei_findings (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        host        TEXT    NOT NULL,
        template_id TEXT    NOT NULL,
        name        TEXT    NOT NULL,
        severity    TEXT    NOT NULL,
        matched_at  TEXT,
        description TEXT,
        tags        TEXT    DEFAULT '[]',
        discovered_at TEXT  NOT NULL,
        created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS risk_scores (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        host        TEXT    NOT NULL UNIQUE,
        score       INTEGER NOT NULL DEFAULT 0,
        risk        TEXT    NOT NULL DEFAULT 'UNKNOWN',
        reasons     TEXT    DEFAULT '[]',
        scored_at   TEXT    NOT NULL,
        created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
    )
    """,
    # --- M006: Schema version tracking ---
    """
    CREATE TABLE IF NOT EXISTS schema_meta (
        version     INTEGER PRIMARY KEY,
        applied_at  TEXT NOT NULL DEFAULT (datetime('now'))
    )
    """,
]


# ---------------------------------------------------------------------------
# Database class
# ---------------------------------------------------------------------------

class Database:
    """
    Async SQLite wrapper.

    Use as an async context manager:

        async with Database("output/recon.db") as db:
            await db.upsert_subdomain(sub, domain="example.com")
    """

    def __init__(self, path: str | Path = "output/recon.db") -> None:
        self._path = Path(path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._conn: aiosqlite.Connection | None = None

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        self._conn = await aiosqlite.connect(self._path)
        self._conn.row_factory = aiosqlite.Row
        await self._conn.execute("PRAGMA journal_mode=WAL")
        await self._conn.execute("PRAGMA synchronous=NORMAL")
        await self._migrate()
        log.debug("Database connected", extra={"path": str(self._path)})

    async def close(self) -> None:
        if self._conn:
            await self._conn.close()
            self._conn = None

    async def __aenter__(self) -> "Database":
        await self.connect()
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _require_conn(self) -> aiosqlite.Connection:
        if self._conn is None:
            raise RuntimeError("Database not connected. Use `async with Database(...)`.")
        return self._conn

    async def _migrate(self) -> None:
        """Run all pending migrations in order."""
        conn = self._require_conn()
        # Ensure meta table exists first
        await conn.execute(
            "CREATE TABLE IF NOT EXISTS schema_meta "
            "(version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT (datetime('now')))"
        )
        await conn.commit()

        cursor = await conn.execute("SELECT MAX(version) FROM schema_meta")
        row = await cursor.fetchone()
        current_version = row[0] if row and row[0] is not None else -1

        applied = 0
        for idx, sql in enumerate(_MIGRATIONS):
            if idx <= current_version:
                continue
            try:
                await conn.executescript(sql)
                await conn.execute(
                    "INSERT OR IGNORE INTO schema_meta (version) VALUES (?)", (idx,)
                )
                await conn.commit()
                applied += 1
            except Exception as exc:  # noqa: BLE001
                log.error(
                    "Migration failed",
                    extra={"migration_index": idx, "error": str(exc)},
                )
                raise

        if applied:
            log.info("Migrations applied", extra={"count": applied})

    # ------------------------------------------------------------------
    # Phase 1 — Subdomains
    # ------------------------------------------------------------------

    async def upsert_subdomain(self, sub: Subdomain, domain: str) -> None:
        """Insert or update a subdomain record."""
        conn = self._require_conn()
        await conn.execute(
            """
            INSERT INTO subdomains (host, domain, sources, is_wildcard, discovered_at)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(host) DO UPDATE SET
                sources     = excluded.sources,
                is_wildcard = excluded.is_wildcard
            """,
            (
                sub.host,
                domain,
                json.dumps(sub.sources),
                int(sub.is_wildcard),
                sub.discovered_at.isoformat(),
            ),
        )
        await conn.commit()

    async def bulk_upsert_subdomains(
        self, subdomains: list[Subdomain], domain: str
    ) -> None:
        """Batch upsert — much faster than individual calls."""
        conn = self._require_conn()
        rows = [
            (
                s.host,
                domain,
                json.dumps(s.sources),
                int(s.is_wildcard),
                s.discovered_at.isoformat(),
            )
            for s in subdomains
        ]
        await conn.executemany(
            """
            INSERT INTO subdomains (host, domain, sources, is_wildcard, discovered_at)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(host) DO UPDATE SET
                sources     = excluded.sources,
                is_wildcard = excluded.is_wildcard
            """,
            rows,
        )
        await conn.commit()
        log.debug(
            "Bulk upsert complete",
            extra={"count": len(rows), "domain": domain},
        )

    async def get_subdomains(self, domain: str) -> list[Subdomain]:
        """Return all subdomains for a domain."""
        conn = self._require_conn()
        cursor = await conn.execute(
            "SELECT host, sources, is_wildcard, discovered_at FROM subdomains WHERE domain=?",
            (domain,),
        )
        rows = await cursor.fetchall()
        result = []
        for row in rows:
            result.append(
                Subdomain(
                    host=row["host"],
                    sources=json.loads(row["sources"]),
                    is_wildcard=bool(row["is_wildcard"]),
                    discovered_at=datetime.fromisoformat(row["discovered_at"]),
                )
            )
        return result

    async def count_subdomains(self, domain: str) -> int:
        conn = self._require_conn()
        cursor = await conn.execute(
            "SELECT COUNT(*) FROM subdomains WHERE domain=?", (domain,)
        )
        row = await cursor.fetchone()
        return row[0] if row else 0

    # ------------------------------------------------------------------
    # Phase 2 — Live Hosts
    # ------------------------------------------------------------------

    async def upsert_live_host(self, host: LiveHost) -> None:
        conn = self._require_conn()
        await conn.execute(
            """
            INSERT INTO live_hosts
                (host, url, status_code, title, redirect_chain, ip_address, asn,
                 web_server, content_length, technologies, response_time_ms, probed_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(url) DO UPDATE SET
                status_code    = excluded.status_code,
                title          = excluded.title,
                redirect_chain = excluded.redirect_chain,
                ip_address     = excluded.ip_address,
                asn            = excluded.asn,
                web_server     = excluded.web_server,
                content_length = excluded.content_length,
                technologies   = excluded.technologies,
                response_time_ms = excluded.response_time_ms,
                probed_at      = excluded.probed_at
            """,
            (
                host.host,
                host.url,
                host.status_code,
                host.title,
                json.dumps(host.redirect_chain),
                host.ip_address,
                host.asn,
                host.web_server,
                host.content_length,
                json.dumps(host.technologies),
                host.response_time_ms,
                host.probed_at.isoformat(),
            ),
        )
        await conn.commit()

    async def bulk_upsert_live_hosts(self, hosts: list) -> None:
        """Batch upsert live hosts."""
        conn = self._require_conn()
        rows = [
            (
                h.host, h.url, h.status_code, h.title,
                json.dumps(h.redirect_chain), h.ip_address, h.asn,
                h.web_server, h.content_length, json.dumps(h.technologies),
                h.response_time_ms, h.probed_at.isoformat(),
            )
            for h in hosts
        ]
        await conn.executemany(
            """
            INSERT INTO live_hosts
                (host, url, status_code, title, redirect_chain, ip_address, asn,
                 web_server, content_length, technologies, response_time_ms, probed_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(url) DO UPDATE SET
                status_code      = excluded.status_code,
                title            = excluded.title,
                redirect_chain   = excluded.redirect_chain,
                ip_address       = excluded.ip_address,
                asn              = excluded.asn,
                web_server       = excluded.web_server,
                content_length   = excluded.content_length,
                technologies     = excluded.technologies,
                response_time_ms = excluded.response_time_ms,
                probed_at        = excluded.probed_at
            """,
            rows,
        )
        await conn.commit()
        log.debug("Bulk upsert live_hosts", extra={"count": len(rows)})

    async def get_live_hosts(self) -> list:
        """Return all probed live hosts ordered by host."""
        from core.models import LiveHost
        from datetime import datetime as _dt
        conn = self._require_conn()
        cursor = await conn.execute(
            "SELECT host, url, status_code, title, redirect_chain, ip_address, "
            "asn, web_server, content_length, technologies, response_time_ms, probed_at "
            "FROM live_hosts ORDER BY host"
        )
        rows = await cursor.fetchall()
        return [
            LiveHost(
                host=r["host"], url=r["url"],
                status_code=r["status_code"], title=r["title"],
                redirect_chain=json.loads(r["redirect_chain"] or "[]"),
                ip_address=r["ip_address"], asn=r["asn"],
                web_server=r["web_server"], content_length=r["content_length"],
                technologies=json.loads(r["technologies"] or "[]"),
                response_time_ms=r["response_time_ms"],
                probed_at=_dt.fromisoformat(r["probed_at"]),
            )
            for r in rows
        ]

    async def count_live_hosts(self) -> int:
        conn = self._require_conn()
        cur = await conn.execute("SELECT COUNT(*) FROM live_hosts")
        row = await cur.fetchone()
        return row[0] if row else 0

    # ------------------------------------------------------------------
    # Phase 3 — Technologies
    # ------------------------------------------------------------------

    async def upsert_technology(self, fp: "TechnologyFingerprint") -> None:  # noqa: F821
        from core.models import TechnologyFingerprint
        conn = self._require_conn()
        await conn.execute(
            """
            INSERT INTO technologies
                (host, url, technologies, cms, web_server, language, frameworks, fingerprinted_at)
            VALUES (?,?,?,?,?,?,?,?)
            ON CONFLICT(url) DO UPDATE SET
                technologies     = excluded.technologies,
                cms              = excluded.cms,
                web_server       = excluded.web_server,
                language         = excluded.language,
                frameworks       = excluded.frameworks,
                fingerprinted_at = excluded.fingerprinted_at
            """,
            (
                fp.host,
                fp.url,
                json.dumps(fp.technologies),
                fp.cms,
                fp.web_server,
                fp.language,
                json.dumps(fp.frameworks),
                fp.fingerprinted_at.isoformat(),
            ),
        )
        await conn.commit()

    async def get_technologies(self) -> list["TechnologyFingerprint"]:
        from core.models import TechnologyFingerprint
        from datetime import datetime as _dt2
        conn = self._require_conn()
        cursor = await conn.execute(
            "SELECT host,url,technologies,cms,web_server,language,frameworks,fingerprinted_at "
            "FROM technologies ORDER BY host"
        )
        rows = await cursor.fetchall()
        return [
            TechnologyFingerprint(
                host=r["host"],
                url=r["url"],
                technologies=json.loads(r["technologies"] or "[]"),
                cms=r["cms"],
                web_server=r["web_server"],
                language=r["language"],
                frameworks=json.loads(r["frameworks"] or "[]"),
                fingerprinted_at=_dt2.fromisoformat(r["fingerprinted_at"]),
            )
            for r in rows
        ]

    # ------------------------------------------------------------------
    # Phase 4 — Asset Intelligence
    # ------------------------------------------------------------------

    async def upsert_asset_intelligence(self, intel: "AssetIntelligence") -> None:
        from core.models import AssetIntelligence as _AI
        conn = self._require_conn()
        await conn.execute(
            """
            INSERT INTO asset_intelligence
                (host, url, risk_level, reasons, confidence, tags, analysed_at)
            VALUES (?,?,?,?,?,?,?)
            ON CONFLICT(url) DO UPDATE SET
                risk_level  = excluded.risk_level,
                reasons     = excluded.reasons,
                confidence  = excluded.confidence,
                tags        = excluded.tags,
                analysed_at = excluded.analysed_at
            """,
            (
                intel.host,
                intel.url,
                intel.risk_level.value,
                json.dumps(intel.reasons),
                intel.confidence,
                json.dumps(intel.tags),
                intel.analysed_at.isoformat(),
            ),
        )
        await conn.commit()

    async def get_asset_intelligence(self) -> list["AssetIntelligence"]:
        from core.models import AssetIntelligence as _AI, RiskLevel
        from datetime import datetime as _dt
        conn = self._require_conn()
        cursor = await conn.execute(
            "SELECT host,url,risk_level,reasons,confidence,tags,analysed_at "
            "FROM asset_intelligence ORDER BY confidence DESC"
        )
        rows = await cursor.fetchall()
        return [
            _AI(
                host=r["host"],
                url=r["url"],
                risk_level=RiskLevel(r["risk_level"]),
                reasons=json.loads(r["reasons"] or "[]"),
                confidence=r["confidence"],
                tags=json.loads(r["tags"] or "[]"),
                analysed_at=_dt.fromisoformat(r["analysed_at"]),
            )
            for r in rows
        ]

    # ------------------------------------------------------------------
    # Phase 10 — Nuclei Findings
    # ------------------------------------------------------------------

    async def upsert_nuclei_finding(self, finding: "NucleiFinding") -> None:
        from core.models import NucleiFinding as _NF
        conn = self._require_conn()
        await conn.execute(
            """
            INSERT INTO nuclei_findings
                (host, template_id, name, severity, matched_at,
                 description, tags, discovered_at)
            VALUES (?,?,?,?,?,?,?,?)
            ON CONFLICT DO NOTHING
            """,
            (
                finding.host,
                finding.template_id,
                finding.name,
                finding.severity,
                finding.matched_at,
                finding.description,
                json.dumps(finding.tags),
                finding.discovered_at.isoformat(),
            ),
        )
        await conn.commit()

    async def get_nuclei_findings(self, host: str | None = None) -> list["NucleiFinding"]:
        from core.models import NucleiFinding as _NF
        from datetime import datetime as _dt
        conn = self._require_conn()
        if host:
            cursor = await conn.execute(
                "SELECT host,template_id,name,severity,matched_at,description,tags,discovered_at "
                "FROM nuclei_findings WHERE host=? ORDER BY severity",
                (host,),
            )
        else:
            cursor = await conn.execute(
                "SELECT host,template_id,name,severity,matched_at,description,tags,discovered_at "
                "FROM nuclei_findings ORDER BY host,severity"
            )
        rows = await cursor.fetchall()
        return [
            _NF(
                host=r["host"],
                template_id=r["template_id"],
                name=r["name"],
                severity=r["severity"],
                matched_at=r["matched_at"],
                description=r["description"],
                tags=json.loads(r["tags"] or "[]"),
                discovered_at=_dt.fromisoformat(r["discovered_at"]),
            )
            for r in rows
        ]
