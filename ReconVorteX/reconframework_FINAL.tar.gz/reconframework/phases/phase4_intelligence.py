"""
phases/phase4_intelligence.py
================================
Phase 4 — Asset Intelligence Engine Orchestrator

Workflow
--------
1. Load live hosts from Phase 2  (url, host, status, title, redirect_chain,
                                   ip, web_server, technologies).
2. Load technology fingerprints from Phase 3  (enrich technologies list).
3. Merge into AssetContext objects (one per host).
4. Run AssetAnalyzer against every context.
5. Filter results below min_confidence.
6. Sort by score descending.
7. Persist to SQLite (asset_intelligence table).
8. Write output/asset_intelligence.json.
9. Print Rich ranked table.

Integration
-----------
Reads  : output/live_hosts.json
         output/technologies.json
Writes : output/asset_intelligence.json
         output/recon.db  (asset_intelligence table)
"""

from __future__ import annotations

import json
import logging
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

from rich import box
from rich.console import Console
from rich.table import Table

from core.config import FrameworkConfig
from core.database import Database
from core.models import AssetIntelligence, RiskLevel
from plugins.intelligence.analyzer import AssetAnalyzer, AssetContext

log     = logging.getLogger(__name__)
console = Console(stderr=True)

# Map risk level to Rich colour
_RISK_COLOUR: dict[RiskLevel, str] = {
    RiskLevel.CRITICAL: "bold bright_red",
    RiskLevel.HIGH:     "bright_red",
    RiskLevel.MEDIUM:   "bright_yellow",
    RiskLevel.LOW:      "bright_green",
    RiskLevel.INFO:     "dim white",
    RiskLevel.UNKNOWN:  "dim",
}


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

async def run_phase4(
    domain: str,
    config: FrameworkConfig,
    *,
    live_hosts:  list[dict] | None = None,
    tech_data:   list[dict] | None = None,
) -> list[AssetIntelligence]:
    """
    Execute Phase 4.

    Parameters
    ----------
    domain:     Target domain string.
    config:     Loaded FrameworkConfig.
    live_hosts: Optional pre-loaded list of live host dicts (from Phase 2).
    tech_data:  Optional pre-loaded list of technology dicts (from Phase 3).

    Returns
    -------
    Ranked list of AssetIntelligence objects (highest score first).
    """
    started = datetime.now(timezone.utc)
    log.info("Phase 4 starting", extra={"domain": domain})

    # ------------------------------------------------------------------
    # 1. Load data from previous phases
    # ------------------------------------------------------------------
    hosts_raw = live_hosts or _load_json_list(
        config.output.live_hosts_json, "hosts"
    )
    tech_raw  = tech_data or _load_json_list(
        config.output.technologies_json, "hosts"
    )

    if not hosts_raw:
        log.warning(
            "No live hosts found — did Phase 2 run?",
            extra={"domain": domain},
        )
        return []

    log.info(
        "Data loaded",
        extra={
            "live_hosts": len(hosts_raw),
            "tech_records": len(tech_raw),
        },
    )

    # ------------------------------------------------------------------
    # 2. Build tech lookup (url → tech list) from Phase 3
    # ------------------------------------------------------------------
    tech_by_url:  dict[str, list[str]] = {}
    tech_by_host: dict[str, list[str]] = {}
    for rec in tech_raw:
        techs = rec.get("technologies", [])
        if rec.get("url"):
            tech_by_url[rec["url"]] = techs
        if rec.get("host"):
            tech_by_host[rec["host"]] = techs

    # ------------------------------------------------------------------
    # 3. Build AssetContext per live host
    # ------------------------------------------------------------------
    contexts: list[AssetContext] = []
    for h in hosts_raw:
        url  = h.get("url", "")
        host = h.get("host", "")
        if not url or not host:
            continue

        # Merge technologies: Phase 2 list + Phase 3 enrichment
        p2_techs    = h.get("technologies", [])
        p3_techs    = tech_by_url.get(url) or tech_by_host.get(host) or []
        merged_tech = list({t for t in (p2_techs + p3_techs) if t})

        contexts.append(AssetContext(
            host=host,
            url=url,
            status_code=h.get("status_code"),
            title=h.get("title"),
            redirect_chain=h.get("redirect_chain", []),
            ip_address=h.get("ip_address"),
            web_server=h.get("web_server"),
            technologies=merged_tech,
            html_body="",   # not stored in Phase 2; behavior rules use redirect_chain
            domain=domain,
        ))

    log.info("Contexts built", extra={"count": len(contexts)})

    # ------------------------------------------------------------------
    # 4. Run analyzer
    # ------------------------------------------------------------------
    analyzer = AssetAnalyzer(config.phase4)
    results:  list[AssetIntelligence] = []

    for ctx in contexts:
        intel = analyzer.analyse(ctx)
        if intel:
            results.append(intel)

    # Sort: CRITICAL → INFO, then by confidence desc
    _RISK_ORDER = {
        RiskLevel.CRITICAL: 0,
        RiskLevel.HIGH:     1,
        RiskLevel.MEDIUM:   2,
        RiskLevel.LOW:      3,
        RiskLevel.INFO:     4,
        RiskLevel.UNKNOWN:  5,
    }
    results.sort(key=lambda r: (_RISK_ORDER[r.risk_level], -r.confidence))

    log.info(
        "Intelligence analysis complete",
        extra={
            "total_assets":    len(contexts),
            "flagged":         len(results),
            "critical":        sum(1 for r in results if r.risk_level == RiskLevel.CRITICAL),
            "high":            sum(1 for r in results if r.risk_level == RiskLevel.HIGH),
        },
    )

    # ------------------------------------------------------------------
    # 5. Persist to SQLite
    # ------------------------------------------------------------------
    async with Database(config.database.path) as db:
        for intel in results:
            await db.upsert_asset_intelligence(intel)

    # ------------------------------------------------------------------
    # 6. Write JSON output
    # ------------------------------------------------------------------
    out_path = Path(config.output.asset_intelligence_json)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    _write_json(results, out_path, domain)
    log.info("Wrote asset_intelligence.json", extra={"path": str(out_path)})

    # ------------------------------------------------------------------
    # 7. Print Rich summary
    # ------------------------------------------------------------------
    elapsed = (datetime.now(timezone.utc) - started).total_seconds()
    _print_summary(results, domain, elapsed)

    return results


# ---------------------------------------------------------------------------
# Data loaders
# ---------------------------------------------------------------------------

def _load_json_list(path_str: str, list_key: str) -> list[dict]:
    """Load a JSON file and return the value at list_key, or [] on error."""
    path = Path(path_str)
    if not path.exists():
        log.debug("File not found", extra={"path": path_str})
        return []
    try:
        with path.open() as fh:
            data = json.load(fh)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return data.get(list_key, [])
    except Exception as exc:
        log.warning("Failed to load JSON", extra={"path": path_str, "error": str(exc)})
    return []


# ---------------------------------------------------------------------------
# JSON output
# ---------------------------------------------------------------------------

def _write_json(
    results: list[AssetIntelligence],
    path:    Path,
    domain:  str,
) -> None:
    # Risk-level distribution
    dist: dict[str, int] = defaultdict(int)
    for r in results:
        dist[r.risk_level.value] += 1

    payload = {
        "meta": {
            "domain":       domain,
            "total_flagged": len(results),
            "risk_distribution": dict(dist),
            "generated_at": datetime.now(timezone.utc).isoformat(),
        },
        "findings": [
            {
                "host":       r.host,
                "url":        r.url,
                "risk_level": r.risk_level.value,
                "confidence": r.confidence,
                "tags":       r.tags,
                "reasons":    r.reasons,
                "analysed_at": r.analysed_at.isoformat(),
            }
            for r in results
        ],
    }

    with path.open("w") as fh:
        json.dump(payload, fh, indent=2, default=str)


# ---------------------------------------------------------------------------
# Rich terminal summary
# ---------------------------------------------------------------------------

def _print_summary(
    results: list[AssetIntelligence],
    domain:  str,
    elapsed: float,
) -> None:
    console.rule(f"[bold cyan]Phase 4 — Asset Intelligence Engine[/] · {domain}")

    # Stats
    dist: dict[RiskLevel, int] = defaultdict(int)
    for r in results:
        dist[r.risk_level] += 1

    console.print(
        f"\n"
        f"  [bold red]◈  CRITICAL :[/] {dist[RiskLevel.CRITICAL]}\n"
        f"  [red]◈  HIGH     :[/] {dist[RiskLevel.HIGH]}\n"
        f"  [yellow]◈  MEDIUM   :[/] {dist[RiskLevel.MEDIUM]}\n"
        f"  [green]◈  LOW      :[/] {dist[RiskLevel.LOW]}\n"
        f"  [dim]◈  INFO     :[/] {dist[RiskLevel.INFO]}\n"
        f"  [bold blue]⏱  Duration  :[/] {elapsed:.1f}s\n"
    )

    if not results:
        console.print("[dim]No assets flagged.[/dim]")
        console.rule()
        return

    # Top findings table (max 25 rows)
    top = results[:25]
    table = Table(
        title=f"Top Intelligence Findings ({len(top)} of {len(results)})",
        box=box.SIMPLE_HEAD,
        show_edge=False,
    )
    table.add_column("Risk",       width=10)
    table.add_column("Host",       style="bright_white", max_width=45, no_wrap=True)
    table.add_column("Tags",       style="cyan",         max_width=35, no_wrap=True)
    table.add_column("Conf",       width=6,  justify="right")
    table.add_column("Top Reason", style="dim white", max_width=45, no_wrap=True)

    for r in top:
        risk_str  = f"[{_RISK_COLOUR[r.risk_level]}]{r.risk_level.value}[/]"
        tags_str  = ", ".join(r.tags[:4])
        reason    = r.reasons[0] if r.reasons else ""
        conf_str  = f"{r.confidence:.2f}"
        table.add_row(risk_str, r.host, tags_str, conf_str, reason)

    console.print(table)

    # CRITICAL / HIGH callout block
    hv = [r for r in results if r.risk_level in (RiskLevel.CRITICAL, RiskLevel.HIGH)]
    if hv:
        console.print(
            f"\n[bold red]⚑  {len(hv)} CRITICAL/HIGH asset(s) — "
            f"review {Path(config_path_hint).name if False else 'output/asset_intelligence.json'}[/]"
        )

    console.rule()

# Sentinel used in the callout — replaced at call time
config_path_hint = "output/asset_intelligence.json"
