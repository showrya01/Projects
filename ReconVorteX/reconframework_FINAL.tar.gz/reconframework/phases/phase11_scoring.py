"""
phases/phase11_scoring.py
===========================
Phase 11 — Risk Scoring Engine

Aggregates intelligence from every prior phase into a single ranked
list of high-value targets. Each target receives a composite score
built from multiple independent evidence sources.

Score sources
-------------
Phase 4  — Asset Intelligence     (risk level → fixed points)
Phase 7  — Sensitive Endpoints    (phase11_score_contributions from JSON)
Phase 8  — JavaScript Intelligence (per finding-type points)
Phase 9  — Takeover Detection     (confidence-band points)
Phase 10 — Vulnerability Scanning  (phase11_score_contributions from JSON)

Output
------
output/high_value_targets.json — ranked targets, each entry:
{
  "host":    "admin.example.com",
  "score":   47,
  "risk":    "CRITICAL",
  "reasons": [
    "Phase 4: CRITICAL asset (score +20)",
    "Phase 7: 3 sensitive endpoints (+10)",
    "Phase 9: Subdomain takeover — GitHub Pages confidence=0.95 (+20)"
  ],
  "source_breakdown": {
    "phase4": 20, "phase7": 10, "phase9": 20
  }
}
"""

from __future__ import annotations

import json
import logging
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from rich import box
from rich.console import Console
from rich.table import Table

from core.config import FrameworkConfig, Phase11Config
from core.models import RiskLevel

log     = logging.getLogger(__name__)
console = Console(stderr=True)

_RISK_COLOUR = {
    RiskLevel.CRITICAL: "bold bright_red",
    RiskLevel.HIGH:     "bright_red",
    RiskLevel.MEDIUM:   "bright_yellow",
    RiskLevel.LOW:      "bright_green",
    RiskLevel.INFO:     "dim white",
    RiskLevel.UNKNOWN:  "dim",
}

# Phase 8 finding-type → config attribute name
_P8_TYPE_TO_CFG = {
    "aws_key":           "p8_aws_key",
    "credential":        "p8_credential",
    "jwt":               "p8_jwt",
    "secret_assignment": "p8_secret_assignment",
    "secret_entropy":    "p8_secret_entropy",
    "internal_url":      "p8_internal_url",
    "source_map":        "p8_source_map",
    "graphql":           "p8_graphql",
    "endpoint":          "p8_endpoint",
    "api_route":         "p8_api_route",
    "package_ref":       "p8_package_ref",
    "commented_code":    "p8_commented_code",
}


# ---------------------------------------------------------------------------
# Per-host accumulator
# ---------------------------------------------------------------------------

@dataclass
class HostScore:
    host: str
    total:   int = 0
    reasons: list[str] = field(default_factory=list)
    breakdown: dict[str, int] = field(default_factory=lambda: defaultdict(int))
    risk: RiskLevel = RiskLevel.UNKNOWN

    def add(self, phase: str, points: int, reason: str) -> None:
        if points <= 0:
            return
        self.total += points
        self.breakdown[phase] += points
        self.reasons.append(reason)

    def finalise(self, cfg: Phase11Config) -> None:
        if self.total >= cfg.tier_critical:
            self.risk = RiskLevel.CRITICAL
        elif self.total >= cfg.tier_high:
            self.risk = RiskLevel.HIGH
        elif self.total >= cfg.tier_medium:
            self.risk = RiskLevel.MEDIUM
        elif self.total >= cfg.tier_low:
            self.risk = RiskLevel.LOW
        else:
            self.risk = RiskLevel.INFO


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

async def run_phase11(
    domain: str,
    config: FrameworkConfig,
) -> list[HostScore]:
    """
    Execute Phase 11.

    Reads all prior phase JSON outputs, aggregates scores per host,
    sorts, and writes output/high_value_targets.json.

    Returns
    -------
    Ranked list of HostScore objects (highest score first).
    """
    started = datetime.now(timezone.utc)
    log.info("Phase 11 starting", extra={"domain": domain})

    cfg = config.phase11

    # ------------------------------------------------------------------
    # Collect scores from all phases into per-host accumulators
    # ------------------------------------------------------------------
    scores: dict[str, HostScore] = {}

    def get(host: str) -> HostScore:
        if host not in scores:
            scores[host] = HostScore(host=host)
        return scores[host]

    _score_phase4 (config, cfg, get)
    _score_phase7 (config, cfg, get)
    _score_phase8 (config, cfg, get)
    _score_phase9 (config, cfg, get)
    _score_phase10(config, cfg, get)

    # ------------------------------------------------------------------
    # Finalise and sort
    # ------------------------------------------------------------------
    for hs in scores.values():
        hs.finalise(cfg)

    ranked = sorted(scores.values(), key=lambda h: -h.total)

    if cfg.max_targets:
        ranked = ranked[: cfg.max_targets]

    # Filter out zero-score hosts (no intelligence = not interesting)
    ranked = [h for h in ranked if h.total > 0]

    log.info(
        "Phase 11 scoring complete",
        extra={
            "total_hosts": len(scores),
            "ranked":      len(ranked),
            "critical":    sum(1 for h in ranked if h.risk == RiskLevel.CRITICAL),
            "high":        sum(1 for h in ranked if h.risk == RiskLevel.HIGH),
        },
    )

    # ------------------------------------------------------------------
    # Write JSON output
    # ------------------------------------------------------------------
    out_path = Path(config.output.high_value_targets_json)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    _write_json(ranked, domain, out_path)
    log.info("Wrote high_value_targets.json", extra={"path": str(out_path)})

    # ------------------------------------------------------------------
    # Print summary
    # ------------------------------------------------------------------
    elapsed = (datetime.now(timezone.utc) - started).total_seconds()
    _print_summary(ranked, domain, elapsed)

    return ranked


# ---------------------------------------------------------------------------
# Per-phase scorers
# ---------------------------------------------------------------------------

def _score_phase4(config, cfg: Phase11Config, get) -> None:
    """Phase 4 — Asset Intelligence findings."""
    path = Path(config.output.asset_intelligence_json)
    if not path.exists():
        return

    try:
        data     = json.loads(path.read_text())
        findings = data.get("findings", []) if isinstance(data, dict) else data
    except Exception as exc:
        log.warning("Failed to load asset_intelligence.json", extra={"error": str(exc)})
        return

    p4_map = {
        "CRITICAL": cfg.p4_critical,
        "HIGH":     cfg.p4_high,
        "MEDIUM":   cfg.p4_medium,
        "LOW":      cfg.p4_low,
    }

    for item in findings:
        host      = item.get("host", "").strip()
        risk      = item.get("risk_level", "").upper()
        pts       = p4_map.get(risk, 0)
        tags      = ", ".join(item.get("tags", [])[:3])
        top_reason = item.get("reasons", [""])[0][:60]

        if host and pts:
            hs = get(host)
            hs.add(
                "phase4", pts,
                f"Phase 4: {risk} asset — {top_reason or tags} (+{pts})",
            )


def _score_phase7(config, cfg: Phase11Config, get) -> None:
    """Phase 7 — reads phase11_score_contributions from JSON."""
    json_path = Path(config.output.sensitive_endpoints_txt).with_suffix(".json")
    if not json_path.exists():
        return

    try:
        data   = json.loads(json_path.read_text())
        contribs = data.get("phase11_score_contributions", {})
        # Also keep a count of findings per host for reason text
        findings = data.get("findings", [])
    except Exception as exc:
        log.warning("Failed to load sensitive_endpoints.json", extra={"error": str(exc)})
        return

    # Count CRITICAL + HIGH findings per host
    critical_by_host: dict[str, int] = defaultdict(int)
    for f in findings:
        if f.get("severity", "") in ("CRITICAL", "HIGH"):
            h = f.get("host", "")
            if h:
                critical_by_host[h] += 1

    for host, pts in contribs.items():
        if host and pts > 0:
            crit = critical_by_host.get(host, 0)
            hs   = get(host)
            hs.add(
                "phase7", pts,
                f"Phase 7: {pts} sensitive endpoint score"
                + (f" ({crit} CRITICAL/HIGH)" if crit else "")
                + f" (+{pts})",
            )


def _score_phase8(config, cfg: Phase11Config, get) -> None:
    """Phase 8 — JS Intelligence, scored per finding type."""
    path = Path(config.output.js_analysis_json)
    if not path.exists():
        return

    try:
        data     = json.loads(path.read_text())
        findings = data.get("findings", [])
    except Exception as exc:
        log.warning("Failed to load js_analysis.json", extra={"error": str(exc)})
        return

    # Aggregate: host → {type → count}
    host_type_counts: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    for f in findings:
        js_url = f.get("js_url", "")
        ftype  = f.get("finding_type", "")
        # Extract host from JS URL
        try:
            from urllib.parse import urlparse
            host = urlparse(js_url).hostname or ""
        except Exception:
            host = ""
        if host and ftype:
            host_type_counts[host][ftype] += 1

    for host, type_counts in host_type_counts.items():
        for ftype, count in type_counts.items():
            cfg_attr = _P8_TYPE_TO_CFG.get(ftype)
            if not cfg_attr:
                continue
            pts_per = getattr(cfg, cfg_attr, 0)
            # Score first occurrence at full weight, extras at 20%
            total_pts = pts_per + int(max(0, count - 1) * pts_per * 0.2)
            if total_pts > 0:
                hs = get(host)
                hs.add(
                    "phase8", total_pts,
                    f"Phase 8: {ftype} × {count} in JS files (+{total_pts})",
                )


def _score_phase9(config, cfg: Phase11Config, get) -> None:
    """Phase 9 — Takeover detection, scored by confidence band."""
    path = Path(config.output.takeovers_json)
    if not path.exists():
        return

    try:
        data      = json.loads(path.read_text())
        takeovers = data.get("takeovers", [])
    except Exception as exc:
        log.warning("Failed to load takeovers.json", extra={"error": str(exc)})
        return

    for t in takeovers:
        host    = t.get("host", "").strip()
        service = t.get("service", "Unknown")
        conf    = float(t.get("confidence", 0))
        method  = t.get("method", "unknown")

        if conf >= 0.85:
            pts = cfg.p9_high_conf
        elif conf >= 0.65:
            pts = cfg.p9_med_conf
        else:
            pts = cfg.p9_low_conf

        if host and pts:
            hs = get(host)
            hs.add(
                "phase9", pts,
                f"Phase 9: Takeover — {service} confidence={conf:.2f} via {method} (+{pts})",
            )


def _score_phase10(config, cfg: Phase11Config, get) -> None:
    """Phase 10 — reads phase11_score_contributions from nuclei_results.json."""
    path = Path(config.output.nuclei_results_json)
    if not path.exists():
        return

    try:
        data     = json.loads(path.read_text())
        contribs = data.get("phase11_score_contributions", {})
        findings = data.get("findings", [])
    except Exception as exc:
        log.warning("Failed to load nuclei_results.json", extra={"error": str(exc)})
        return

    # Top finding name per host for reason text
    top_by_host: dict[str, str] = {}
    for f in findings:
        h = f.get("host", "")
        if h and h not in top_by_host and f.get("severity") in ("critical", "high"):
            top_by_host[h] = f.get("name", "")

    for host, pts in contribs.items():
        if host and pts > 0:
            top = top_by_host.get(host, "")
            hs  = get(host)
            hs.add(
                "phase10", pts,
                f"Phase 10: scan score {pts}"
                + (f" — top: {top[:50]}" if top else "")
                + f" (+{pts})",
            )


# ---------------------------------------------------------------------------
# JSON writer
# ---------------------------------------------------------------------------

def _write_json(ranked: list[HostScore], domain: str, path: Path) -> None:
    dist: dict[str, int] = defaultdict(int)
    for h in ranked:
        dist[h.risk.value] += 1

    payload = {
        "meta": {
            "domain":       domain,
            "total_targets": len(ranked),
            "risk_distribution": dict(dist),
            "generated_at": datetime.now(timezone.utc).isoformat(),
        },
        "targets": [
            {
                "host":             hs.host,
                "score":            hs.total,
                "risk":             hs.risk.value,
                "reasons":          hs.reasons,
                "source_breakdown": dict(hs.breakdown),
            }
            for hs in ranked
        ],
    }

    with path.open("w") as fh:
        json.dump(payload, fh, indent=2, default=str)


# ---------------------------------------------------------------------------
# Rich summary
# ---------------------------------------------------------------------------

def _print_summary(ranked: list[HostScore], domain: str, elapsed: float) -> None:
    console.rule(f"[bold cyan]Phase 11 — Risk Scoring Engine[/] · {domain}")

    dist: dict[RiskLevel, int] = defaultdict(int)
    for h in ranked:
        dist[h.risk] += 1

    console.print(
        f"\n"
        f"  [bold red]◈  CRITICAL :[/] {dist[RiskLevel.CRITICAL]}\n"
        f"  [red]◈  HIGH     :[/] {dist[RiskLevel.HIGH]}\n"
        f"  [yellow]◈  MEDIUM   :[/] {dist[RiskLevel.MEDIUM]}\n"
        f"  [green]◈  LOW      :[/] {dist[RiskLevel.LOW]}\n"
        f"  [dim]◈  INFO     :[/] {dist[RiskLevel.INFO]}\n"
        f"  [bold blue]⏱  Duration  :[/] {elapsed:.2f}s\n"
    )

    top = ranked[:20]
    if top:
        tbl = Table(
            title=f"High-Value Targets (top {len(top)} of {len(ranked)})",
            box=box.SIMPLE_HEAD, show_edge=False,
        )
        tbl.add_column("Rank",  width=6,  justify="right")
        tbl.add_column("Risk",  width=10)
        tbl.add_column("Score", width=7,  justify="right", style="bold")
        tbl.add_column("Host",  style="bright_white", max_width=40, no_wrap=True)
        tbl.add_column("Sources", style="dim cyan", max_width=22, no_wrap=True)
        tbl.add_column("Top Reason", style="dim white", max_width=40, no_wrap=True)

        for rank, hs in enumerate(top, 1):
            colour   = _RISK_COLOUR.get(hs.risk, "white")
            risk_str = f"[{colour}]{hs.risk.value}[/]"
            sources  = "+".join(sorted(hs.breakdown.keys()))
            top_rsn  = hs.reasons[0][:40] if hs.reasons else ""
            tbl.add_row(
                str(rank), risk_str, str(hs.total),
                hs.host, sources, top_rsn,
            )
        console.print(tbl)

    console.rule()
