"""
phases/phase2_live_hosts.py
=============================
Phase 2 — Live Host Discovery Orchestrator

Workflow
--------
1. Load subdomains from Phase 1 output (DB or JSON).
2. Attempt to probe using httpx binary (fast, feature-rich).
3. If binary unavailable or crashes → fall back to aiohttp (pure Python).
4. Filter results to configured live status codes.
5. Persist every LiveHost to SQLite.
6. Write output/live_hosts.json.
7. Print Rich summary table.

Integration with Phase 1
------------------------
Reads  : output/subdomains.json  (or directly from DB)
Writes : output/live_hosts.json
         output/recon.db  (live_hosts table)
"""

from __future__ import annotations

import asyncio
import json
import logging
import shutil
from datetime import datetime, timezone
from pathlib import Path

from rich.console import Console
from rich.table import Table
from rich import box

from core.base_plugin import PluginContext
from core.config import FrameworkConfig
from core.database import Database
from core.models import LiveHost
from plugins.live_hosts import FALLBACK, PREFERRED

log = logging.getLogger(__name__)
console = Console(stderr=True)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

async def run_phase2(
    domain: str,
    config: FrameworkConfig,
    *,
    subdomains: list[str] | None = None,
) -> list[LiveHost]:
    """
    Execute Phase 2.

    Parameters
    ----------
    domain:     Target domain string (e.g. "example.com").
    config:     Loaded FrameworkConfig.
    subdomains: Optional pre-loaded hostname list.
                If None, hosts are read from Phase 1 outputs.

    Returns
    -------
    List of LiveHost objects representing all responsive hosts.
    """
    started = datetime.now(timezone.utc)
    log.info("Phase 2 starting", extra={"domain": domain})

    # ------------------------------------------------------------------
    # 1. Resolve hostname list
    # ------------------------------------------------------------------
    hosts = subdomains or await _load_subdomains(domain, config)
    if not hosts:
        log.warning("No subdomains to probe — did Phase 1 run?", extra={"domain": domain})
        return []

    log.info("Probing hostnames", extra={"count": len(hosts), "domain": domain})

    # ------------------------------------------------------------------
    # 2. Build shared plugin context
    # ------------------------------------------------------------------
    ctx = PluginContext(domain=domain, config=config)
    ctx.metadata["subdomains"] = hosts

    # ------------------------------------------------------------------
    # 3. Strategy: httpx binary → aiohttp fallback
    # ------------------------------------------------------------------
    live_hosts = await _probe_with_strategy(ctx)

    # ------------------------------------------------------------------
    # 4. Persist to DB
    # ------------------------------------------------------------------
    output_path = Path(config.output.live_hosts_json)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    async with Database(config.database.path) as db:
        for host in live_hosts:
            await db.upsert_live_host(host)

    log.info(
        "Live hosts persisted",
        extra={"count": len(live_hosts), "db": config.database.path},
    )

    # ------------------------------------------------------------------
    # 5. Write JSON output
    # ------------------------------------------------------------------
    _write_json(live_hosts, output_path)
    log.info("Wrote live_hosts.json", extra={"path": str(output_path)})

    # ------------------------------------------------------------------
    # 6. Print summary
    # ------------------------------------------------------------------
    elapsed = (datetime.now(timezone.utc) - started).total_seconds()
    _print_summary(live_hosts, domain, elapsed, ctx.errors)

    return live_hosts


# ---------------------------------------------------------------------------
# Strategy: try binary, fall back to aiohttp
# ---------------------------------------------------------------------------

async def _probe_with_strategy(ctx: PluginContext) -> list[LiveHost]:
    cfg = ctx.config.phase2
    binary_available = bool(shutil.which(cfg.httpx_bin))

    if binary_available:
        log.info(
            "httpx binary found — using binary prober",
            extra={"binary": cfg.httpx_bin},
        )
        prober = PREFERRED()
        result = await prober.execute(ctx)

        if result.success and result.data:
            return result.data

        # Binary ran but produced no results or soft-failed
        log.warning(
            "httpx binary prober unsuccessful — switching to aiohttp fallback",
            extra={"error": result.error},
        )
    else:
        log.info(
            "httpx binary not found — using aiohttp fallback",
            extra={"searched": cfg.httpx_bin},
        )

    # aiohttp fallback
    fallback = FALLBACK()
    result = await fallback.execute(ctx)

    if result.success and result.data:
        return result.data

    log.error(
        "Both probers failed",
        extra={"error": result.error, "errors": ctx.errors},
    )
    return []


# ---------------------------------------------------------------------------
# Load subdomains from Phase 1 outputs
# ---------------------------------------------------------------------------

async def _load_subdomains(domain: str, config: FrameworkConfig) -> list[str]:
    """
    Load hostnames from:
      1. output/subdomains.json  (preferred — richer source metadata)
      2. output/subdomains.txt   (plain list fallback)
      3. SQLite DB               (last resort)
    """
    json_path = Path(config.output.subdomains_json)
    txt_path  = Path(config.output.subdomains_txt)

    if json_path.exists():
        log.debug("Loading subdomains from JSON", extra={"path": str(json_path)})
        with json_path.open() as fh:
            data = json.load(fh)
        # DiscoveryResult JSON: {"subdomains": [{"host": "..."}, ...]}
        if isinstance(data, dict) and "subdomains" in data:
            return [s["host"] for s in data["subdomains"]]
        # Plain list of strings fallback
        if isinstance(data, list):
            return [s if isinstance(s, str) else s.get("host", "") for s in data]

    if txt_path.exists():
        log.debug("Loading subdomains from TXT", extra={"path": str(txt_path)})
        return [
            line.strip()
            for line in txt_path.read_text().splitlines()
            if line.strip()
        ]

    log.info("Loading subdomains from DB", extra={"domain": domain})
    try:
        async with Database(config.database.path) as db:
            subs = await db.get_subdomains(domain)
            return [s.host for s in subs]
    except Exception as exc:
        log.error("Failed to load subdomains from DB", extra={"error": str(exc)})
        return []


# ---------------------------------------------------------------------------
# JSON output
# ---------------------------------------------------------------------------

def _write_json(hosts: list[LiveHost], path: Path) -> None:
    payload = {
        "meta": {
            "total": len(hosts),
            "generated_at": datetime.now(timezone.utc).isoformat(),
        },
        "hosts": [h.model_dump() for h in hosts],
    }
    with path.open("w") as fh:
        json.dump(payload, fh, indent=2, default=str)


# ---------------------------------------------------------------------------
# Rich terminal summary
# ---------------------------------------------------------------------------

def _print_summary(
    hosts: list[LiveHost],
    domain: str,
    elapsed: float,
    errors: list[dict],
) -> None:
    console.rule(f"[bold cyan]Phase 2 — Live Host Discovery[/] · {domain}")

    # Status code distribution
    code_dist: dict[int, int] = {}
    for h in hosts:
        code_dist[h.status_code or 0] = code_dist.get(h.status_code or 0, 0) + 1

    # --- Stats panel ---
    console.print(
        f"\n  [bold green]✔ Live hosts found   :[/] {len(hosts)}\n"
        f"  [bold yellow]⚑ Errors             :[/] {len(errors)}\n"
        f"  [bold blue]⏱  Duration           :[/] {elapsed:.1f}s\n"
    )

    # --- Status code breakdown ---
    sc_table = Table(title="Status Code Distribution", box=box.SIMPLE_HEAD, show_edge=False)
    sc_table.add_column("Code", style="cyan", width=8)
    sc_table.add_column("Count", style="bright_white", justify="right")

    for code in sorted(code_dist):
        colour = "green" if code < 400 else ("yellow" if code < 500 else "red")
        sc_table.add_row(f"[{colour}]{code}[/]", str(code_dist[code]))
    console.print(sc_table)

    # --- Top 15 live hosts preview ---
    if hosts:
        preview = sorted(hosts, key=lambda h: (h.status_code or 999))[:15]
        host_table = Table(
            title=f"Live Hosts Preview (top {len(preview)})",
            box=box.SIMPLE_HEAD,
            show_edge=False,
        )
        host_table.add_column("URL",           style="bright_white", max_width=55, no_wrap=True)
        host_table.add_column("Status",        style="cyan",  width=8, justify="center")
        host_table.add_column("Title",         style="yellow", max_width=30, no_wrap=True)
        host_table.add_column("Server",        style="dim white", max_width=20, no_wrap=True)
        host_table.add_column("IP",            style="dim cyan", width=16)
        host_table.add_column("Redirects",     style="dim",  width=10, justify="right")

        for h in preview:
            status_str = str(h.status_code or "?")
            if h.status_code and h.status_code < 300:
                status_str = f"[green]{status_str}[/]"
            elif h.status_code and h.status_code < 400:
                status_str = f"[yellow]{status_str}[/]"
            elif h.status_code and h.status_code >= 400:
                status_str = f"[red]{status_str}[/]"

            host_table.add_row(
                h.url,
                status_str,
                h.title or "",
                h.web_server or "",
                h.ip_address or "",
                str(len(h.redirect_chain)),
            )
        console.print(host_table)

    if errors:
        console.print(f"\n[bold red]⚠  {len(errors)} error(s) recorded — check output/recon.log[/]")

    console.rule()
