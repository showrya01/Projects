"""
phases/phase6_urls.py
=======================
Phase 6 — Historical URL Collection Orchestrator

Workflow
--------
1. Run all three collectors (GAU, Wayback, Common Crawl) in parallel.
2. Feed each collector's output through the smart URLFilter as it arrives.
   - Deduplication is maintained across all sources via the shared filter.
3. Write output/urls.txt  (one URL per line, for tool piping).
4. Write output/urls.json (with per-URL source metadata + stats).
5. Return the filtered URL list in-memory for Phase 7 to consume directly.

Integration
-----------
Reads  : nothing (queries live APIs / binary)
Writes : output/urls.txt
         output/urls.json
"""

from __future__ import annotations

import asyncio
import json
import logging
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from rich import box
from rich.console import Console
from rich.table import Table

from core.base_plugin import PluginContext, PluginResult
from core.config import FrameworkConfig
from plugins.urls import ALL_COLLECTORS
from plugins.urls.filter import URLFilter

log     = logging.getLogger(__name__)
console = Console(stderr=True)


# ---------------------------------------------------------------------------
# Result models
# ---------------------------------------------------------------------------

@dataclass
class CollectorStats:
    name:        str
    raw_count:   int = 0     # URLs before filter
    kept_count:  int = 0     # URLs after filter
    duration_s:  float = 0.0
    error:       str | None = None


@dataclass
class Phase6Result:
    domain:      str
    urls:        list[str] = field(default_factory=list)
    stats:       list[CollectorStats] = field(default_factory=list)
    total_raw:   int = 0
    total_kept:  int = 0
    started_at:  datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    finished_at: datetime | None = None
    duration_s:  float = 0.0


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

async def run_phase6(
    domain: str,
    config: FrameworkConfig,
) -> Phase6Result:
    """
    Execute Phase 6.

    Returns a Phase6Result whose .urls list can be passed directly to
    the Phase 7 orchestrator without touching disk.
    """
    started = datetime.now(timezone.utc)
    log.info("Phase 6 starting", extra={"domain": domain})

    ctx    = PluginContext(domain=domain, config=config)
    filt   = URLFilter(config.phase6)
    result = Phase6Result(domain=domain)

    # ------------------------------------------------------------------
    # Run all collectors in parallel — each feeds into the shared filter
    # ------------------------------------------------------------------
    collector_instances = [C() for C in ALL_COLLECTORS]

    raw_results: list[PluginResult[list[str]]] = await asyncio.gather(
        *[c.execute(ctx) for c in collector_instances],
        return_exceptions=False,
    )

    # ------------------------------------------------------------------
    # Merge results through the filter
    # ------------------------------------------------------------------
    all_filtered: list[str] = []
    for plugin_result, collector in zip(raw_results, collector_instances):
        raw_urls   = plugin_result.data or []
        kept_urls  = filt.filter_batch(raw_urls)

        all_filtered.extend(kept_urls)

        result.stats.append(CollectorStats(
            name       = collector.NAME,
            raw_count  = len(raw_urls),
            kept_count = len(kept_urls),
            duration_s = round(plugin_result.duration_seconds, 2),
            error      = plugin_result.error,
        ))

        if plugin_result.error:
            log.warning(
                "Collector had errors",
                extra={"collector": collector.NAME, "error": plugin_result.error},
            )

    # Final dedup across all sources (filter already deduped within each
    # batch, but the same URL could come from GAU and Wayback)
    result.urls       = list(dict.fromkeys(all_filtered))   # preserve order
    result.total_raw  = sum(s.raw_count  for s in result.stats)
    result.total_kept = len(result.urls)

    # ------------------------------------------------------------------
    # Write outputs
    # ------------------------------------------------------------------
    out_dir = Path(config.output.base_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    _write_txt(result.urls, Path(config.output.urls_txt))
    _write_json(result, Path(config.output.urls_txt.replace(".txt", ".json")))

    # ------------------------------------------------------------------
    # Finalise
    # ------------------------------------------------------------------
    result.finished_at = datetime.now(timezone.utc)
    result.duration_s  = (result.finished_at - started).total_seconds()

    log.info(
        "Phase 6 complete",
        extra={
            "domain":     domain,
            "total_raw":  result.total_raw,
            "total_kept": result.total_kept,
            "duration_s": round(result.duration_s, 1),
        },
    )

    _print_summary(result)
    return result


# ---------------------------------------------------------------------------
# Writers
# ---------------------------------------------------------------------------

def _write_txt(urls: list[str], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as fh:
        fh.write("\n".join(urls))
        if urls:
            fh.write("\n")
    log.info("Wrote urls.txt", extra={"path": str(path), "count": len(urls)})


def _write_json(result: Phase6Result, path: Path) -> None:
    # Bucket URLs by category for fast Phase 7 consumption
    ext_buckets: dict[str, list[str]] = defaultdict(list)
    param_urls:  list[str]            = []
    segment_urls: list[str]           = []

    from urllib.parse import urlparse, parse_qs
    from plugins.urls.filter import (
        _has_interesting_extension,
        _has_interesting_param,
        _has_interesting_segment,
    )

    cfg_ext    = result.stats[0].name if result.stats else ""
    # Re-use default config extensions for bucketing
    from core.config import Phase6Config
    _default_ext = Phase6Config().interesting_extensions
    _default_par = Phase6Config().interesting_params

    for url in result.urls:
        path_part = urlparse(url).path
        ext = next(
            (e for e in _default_ext if path_part.lower().endswith(e)),
            None,
        )
        if ext:
            ext_buckets[ext].append(url)
        if _has_interesting_param(url, _default_par):
            param_urls.append(url)
        if _has_interesting_segment(path_part):
            segment_urls.append(url)

    payload = {
        "meta": {
            "domain":      result.domain,
            "total_raw":   result.total_raw,
            "total_kept":  result.total_kept,
            "duration_s":  result.duration_s,
            "generated_at": datetime.now(timezone.utc).isoformat(),
        },
        "collector_stats": [
            {
                "name":       s.name,
                "raw_count":  s.raw_count,
                "kept_count": s.kept_count,
                "duration_s": s.duration_s,
                "error":      s.error,
            }
            for s in result.stats
        ],
        "buckets": {
            "by_extension": {
                ext: len(urls_list)
                for ext, urls_list in sorted(
                    ext_buckets.items(), key=lambda x: -len(x[1])
                )
            },
            "param_bearing":  len(param_urls),
            "segment_match":  len(segment_urls),
        },
        "urls": result.urls,
    }

    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as fh:
        json.dump(payload, fh, indent=2)
    log.info("Wrote urls.json", extra={"path": str(path), "count": len(result.urls)})


# ---------------------------------------------------------------------------
# Rich summary
# ---------------------------------------------------------------------------

def _print_summary(result: Phase6Result) -> None:
    console.rule(f"[bold cyan]Phase 6 — Historical URL Collection[/] · {result.domain}")

    console.print(
        f"\n"
        f"  [bold green]✔ URLs collected   :[/] {result.total_kept:,}\n"
        f"  [dim]◈  Raw before filter:[/] {result.total_raw:,}\n"
        f"  [dim]◈  Dedup ratio      :[/] "
        f"{(1 - result.total_kept / max(result.total_raw, 1)) * 100:.0f}% removed\n"
        f"  [bold blue]⏱  Duration         :[/] {result.duration_s:.1f}s\n"
    )

    # Per-collector stats
    tbl = Table(title="Collector Breakdown", box=box.SIMPLE_HEAD, show_edge=False)
    tbl.add_column("Source",     style="bright_white", width=16)
    tbl.add_column("Raw URLs",   style="dim",          justify="right", width=12)
    tbl.add_column("Kept",       style="cyan",         justify="right", width=10)
    tbl.add_column("Time (s)",   style="dim",          justify="right", width=10)
    tbl.add_column("Status",     width=12)

    for s in result.stats:
        status = "[green]OK[/]" if not s.error else "[red]ERROR[/]"
        if s.raw_count == 0 and not s.error:
            status = "[dim]SKIPPED[/]"
        tbl.add_row(
            s.name,
            f"{s.raw_count:,}",
            f"{s.kept_count:,}",
            f"{s.duration_s:.1f}",
            status,
        )
    console.print(tbl)

    # Extension breakdown (top 10)
    from urllib.parse import urlparse
    from collections import Counter
    from core.config import Phase6Config

    ext_counter: Counter = Counter()
    for url in result.urls:
        p = urlparse(url).path.lower().split("?")[0]
        for ext in Phase6Config().interesting_extensions:
            if p.endswith(ext):
                ext_counter[ext] += 1
                break

    if ext_counter:
        ext_tbl = Table(
            title="Top Extensions Found", box=box.SIMPLE_HEAD, show_edge=False
        )
        ext_tbl.add_column("Extension", style="cyan",        width=12)
        ext_tbl.add_column("Count",     style="bright_white", justify="right", width=8)
        ext_tbl.add_column("Bar",       style="green",        min_width=20)

        top_ext  = ext_counter.most_common(10)
        max_cnt  = top_ext[0][1] if top_ext else 1
        for ext, cnt in top_ext:
            bar = "█" * int((cnt / max_cnt) * 20)
            ext_tbl.add_row(ext, str(cnt), bar)
        console.print(ext_tbl)

    console.rule()
