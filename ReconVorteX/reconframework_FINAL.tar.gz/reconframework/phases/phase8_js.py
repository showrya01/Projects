"""
phases/phase8_js.py
=====================
Phase 8 — JavaScript Intelligence Orchestrator

Workflow
--------
1. Load Phase 6 URL list + Phase 2 live hosts.
2. Discover JS files from both sources via JSFetcher.
3. Run JSExtractor on every fetched JS file.
4. Aggregate findings, deduplicate, sort by confidence.
5. Persist to SQLite (js_findings table).
6. Write output/js_analysis.json.
7. Print Rich summary grouped by finding type.

Integration
-----------
Reads  : output/urls.json       (Phase 6 — JS URL discovery)
         output/live_hosts.json (Phase 2 — script tag scraping)
Writes : output/js_analysis.json
         output/recon.db (js_findings table)
"""

from __future__ import annotations

import json
import logging
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

from rich import box
from rich.console import Console
from rich.table import Table

from core.config import FrameworkConfig
from plugins.js.extractors import JSExtractor, JSFinding
from plugins.js.fetcher import JSFetcher

log     = logging.getLogger(__name__)
console = Console(stderr=True)

_TYPE_COLOUR: dict[str, str] = {
    "aws_key":           "bold bright_red",
    "credential":        "bold bright_red",
    "jwt":               "bright_red",
    "secret_assignment": "bright_red",
    "secret_entropy":    "bright_red",
    "internal_url":      "bright_yellow",
    "source_map":        "bright_yellow",
    "commented_code":    "yellow",
    "endpoint":          "cyan",
    "api_route":         "cyan",
    "graphql":           "bright_cyan",
    "aws_s3":            "bright_magenta",
    "package_ref":       "dim white",
}

_HIGH_VALUE_TYPES = frozenset([
    "aws_key", "credential", "jwt", "secret_assignment",
    "secret_entropy", "internal_url",
])


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

async def run_phase8(
    domain: str,
    config: FrameworkConfig,
    *,
    phase6_urls: list[str] | None = None,
    live_hosts:  list[dict] | None = None,
) -> list[JSFinding]:
    """
    Execute Phase 8.

    Parameters
    ----------
    domain:      Target domain string.
    config:      Loaded FrameworkConfig.
    phase6_urls: Optional pre-loaded Phase 6 URL list (in-memory).
    live_hosts:  Optional pre-loaded Phase 2 live host dicts.

    Returns
    -------
    Deduplicated list of JSFinding objects sorted by confidence desc.
    """
    started = datetime.now(timezone.utc)
    log.info("Phase 8 starting", extra={"domain": domain})

    cfg = config.phase8

    # ------------------------------------------------------------------
    # 1. Load input data
    # ------------------------------------------------------------------
    urls_data  = phase6_urls or _load_urls(config)
    hosts_data = live_hosts  or _load_hosts(config)

    log.info(
        "Input loaded",
        extra={"urls": len(urls_data), "live_hosts": len(hosts_data)},
    )

    # ------------------------------------------------------------------
    # 2. Discover and fetch JS files
    # ------------------------------------------------------------------
    fetcher       = JSFetcher(cfg)
    discovery     = await fetcher.discover_and_fetch(
        phase6_urls=urls_data,
        live_hosts=hosts_data,
    )

    if not discovery.fetched:
        log.warning(
            "No JS files fetched",
            extra={"skipped": len(discovery.skipped), "errors": len(discovery.errors)},
        )
        return []

    log.info(
        "JS files fetched",
        extra={"count": len(discovery.fetched), "total_urls": len(discovery.js_urls)},
    )

    # ------------------------------------------------------------------
    # 3. Extract intelligence from each file
    # ------------------------------------------------------------------
    extractor = JSExtractor(
        entropy_threshold=cfg.entropy_threshold,
        min_len=cfg.min_secret_length,
        max_len=cfg.max_secret_length,
    )

    all_findings: list[JSFinding] = []
    for fetched in discovery.fetched:
        file_findings = extractor.extract(fetched.url, fetched.source)
        all_findings.extend(file_findings)
        if file_findings:
            log.debug(
                "JS file analysed",
                extra={"url": fetched.url, "findings": len(file_findings)},
            )

    # Global dedup across all files (same value from multiple files = one finding)
    all_findings = _global_dedup(all_findings)

    log.info(
        "JS analysis complete",
        extra={"total_findings": len(all_findings), "js_files": len(discovery.fetched)},
    )

    # ------------------------------------------------------------------
    # 4. Write JSON output
    # ------------------------------------------------------------------
    out_path = Path(config.output.js_analysis_json)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    _write_json(all_findings, discovery, out_path, domain)
    log.info("Wrote js_analysis.json", extra={"path": str(out_path)})

    # ------------------------------------------------------------------
    # 5. Summary
    # ------------------------------------------------------------------
    elapsed = (datetime.now(timezone.utc) - started).total_seconds()
    _print_summary(all_findings, discovery, domain, elapsed)

    return all_findings


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _global_dedup(findings: list[JSFinding]) -> list[JSFinding]:
    """Keep highest-confidence finding per (type, value) across all JS files."""
    best: dict[tuple[str, str], JSFinding] = {}
    for f in findings:
        key = (f.finding_type, f.value[:60])
        if key not in best or f.confidence > best[key].confidence:
            best[key] = f
    return sorted(best.values(), key=lambda f: (-f.confidence, f.finding_type))


def _load_urls(config: FrameworkConfig) -> list[str]:
    json_path = Path(config.output.urls_txt.replace(".txt", ".json"))
    txt_path  = Path(config.output.urls_txt)
    if json_path.exists():
        try:
            data = json.loads(json_path.read_text())
            if isinstance(data, dict):
                return data.get("urls", [])
            return data if isinstance(data, list) else []
        except Exception:
            pass
    if txt_path.exists():
        return [l.strip() for l in txt_path.read_text().splitlines() if l.strip()]
    return []


def _load_hosts(config: FrameworkConfig) -> list[dict]:
    path = Path(config.output.live_hosts_json)
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text())
        if isinstance(data, dict):
            return data.get("hosts", [])
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _write_json(
    findings:  list[JSFinding],
    discovery,
    path:      Path,
    domain:    str,
) -> None:
    # Type distribution
    type_dist: dict[str, int] = defaultdict(int)
    for f in findings:
        type_dist[f.finding_type] += 1

    # Per-JS-file summary
    file_summary: dict[str, int] = defaultdict(int)
    for f in findings:
        file_summary[f.js_url] += 1

    payload = {
        "meta": {
            "domain":          domain,
            "total_findings":  len(findings),
            "js_files_fetched": len(discovery.fetched),
            "js_files_skipped": len(discovery.skipped),
            "generated_at":    datetime.now(timezone.utc).isoformat(),
        },
        "type_distribution":  dict(sorted(type_dist.items(), key=lambda x: -x[1])),
        "findings_per_file":  dict(sorted(file_summary.items(), key=lambda x: -x[1])[:20]),
        "findings": [
            {
                "js_url":       f.js_url,
                "finding_type": f.finding_type,
                "value":        f.value,
                "context":      f.context,
                "confidence":   f.confidence,
            }
            for f in findings
        ],
    }

    with path.open("w") as fh:
        json.dump(payload, fh, indent=2, default=str)


def _print_summary(
    findings:  list[JSFinding],
    discovery,
    domain:    str,
    elapsed:   float,
) -> None:
    console.rule(f"[bold cyan]Phase 8 — JavaScript Intelligence[/] · {domain}")

    hv = [f for f in findings if f.finding_type in _HIGH_VALUE_TYPES]

    console.print(
        f"\n"
        f"  [bold green]✔ JS files fetched  :[/] {len(discovery.fetched)}\n"
        f"  [bold cyan]◈  Total findings    :[/] {len(findings)}\n"
        f"  [bold red]⚑  High-value hits   :[/] {len(hv)}\n"
        f"  [dim]◈  Files skipped     :[/] {len(discovery.skipped)}\n"
        f"  [bold blue]⏱  Duration          :[/] {elapsed:.1f}s\n"
    )

    # Type distribution table
    type_dist: dict[str, int] = defaultdict(int)
    for f in findings:
        type_dist[f.finding_type] += 1

    if type_dist:
        tbl = Table(title="Finding Type Distribution", box=box.SIMPLE_HEAD, show_edge=False)
        tbl.add_column("Type",  style="bright_white", min_width=22)
        tbl.add_column("Count", style="cyan", justify="right", width=8)
        tbl.add_column("Bar",   style="green", min_width=20)
        max_cnt = max(type_dist.values())
        for t, cnt in sorted(type_dist.items(), key=lambda x: -x[1]):
            colour = _TYPE_COLOUR.get(t, "white")
            bar    = "█" * int((cnt / max_cnt) * 20)
            tbl.add_row(f"[{colour}]{t}[/]", str(cnt), bar)
        console.print(tbl)

    # High-value findings preview
    if hv:
        hv_tbl = Table(
            title="[bold red]⚑ High-Value Findings (top 15)[/]",
            box=box.SIMPLE_HEAD, show_edge=False,
        )
        hv_tbl.add_column("Type",  style="bright_red", width=20)
        hv_tbl.add_column("Value", style="bright_white", max_width=55, no_wrap=True)
        hv_tbl.add_column("JS File", style="dim cyan", max_width=35, no_wrap=True)
        hv_tbl.add_column("Conf", justify="right", width=6)
        from pathlib import Path as _P
        for f in hv[:15]:
            hv_tbl.add_row(
                f.finding_type,
                f.value[:55],
                _P(f.js_url).name,
                f"{f.confidence:.2f}",
            )
        console.print(hv_tbl)

    console.rule()
