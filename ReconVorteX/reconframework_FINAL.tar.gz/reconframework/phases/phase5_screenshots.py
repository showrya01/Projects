"""
phases/phase5_screenshots.py
==============================
Phase 5 — Screenshot Collection Orchestrator

Workflow
--------
1. Load Phase 4 asset intelligence (CRITICAL/HIGH hosts first).
2. Fill remaining slots from Phase 2 live hosts up to cfg.max_hosts.
3. Run GowitnessRunner with the prioritised URL list.
4. Map screenshot files back to their source URLs + intelligence metadata.
5. Build a self-contained HTML gallery (output/screenshots/index.html).
6. Write a metadata JSON (output/screenshots/metadata.json).
7. Print Rich summary.

Integration
-----------
Reads  : output/asset_intelligence.json   (Phase 4 — priority hosts)
         output/live_hosts.json           (Phase 2 — all live hosts)
Writes : output/screenshots/*.png         (Gowitness)
         output/screenshots/index.html    (gallery)
         output/screenshots/metadata.json
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from rich import box
from rich.console import Console
from rich.table import Table

from core.base_plugin import PluginContext
from core.config import FrameworkConfig
from plugins.screenshots.gallery import GalleryEntry, build_gallery
from plugins.screenshots.gowitness_runner import GowitnessRunner, ScreenshotResult

log     = logging.getLogger(__name__)
console = Console(stderr=True)


# ---------------------------------------------------------------------------
# Result model
# ---------------------------------------------------------------------------

@dataclass
class Phase5Result:
    domain:        str
    total_urls:    int = 0
    total_success: int = 0
    total_failed:  int = 0
    gallery_path:  str | None = None
    screenshots:   list[ScreenshotResult] = field(default_factory=list)
    duration_s:    float = 0.0


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

async def run_phase5(
    domain: str,
    config: FrameworkConfig,
    *,
    live_hosts:    list[dict] | None = None,
    intelligence:  list[dict] | None = None,
) -> Phase5Result:
    """
    Execute Phase 5.

    Parameters
    ----------
    domain:       Target domain.
    config:       Loaded FrameworkConfig.
    live_hosts:   Optional pre-loaded Phase 2 live host dicts.
    intelligence: Optional pre-loaded Phase 4 asset intelligence dicts.

    Returns
    -------
    Phase5Result with screenshot paths and gallery location.
    """
    started = datetime.now(timezone.utc)
    log.info("Phase 5 starting", extra={"domain": domain})

    cfg    = config.phase5
    result = Phase5Result(domain=domain)

    # ------------------------------------------------------------------
    # 1. Build prioritised URL list
    # ------------------------------------------------------------------
    intel_data = intelligence or _load_json_list(
        config.output.asset_intelligence_json, "findings"
    )
    hosts_data = live_hosts or _load_json_list(
        config.output.live_hosts_json, "hosts"
    )

    urls = _build_url_list(intel_data, hosts_data, cfg)
    result.total_urls = len(urls)

    if not urls:
        log.warning("No URLs to screenshot — did Phase 2/4 run?")
        return result

    log.info(
        "Screenshot targets selected",
        extra={"count": len(urls), "max": cfg.max_hosts},
    )

    # ------------------------------------------------------------------
    # 2. Run Gowitness
    # ------------------------------------------------------------------
    ctx = PluginContext(domain=domain, config=config)
    ctx.metadata["screenshot_urls"] = urls

    runner       = GowitnessRunner()
    plugin_result = await runner.execute(ctx)
    screenshots  = plugin_result.data or []

    result.screenshots   = screenshots
    result.total_success = sum(1 for s in screenshots if s.file_path)
    result.total_failed  = len(screenshots) - result.total_success

    # ------------------------------------------------------------------
    # 3. Build intelligence lookup for gallery enrichment
    # ------------------------------------------------------------------
    intel_by_url:  dict[str, dict] = {}
    intel_by_host: dict[str, dict] = {}
    for item in intel_data:
        if item.get("url"):
            intel_by_url[item["url"]] = item
        if item.get("host"):
            intel_by_host[item["host"]] = item

    # ------------------------------------------------------------------
    # 4. Build gallery entries
    # ------------------------------------------------------------------
    gallery_entries: list[GalleryEntry] = []
    for shot in screenshots:
        if not shot.file_path:
            continue
        intel = intel_by_url.get(shot.url) or intel_by_host.get(
            _host_from_url(shot.url), {}
        )
        from urllib.parse import urlparse
        host = urlparse(shot.url).hostname or shot.url
        gallery_entries.append(GalleryEntry(
            url=shot.url,
            file_path=shot.file_path,
            host=host,
            risk_level=intel.get("risk_level", "UNKNOWN"),
            tags=intel.get("tags", []),
            title=intel.get("title", ""),
        ))

    # Sort CRITICAL/HIGH first in gallery
    _risk_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4, "UNKNOWN": 5}
    gallery_entries.sort(key=lambda e: _risk_order.get(e.risk_level.upper(), 5))

    # ------------------------------------------------------------------
    # 5. Write HTML gallery
    # ------------------------------------------------------------------
    gallery_path = Path(cfg.gallery_file)
    ok = build_gallery(
        gallery_entries,
        gallery_path,
        title=cfg.gallery_title,
        per_row=cfg.thumbnails_per_row,
    )
    if ok:
        result.gallery_path = str(gallery_path)

    # ------------------------------------------------------------------
    # 6. Write metadata JSON
    # ------------------------------------------------------------------
    meta_path = Path(cfg.output_dir) / "metadata.json"
    _write_metadata(result, screenshots, intel_by_url, intel_by_host, meta_path, domain)

    # ------------------------------------------------------------------
    # 7. Summary
    # ------------------------------------------------------------------
    result.duration_s = (datetime.now(timezone.utc) - started).total_seconds()
    log.info(
        "Phase 5 complete",
        extra={
            "total_urls":    result.total_urls,
            "total_success": result.total_success,
            "duration_s":    round(result.duration_s, 1),
        },
    )
    _print_summary(result)
    return result


# ---------------------------------------------------------------------------
# Host selection
# ---------------------------------------------------------------------------

def _build_url_list(
    intel_data: list[dict],
    hosts_data: list[dict],
    cfg,
) -> list[str]:
    """
    Build a de-duplicated, prioritised list of URLs to screenshot.

    Order:
      1. Phase 4 CRITICAL/HIGH assets.
      2. Remaining Phase 2 live hosts up to cfg.max_hosts.
    """
    seen: set[str] = set()
    urls: list[str] = []

    priority_set = {r.upper() for r in cfg.priority_risk_levels}

    # Priority: Phase 4 intelligence findings
    for item in intel_data:
        if item.get("risk_level", "").upper() in priority_set:
            url = item.get("url", "")
            if url and url not in seen:
                seen.add(url)
                urls.append(url)
            if len(urls) >= cfg.max_hosts:
                return urls

    # Fill remaining from Phase 2
    for host in hosts_data:
        url = host.get("url", "")
        if url and url not in seen:
            seen.add(url)
            urls.append(url)
        if len(urls) >= cfg.max_hosts:
            break

    return urls


def _host_from_url(url: str) -> str:
    from urllib.parse import urlparse
    return urlparse(url).hostname or url


# ---------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------

def _load_json_list(path_str: str, list_key: str) -> list[dict]:
    path = Path(path_str)
    if not path.exists():
        return []
    try:
        with path.open() as fh:
            data = json.load(fh)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return data.get(list_key, [])
    except Exception as exc:
        log.warning("Failed to load JSON", extra={"path": path_str, "error": str(exc)})
    return []


def _write_metadata(
    result:        Phase5Result,
    screenshots:   list[ScreenshotResult],
    intel_by_url:  dict,
    intel_by_host: dict,
    path:          Path,
    domain:        str,
) -> None:
    from urllib.parse import urlparse
    entries = []
    for shot in screenshots:
        host  = urlparse(shot.url).hostname or shot.url
        intel = intel_by_url.get(shot.url) or intel_by_host.get(host, {})
        entries.append({
            "url":        shot.url,
            "host":       host,
            "file_path":  shot.file_path,
            "success":    shot.success,
            "error":      shot.error,
            "risk_level": intel.get("risk_level", "UNKNOWN"),
            "tags":       intel.get("tags", []),
        })

    payload = {
        "meta": {
            "domain":        domain,
            "total_urls":    result.total_urls,
            "total_success": result.total_success,
            "total_failed":  result.total_failed,
            "gallery":       result.gallery_path,
            "generated_at":  datetime.now(timezone.utc).isoformat(),
        },
        "screenshots": entries,
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as fh:
        json.dump(payload, fh, indent=2, default=str)
    log.info("Wrote screenshots/metadata.json", extra={"path": str(path)})


# ---------------------------------------------------------------------------
# Rich summary
# ---------------------------------------------------------------------------

def _print_summary(result: Phase5Result) -> None:
    console.rule(f"[bold cyan]Phase 5 — Screenshot Collection[/] · {result.domain}")

    success_pct = (
        round(result.total_success / result.total_urls * 100, 1)
        if result.total_urls else 0
    )

    console.print(
        f"\n"
        f"  [bold green]✔ Screenshots taken :[/] {result.total_success}\n"
        f"  [red]✗ Failed            :[/] {result.total_failed}\n"
        f"  [cyan]◈  Success rate      :[/] {success_pct}%\n"
        f"  [bold blue]⏱  Duration          :[/] {result.duration_s:.1f}s\n"
    )

    if result.gallery_path:
        console.print(
            f"  [bold cyan]🖼  Gallery           :[/] {result.gallery_path}\n"
        )

    # Show top 10 captures
    captured = [s for s in result.screenshots if s.file_path][:10]
    if captured:
        tbl = Table(
            title=f"Screenshots (top {len(captured)})",
            box=box.SIMPLE_HEAD, show_edge=False,
        )
        tbl.add_column("URL",    style="bright_white", max_width=55, no_wrap=True)
        tbl.add_column("File",   style="dim cyan",     max_width=30, no_wrap=True)
        tbl.add_column("Status", width=8)
        for s in captured:
            fname = Path(s.file_path).name if s.file_path else "—"
            status = "[green]OK[/]" if s.file_path else "[red]FAIL[/]"
            tbl.add_row(s.url, fname, status)
        console.print(tbl)

    console.rule()
