"""
phases/phase3_technology.py
=============================
Phase 3 — Technology Intelligence Orchestrator

Workflow
--------
1. Load live hosts from Phase 2 output (live_hosts.json or DB).
2. For each host, re-fetch headers + HTML body via Phase3Fetcher.
3. Run TechFingerprinter.match() against the raw probe result,
   seeding it with any technology names Phase 2 already detected.
4. Filter matches below cfg.phase3.min_confidence.
5. Persist TechnologyFingerprint records to SQLite.
6. Write output/technologies.json.
7. Print Rich summary table grouped by category.

Integration
-----------
Reads  : output/live_hosts.json
Writes : output/technologies.json
         output/recon.db  (technologies table)
"""

from __future__ import annotations

import asyncio
import json
import logging
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

from rich import box
from rich.console import Console
from rich.table import Table

from core.config import FrameworkConfig
from core.database import Database
from core.models import TechnologyFingerprint
from plugins.technology.fetcher import Phase3Fetcher
from plugins.technology.fingerprinter import TechFingerprinter, TechMatch
from plugins.technology.signatures import TechCategory

log = logging.getLogger(__name__)
console = Console(stderr=True)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

async def run_phase3(
    domain: str,
    config: FrameworkConfig,
    *,
    live_hosts: list[dict] | None = None,
) -> list[TechnologyFingerprint]:
    """
    Execute Phase 3.

    Parameters
    ----------
    domain:     Target domain string.
    config:     Loaded FrameworkConfig.
    live_hosts: Optional pre-loaded list of LiveHost dicts.
                If None, loads from output/live_hosts.json.

    Returns
    -------
    List of TechnologyFingerprint objects, one per probed host.
    """
    started = datetime.now(timezone.utc)
    log.info("Phase 3 starting", extra={"domain": domain})

    # ------------------------------------------------------------------
    # 1. Load live hosts
    # ------------------------------------------------------------------
    hosts_data = live_hosts or await _load_live_hosts(config)
    if not hosts_data:
        log.warning(
            "No live hosts to fingerprint — did Phase 2 run?",
            extra={"domain": domain},
        )
        return []

    log.info("Fingerprinting live hosts", extra={"count": len(hosts_data), "domain": domain})

    # ------------------------------------------------------------------
    # 2. Build fetch list — (url, host, phase2_techs)
    # ------------------------------------------------------------------
    fetch_list: list[tuple[str, str, list[str]]] = []
    for h in hosts_data:
        url  = h.get("url", "")
        host = h.get("host", "")
        p2   = h.get("technologies", [])   # Phase 2 tech list
        if url and host:
            fetch_list.append((url, host, p2))

    # ------------------------------------------------------------------
    # 3. Fetch + Fingerprint concurrently
    # ------------------------------------------------------------------
    fp = TechFingerprinter()
    fingerprints: list[TechnologyFingerprint] = []

    async with Phase3Fetcher(config.phase3) as fetcher:
        probes = await fetcher.fetch_all(fetch_list)

    cfg_p3 = config.phase3
    for probe in probes:
        matches = fp.match(probe)
        # Filter by minimum confidence
        matches = [m for m in matches if m.confidence >= cfg_p3.min_confidence]

        # Group matches into a TechnologyFingerprint model
        fp_model = _build_fingerprint(probe.url, probe.host, matches)
        fingerprints.append(fp_model)

    # ------------------------------------------------------------------
    # 4. Persist to SQLite
    # ------------------------------------------------------------------
    async with Database(config.database.path) as db:
        for fp_model in fingerprints:
            await db.upsert_technology(fp_model)

    log.info(
        "Technologies persisted",
        extra={"hosts": len(fingerprints), "db": config.database.path},
    )

    # ------------------------------------------------------------------
    # 5. Write JSON output
    # ------------------------------------------------------------------
    out_path = Path(config.output.technologies_json)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    _write_json(fingerprints, out_path, domain)
    log.info("Wrote technologies.json", extra={"path": str(out_path)})

    # ------------------------------------------------------------------
    # 6. Print summary
    # ------------------------------------------------------------------
    elapsed = (datetime.now(timezone.utc) - started).total_seconds()
    _print_summary(fingerprints, domain, elapsed)

    return fingerprints


# ---------------------------------------------------------------------------
# Load live hosts from Phase 2 output
# ---------------------------------------------------------------------------

async def _load_live_hosts(config: FrameworkConfig) -> list[dict]:
    json_path = Path(config.output.live_hosts_json)
    if json_path.exists():
        log.debug("Loading live hosts from JSON", extra={"path": str(json_path)})
        with json_path.open() as fh:
            data = json.load(fh)
        if isinstance(data, dict) and "hosts" in data:
            return data["hosts"]
        if isinstance(data, list):
            return data

    log.info("Loading live hosts from DB")
    try:
        async with Database(config.database.path) as db:
            rows = await db.get_live_hosts()
            return [h.model_dump() for h in rows]
    except Exception as exc:
        log.error("Failed to load live hosts", extra={"error": str(exc)})
        return []


# ---------------------------------------------------------------------------
# Build TechnologyFingerprint from TechMatch list
# ---------------------------------------------------------------------------

def _build_fingerprint(
    url: str,
    host: str,
    matches: list[TechMatch],
) -> TechnologyFingerprint:
    all_tech_names = [m.name for m in matches]

    # Classify into semantic slots
    cms = next(
        (m.name for m in matches if m.category == TechCategory.CMS),
        None,
    )
    web_server = next(
        (m.name for m in matches if m.category == TechCategory.WEB_SERVER),
        None,
    )
    language = next(
        (m.name for m in matches if m.category == TechCategory.LANGUAGE),
        None,
    )
    frameworks = [
        m.name
        for m in matches
        if m.category in (TechCategory.FRAMEWORK, TechCategory.JS_FRAMEWORK)
    ]

    return TechnologyFingerprint(
        host=host,
        url=url,
        technologies=all_tech_names,
        cms=cms,
        web_server=web_server,
        language=language,
        frameworks=frameworks,
    )


# ---------------------------------------------------------------------------
# JSON output
# ---------------------------------------------------------------------------

def _write_json(
    fingerprints: list[TechnologyFingerprint],
    path: Path,
    domain: str,
) -> None:
    # Build a richer output dict that includes category grouping
    hosts_out = []
    for fp in fingerprints:
        hosts_out.append({
            "host":         fp.host,
            "url":          fp.url,
            "cms":          fp.cms,
            "web_server":   fp.web_server,
            "language":     fp.language,
            "frameworks":   fp.frameworks,
            "technologies": fp.technologies,
            "fingerprinted_at": fp.fingerprinted_at.isoformat(),
        })

    # Global technology frequency table
    freq: dict[str, int] = defaultdict(int)
    for fp in fingerprints:
        for t in fp.technologies:
            freq[t] += 1

    payload = {
        "meta": {
            "domain":         domain,
            "total_hosts":    len(fingerprints),
            "generated_at":   datetime.now(timezone.utc).isoformat(),
        },
        "technology_frequency": dict(
            sorted(freq.items(), key=lambda x: -x[1])
        ),
        "hosts": hosts_out,
    }

    with path.open("w") as fh:
        json.dump(payload, fh, indent=2, default=str)


# ---------------------------------------------------------------------------
# Rich terminal summary
# ---------------------------------------------------------------------------

def _print_summary(
    fingerprints: list[TechnologyFingerprint],
    domain: str,
    elapsed: float,
) -> None:
    console.rule(f"[bold cyan]Phase 3 — Technology Intelligence[/] · {domain}")

    # Global technology frequency
    freq: dict[str, int] = defaultdict(int)
    for fp in fingerprints:
        for t in fp.technologies:
            freq[t] += 1

    total_tech_hits = sum(freq.values())
    unique_techs    = len(freq)

    console.print(
        f"\n  [bold green]✔ Hosts fingerprinted  :[/] {len(fingerprints)}\n"
        f"  [bold cyan]◈  Unique technologies  :[/] {unique_techs}\n"
        f"  [bold cyan]◈  Total tech detections:[/] {total_tech_hits}\n"
        f"  [bold blue]⏱  Duration             :[/] {elapsed:.1f}s\n"
    )

    # --- Technology frequency table (top 20) ---
    top_techs = sorted(freq.items(), key=lambda x: -x[1])[:20]
    if top_techs:
        freq_table = Table(
            title="Technology Frequency (top 20)",
            box=box.SIMPLE_HEAD,
            show_edge=False,
        )
        freq_table.add_column("Technology", style="bright_white", min_width=22)
        freq_table.add_column("Hosts",      style="cyan", justify="right", width=8)
        freq_table.add_column("Bar",        style="green", min_width=20)

        max_count = top_techs[0][1] if top_techs else 1
        for tech_name, count in top_techs:
            bar_len = int((count / max_count) * 20)
            freq_table.add_row(tech_name, str(count), "█" * bar_len)
        console.print(freq_table)

    # --- Admin / CI-CD panel (high-value targets) ---
    high_value_cats = {
        TechCategory.ADMIN_PANEL, TechCategory.MONITORING,
        TechCategory.CI_CD,
    }
    hv_hosts: list[tuple[str, str]] = []   # (host, tech_name)
    for fp in fingerprints:
        from plugins.technology.signatures import COMPILED_SIGNATURES
        for tech_name in fp.technologies:
            sig = next((s for s in COMPILED_SIGNATURES if s.name == tech_name), None)
            if sig and sig.category in high_value_cats:
                hv_hosts.append((fp.host, tech_name))

    if hv_hosts:
        hv_table = Table(
            title="[bold red]⚑ High-Value Panels Detected[/]",
            box=box.SIMPLE_HEAD,
            show_edge=False,
        )
        hv_table.add_column("Host",       style="bright_white", max_width=50, no_wrap=True)
        hv_table.add_column("Technology", style="bold red",     width=20)
        for host, tech in sorted(hv_hosts)[:20]:
            hv_table.add_row(host, tech)
        console.print(hv_table)

    console.rule()
