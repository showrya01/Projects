"""
phases/phase10_scan.py
========================
Phase 10 — Safe Vulnerability Scanning Orchestrator

Workflow
--------
1. Load all live host URLs from Phase 2.
2. Run Nuclei safe templates (if binary available).
3. Run Python security header checker (always-on).
4. Merge + deduplicate findings across both sources.
5. Build Phase 11 score contributions per host.
6. Persist NucleiFinding records to SQLite.
7. Write output/nuclei_results.json.
8. Print Rich summary grouped by severity and category.

Integration
-----------
Reads  : output/live_hosts.json  (Phase 2)
Writes : output/nuclei_results.json
         output/recon.db  (nuclei_findings table)
"""

from __future__ import annotations

import asyncio
import json
import logging
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

from rich import box
from rich.console import Console
from rich.table import Table

from core.base_plugin import PluginContext
from core.config import FrameworkConfig
from core.database import Database
from core.models import NucleiFinding
from plugins.scanner.header_checker import HeaderChecker
from plugins.scanner.nuclei_scanner import NucleiScanner

log     = logging.getLogger(__name__)
console = Console(stderr=True)

_SEV_COLOUR = {
    "critical": "bold bright_red",
    "high":     "bright_red",
    "medium":   "bright_yellow",
    "low":      "bright_green",
    "info":     "dim white",
}
_SEV_RANK = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

async def run_phase10(
    domain: str,
    config: FrameworkConfig,
    *,
    live_hosts: list[dict] | None = None,
) -> list[NucleiFinding]:
    """
    Execute Phase 10.

    Parameters
    ----------
    domain:     Target domain string.
    config:     Loaded FrameworkConfig.
    live_hosts: Optional pre-loaded Phase 2 live host dicts.

    Returns
    -------
    Deduplicated list of NucleiFinding sorted by severity.
    Also stores per-host Phase 11 score contributions.
    """
    started = datetime.now(timezone.utc)
    log.info("Phase 10 starting", extra={"domain": domain})

    cfg = config.phase10

    # ------------------------------------------------------------------
    # 1. Load live hosts
    # ------------------------------------------------------------------
    hosts_data = live_hosts or _load_live_hosts(config)
    if not hosts_data:
        log.warning("No live hosts to scan — did Phase 2 run?")
        return []

    # Build URL list
    urls = [h.get("url", "") for h in hosts_data if h.get("url")]
    log.info("Scanning live hosts", extra={"count": len(urls)})

    # ------------------------------------------------------------------
    # 2. Run Nuclei + header checker in parallel
    # ------------------------------------------------------------------
    ctx = PluginContext(domain=domain, config=config)
    ctx.metadata["scan_urls"] = urls

    nuclei   = NucleiScanner()
    headers  = HeaderChecker(cfg)

    nuclei_task  = nuclei.execute(ctx)
    headers_task = headers.check_all(urls) if cfg.check_headers else _empty()

    nuclei_result, header_findings = await asyncio.gather(
        nuclei_task, headers_task,
        return_exceptions=False,
    )

    all_findings: list[NucleiFinding] = []
    all_findings.extend(nuclei_result.data or [])
    all_findings.extend(header_findings)

    log.info(
        "Scan complete",
        extra={
            "nuclei":  len(nuclei_result.data or []),
            "headers": len(header_findings),
            "total":   len(all_findings),
        },
    )

    # ------------------------------------------------------------------
    # 3. Deduplicate  (host + template_id)
    # ------------------------------------------------------------------
    seen: set[tuple[str, str]] = set()
    deduped: list[NucleiFinding] = []
    for f in all_findings:
        key = (f.host, f.template_id)
        if key not in seen:
            seen.add(key)
            deduped.append(f)

    # Sort: severity rank asc, then host asc
    deduped.sort(key=lambda f: (_SEV_RANK.get(f.severity, 99), f.host))

    # ------------------------------------------------------------------
    # 4. Phase 11 score contributions
    # ------------------------------------------------------------------
    _score_map = {
        "critical": cfg.score_critical,
        "high":     cfg.score_high,
        "medium":   cfg.score_medium,
        "low":      cfg.score_low,
        "info":     cfg.score_info,
    }
    phase11_scores: dict[str, int] = defaultdict(int)
    for f in deduped:
        phase11_scores[f.host] += _score_map.get(f.severity, 0)

    # ------------------------------------------------------------------
    # 5. Persist to DB
    # ------------------------------------------------------------------
    async with Database(config.database.path) as db:
        for finding in deduped:
            await db.upsert_nuclei_finding(finding)

    log.info(
        "Findings persisted",
        extra={"count": len(deduped), "db": config.database.path},
    )

    # ------------------------------------------------------------------
    # 6. Write JSON output
    # ------------------------------------------------------------------
    out_path = Path(config.output.nuclei_results_json)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    _write_json(deduped, dict(phase11_scores), domain, out_path)
    log.info("Wrote nuclei_results.json", extra={"path": str(out_path)})

    # ------------------------------------------------------------------
    # 7. Summary
    # ------------------------------------------------------------------
    elapsed = (datetime.now(timezone.utc) - started).total_seconds()
    _print_summary(deduped, domain, elapsed, dict(phase11_scores))

    return deduped


async def _empty() -> list:
    return []


# ---------------------------------------------------------------------------
# Loaders
# ---------------------------------------------------------------------------

def _load_live_hosts(config: FrameworkConfig) -> list[dict]:
    path = Path(config.output.live_hosts_json)
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text())
        if isinstance(data, dict):
            return data.get("hosts", [])
        return data if isinstance(data, list) else []
    except Exception as exc:
        log.warning("Failed to load live_hosts.json", extra={"error": str(exc)})
        return []


# ---------------------------------------------------------------------------
# DB method (appended inline to avoid circular import)
# ---------------------------------------------------------------------------
# The actual upsert_nuclei_finding method is defined in core/database.py.
# We add it here if not already present via the _patch approach.


# ---------------------------------------------------------------------------
# Writers
# ---------------------------------------------------------------------------

def _write_json(
    findings:       list[NucleiFinding],
    phase11_scores: dict[str, int],
    domain:         str,
    path:           Path,
) -> None:
    sev_dist: dict[str, int] = defaultdict(int)
    cat_dist: dict[str, int] = defaultdict(int)
    for f in findings:
        sev_dist[f.severity] += 1
        for tag in f.tags[:1]:          # primary tag = category
            cat_dist[tag] += 1

    payload = {
        "meta": {
            "domain":        domain,
            "total":         len(findings),
            "generated_at":  datetime.now(timezone.utc).isoformat(),
            "severity_distribution": dict(sev_dist),
            "category_distribution": dict(cat_dist),
        },
        "phase11_score_contributions": phase11_scores,
        "findings": [
            {
                "host":         f.host,
                "template_id":  f.template_id,
                "name":         f.name,
                "severity":     f.severity,
                "matched_at":   f.matched_at,
                "description":  f.description,
                "tags":         f.tags,
                "discovered_at": f.discovered_at.isoformat(),
            }
            for f in findings
        ],
    }

    with path.open("w") as fh:
        json.dump(payload, fh, indent=2, default=str)


# ---------------------------------------------------------------------------
# Rich summary
# ---------------------------------------------------------------------------

def _print_summary(
    findings:       list[NucleiFinding],
    domain:         str,
    elapsed:        float,
    phase11_scores: dict[str, int],
) -> None:
    console.rule(f"[bold cyan]Phase 10 — Safe Vulnerability Scanning[/] · {domain}")

    sev_dist: dict[str, int] = defaultdict(int)
    for f in findings:
        sev_dist[f.severity] += 1

    console.print(
        f"\n"
        f"  [bold red]◈  CRITICAL :[/] {sev_dist.get('critical', 0)}\n"
        f"  [red]◈  HIGH     :[/] {sev_dist.get('high', 0)}\n"
        f"  [yellow]◈  MEDIUM   :[/] {sev_dist.get('medium', 0)}\n"
        f"  [green]◈  LOW      :[/] {sev_dist.get('low', 0)}\n"
        f"  [dim]◈  INFO     :[/] {sev_dist.get('info', 0)}\n"
        f"  [bold blue]⏱  Duration  :[/] {elapsed:.1f}s\n"
    )

    # Top findings
    top = findings[:25]
    if top:
        tbl = Table(
            title=f"Top Findings ({len(top)} of {len(findings)})",
            box=box.SIMPLE_HEAD, show_edge=False,
        )
        tbl.add_column("Sev",         width=10)
        tbl.add_column("Host",        style="bright_white", max_width=40, no_wrap=True)
        tbl.add_column("Finding",     style="cyan",         max_width=45, no_wrap=True)
        tbl.add_column("Template",    style="dim",          max_width=30, no_wrap=True)

        for f in top:
            sev_str = f"[{_SEV_COLOUR.get(f.severity,'white')}]{f.severity.upper()}[/]"
            tbl.add_row(sev_str, f.host, f.name, f.template_id)
        console.print(tbl)

    # Phase 11 top contributors
    if phase11_scores:
        top_hosts = sorted(phase11_scores.items(), key=lambda x: -x[1])[:10]
        p11_tbl = Table(
            title="Phase 11 Score Contributions (top 10 hosts)",
            box=box.SIMPLE_HEAD, show_edge=False,
        )
        p11_tbl.add_column("Host",  style="bright_white", min_width=38)
        p11_tbl.add_column("Score", style="bright_red", justify="right", width=8)
        for host, score in top_hosts:
            p11_tbl.add_row(host, str(score))
        console.print(p11_tbl)

    console.rule()
