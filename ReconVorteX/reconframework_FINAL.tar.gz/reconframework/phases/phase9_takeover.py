"""
phases/phase9_takeover.py
============================
Phase 9 — Subdomain Takeover Detection Orchestrator

Workflow
--------
1. Load subdomains from Phase 1 (subdomains.json / DB).
2. Run all three detection methods in parallel:
     a) HTTPTakeoverChecker  — pure Python, always runs
     b) SubzyRunner          — if binary available
     c) NucleiTakeoverRunner — if binary available
3. Merge results: same host across methods → keep highest-confidence.
4. Persist to SQLite.
5. Write output/takeovers.json.
6. Print Rich ranked table.

Integration
-----------
Reads  : output/subdomains.json  (Phase 1)
Writes : output/takeovers.json
         output/recon.db  (takeovers table implied by existing schema)
"""

from __future__ import annotations

import asyncio
import json
import logging
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

from rich import box
from rich.console import Console
from rich.table import Table

from core.base_plugin import PluginContext
from core.config import FrameworkConfig
from core.models import TakeoverFinding
from plugins.takeover.http_checker import HTTPTakeoverChecker, TakeoverCandidate
from plugins.takeover.nuclei_runner import NucleiTakeoverRunner
from plugins.takeover.subzy_runner import SubzyRunner

log     = logging.getLogger(__name__)
console = Console(stderr=True)

_CONF_COLOUR = {
    "high":   "bold bright_red",
    "medium": "bright_yellow",
    "low":    "dim white",
}


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

async def run_phase9(
    domain: str,
    config: FrameworkConfig,
    *,
    subdomains: list[str] | None = None,
) -> list[TakeoverFinding]:
    """
    Execute Phase 9.

    Parameters
    ----------
    domain:     Target domain string.
    config:     Loaded FrameworkConfig.
    subdomains: Optional pre-loaded hostname list (from Phase 1 in-memory).

    Returns
    -------
    List of TakeoverFinding objects sorted by confidence descending.
    """
    started = datetime.now(timezone.utc)
    log.info("Phase 9 starting", extra={"domain": domain})

    cfg = config.phase9

    # ------------------------------------------------------------------
    # 1. Load subdomains
    # ------------------------------------------------------------------
    hosts = subdomains or _load_subdomains(config)
    if not hosts:
        log.warning("No subdomains to check — did Phase 1 run?", extra={"domain": domain})
        return []

    log.info("Checking subdomains for takeover", extra={"count": len(hosts)})

    # ------------------------------------------------------------------
    # 2. Run all three detection methods
    # ------------------------------------------------------------------
    ctx = PluginContext(domain=domain, config=config)
    ctx.metadata["takeover_hosts"] = hosts

    # a) HTTP fingerprint checker (always runs)
    http_checker = HTTPTakeoverChecker(cfg)

    # b) Subzy + Nuclei via plugin wrappers
    subzy   = SubzyRunner()
    nuclei  = NucleiTakeoverRunner()

    http_task   = http_checker.check_all(hosts)
    subzy_task  = subzy.execute(ctx)
    nuclei_task = nuclei.execute(ctx)

    http_results, subzy_result, nuclei_result = await asyncio.gather(
        http_task, subzy_task, nuclei_task,
        return_exceptions=False,
    )

    all_candidates: list[TakeoverCandidate] = []
    all_candidates.extend(http_results)
    all_candidates.extend(subzy_result.data  or [])
    all_candidates.extend(nuclei_result.data or [])

    log.info(
        "All checkers complete",
        extra={
            "http":   len(http_results),
            "subzy":  len(subzy_result.data or []),
            "nuclei": len(nuclei_result.data or []),
        },
    )

    # ------------------------------------------------------------------
    # 3. Merge + deduplicate (keep highest confidence per host)
    # ------------------------------------------------------------------
    best: dict[str, TakeoverCandidate] = {}
    for c in all_candidates:
        key = c.host.lower()
        if key not in best or c.confidence > best[key].confidence:
            best[key] = c

    merged = sorted(best.values(), key=lambda c: -c.confidence)

    # Convert to canonical TakeoverFinding model
    findings = [
        TakeoverFinding(
            host=c.host,
            cname=c.cname_hint,
            service=c.service,
            confidence=c.confidence,
            fingerprint="; ".join(c.evidence[:2]),
        )
        for c in merged
    ]

    log.info(
        "Phase 9 complete",
        extra={
            "total_checked":  len(hosts),
            "candidates":     len(merged),
            "high_conf":      sum(1 for c in merged if c.confidence >= 0.85),
        },
    )

    # ------------------------------------------------------------------
    # 4. Write JSON output
    # ------------------------------------------------------------------
    out_path = Path(config.output.takeovers_json)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    _write_json(merged, findings, domain, out_path)
    log.info("Wrote takeovers.json", extra={"path": str(out_path)})

    # ------------------------------------------------------------------
    # 5. Summary
    # ------------------------------------------------------------------
    elapsed = (datetime.now(timezone.utc) - started).total_seconds()
    _print_summary(merged, domain, elapsed)

    return findings


# ---------------------------------------------------------------------------
# Loaders
# ---------------------------------------------------------------------------

def _load_subdomains(config: FrameworkConfig) -> list[str]:
    json_path = Path(config.output.subdomains_json)
    txt_path  = Path(config.output.subdomains_txt)

    if json_path.exists():
        try:
            data = json.loads(json_path.read_text())
            if isinstance(data, dict) and "subdomains" in data:
                return [s["host"] for s in data["subdomains"]]
            if isinstance(data, list):
                return [s if isinstance(s, str) else s.get("host", "") for s in data]
        except Exception as exc:
            log.warning("Failed to load subdomains.json", extra={"error": str(exc)})

    if txt_path.exists():
        return [l.strip() for l in txt_path.read_text().splitlines() if l.strip()]

    return []


# ---------------------------------------------------------------------------
# Writers
# ---------------------------------------------------------------------------

def _write_json(
    candidates: list[TakeoverCandidate],
    findings:   list[TakeoverFinding],
    domain:     str,
    path:       Path,
) -> None:
    conf_dist: dict[str, int] = {"high": 0, "medium": 0, "low": 0}
    for c in candidates:
        if c.confidence >= 0.85:
            conf_dist["high"] += 1
        elif c.confidence >= 0.65:
            conf_dist["medium"] += 1
        else:
            conf_dist["low"] += 1

    service_dist: dict[str, int] = defaultdict(int)
    for c in candidates:
        service_dist[c.service] += 1

    payload = {
        "meta": {
            "domain":        domain,
            "total_checked": 0,
            "total_found":   len(candidates),
            "confidence_distribution": conf_dist,
            "service_distribution":    dict(service_dist),
            "generated_at":  datetime.now(timezone.utc).isoformat(),
        },
        "takeovers": [
            {
                "host":        c.host,
                "url":         c.url,
                "service":     c.service,
                "confidence":  c.confidence,
                "method":      c.method,
                "cname_hint":  c.cname_hint,
                "status_code": c.status_code,
                "evidence":    c.evidence,
                "fingerprint": c.fingerprint,
            }
            for c in candidates
        ],
    }

    with path.open("w") as fh:
        json.dump(payload, fh, indent=2, default=str)


# ---------------------------------------------------------------------------
# Rich summary
# ---------------------------------------------------------------------------

def _print_summary(
    candidates: list[TakeoverCandidate],
    domain:     str,
    elapsed:    float,
) -> None:
    console.rule(f"[bold cyan]Phase 9 — Subdomain Takeover Detection[/] · {domain}")

    high   = [c for c in candidates if c.confidence >= 0.85]
    medium = [c for c in candidates if 0.65 <= c.confidence < 0.85]
    low    = [c for c in candidates if c.confidence < 0.65]

    console.print(
        f"\n"
        f"  [bold red]⚑  High confidence  :[/] {len(high)}\n"
        f"  [yellow]◈  Medium confidence:[/] {len(medium)}\n"
        f"  [dim]◈  Low confidence   :[/] {len(low)}\n"
        f"  [bold blue]⏱  Duration         :[/] {elapsed:.1f}s\n"
    )

    if not candidates:
        console.print("[dim]  No takeover candidates found.[/dim]\n")
        console.rule()
        return

    tbl = Table(
        title=f"Takeover Candidates ({len(candidates)} total)",
        box=box.SIMPLE_HEAD, show_edge=False,
    )
    tbl.add_column("Host",        style="bright_white", max_width=45, no_wrap=True)
    tbl.add_column("Service",     style="cyan",         width=20)
    tbl.add_column("Confidence",  justify="right",      width=12)
    tbl.add_column("Method",      style="dim",          width=12)
    tbl.add_column("Evidence",    style="dim white",    max_width=35, no_wrap=True)

    for c in candidates[:20]:
        if c.confidence >= 0.85:
            conf_str = f"[bold bright_red]{c.confidence:.2f}[/]"
        elif c.confidence >= 0.65:
            conf_str = f"[bright_yellow]{c.confidence:.2f}[/]"
        else:
            conf_str = f"[dim]{c.confidence:.2f}[/]"

        evidence_str = c.evidence[0][:35] if c.evidence else ""
        tbl.add_row(c.host, c.service, conf_str, c.method, evidence_str)

    console.print(tbl)
    console.rule()
