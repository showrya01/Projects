"""
phases/phase1_discovery.py
===========================
Phase 1 Orchestrator — Multi-Source Asset Discovery.

Responsibilities:
  1. Instantiate all enabled subdomain plugins.
  2. Run them concurrently (bounded by semaphore).
  3. Merge + deduplicate results (union of sources per host).
  4. Persist to SQLite.
  5. Write output/subdomains.txt and output/subdomains.json.
  6. Print a rich summary table to the terminal.
  7. Return a DiscoveryResult for downstream phases.
"""

from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Type

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box

from core.base_plugin import BasePlugin, PluginContext, PluginResult
from core.config import FrameworkConfig
from core.database import Database
from core.http_client import close_session
from core.models import DiscoveryResult, Subdomain
from plugins.subdomains import ALL_PLUGINS

log = logging.getLogger(__name__)
console = Console()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _merge_subdomains(
    results: list[PluginResult[list[Subdomain]]],
) -> dict[str, Subdomain]:
    """
    Merge all plugin results into a single deduped dict.

    Key   = normalised hostname
    Value = Subdomain with union of all sources
    """
    merged: dict[str, Subdomain] = {}
    for res in results:
        if not res.success or not res.data:
            continue
        for sub in res.data:
            if sub.host in merged:
                for src in sub.sources:
                    merged[sub.host].add_source(src)
            else:
                merged[sub.host] = sub
    return merged


def _source_breakdown(
    results: list[PluginResult[list[Subdomain]]],
) -> dict[str, int]:
    """Count unique hosts discovered per source."""
    breakdown: dict[str, int] = {}
    for res in results:
        if not res.success or not res.data:
            breakdown[res.plugin_name] = 0
            continue
        # Count only hosts unique to this result (pre-merge)
        breakdown[res.plugin_name] = len(set(s.host for s in res.data))
    return breakdown


# ---------------------------------------------------------------------------
# Rich summary
# ---------------------------------------------------------------------------

def _print_summary(result: DiscoveryResult) -> None:
    console.print()
    console.rule("[bold cyan]Phase 1 — Asset Discovery Complete[/bold cyan]")

    # Stats panel
    stats = (
        f"[bold]Domain:[/bold]            {result.domain}\n"
        f"[bold]Total discovered:[/bold]  {result.total_discovered}\n"
        f"[bold]Unique subdomains:[/bold] {result.unique_discovered}\n"
        f"[bold]Duration:[/bold]          {result.duration_seconds:.1f}s\n"
        f"[bold]Errors:[/bold]            {len(result.errors)}"
    )
    console.print(Panel(stats, title="[bold green]Summary[/bold green]", border_style="green"))

    # Source breakdown table
    table = Table(
        title="Source Breakdown",
        box=box.ROUNDED,
        border_style="cyan",
        show_lines=False,
    )
    table.add_column("Source", style="bright_cyan", no_wrap=True)
    table.add_column("Hosts Found", justify="right", style="bright_white")

    for src, count in sorted(result.source_breakdown.items(), key=lambda x: -x[1]):
        table.add_row(src, str(count))

    console.print(table)

    if result.errors:
        console.print(
            f"\n[yellow]⚠  {len(result.errors)} plugin(s) failed — see recon.log for details[/yellow]"
        )
    console.print()


# ---------------------------------------------------------------------------
# Phase 1 entry-point
# ---------------------------------------------------------------------------

class Phase1Discovery:
    """
    Multi-source subdomain discovery orchestrator.

    Usage:
        phase = Phase1Discovery(config)
        result = await phase.run("example.com")
    """

    def __init__(self, config: FrameworkConfig) -> None:
        self._config = config
        self._db = Database(config.database.path)

    async def run(self, domain: str) -> DiscoveryResult:
        """
        Execute all subdomain discovery plugins in parallel.

        Returns a fully-populated DiscoveryResult.
        """
        result = DiscoveryResult(domain=domain)
        ctx = PluginContext(domain=domain, config=self._config, errors=result.errors)

        # Filter to enabled plugins, sorted by priority
        plugins: list[BasePlugin] = sorted(
            [cls() for cls in ALL_PLUGINS if cls.ENABLED],
            key=lambda p: p.PRIORITY,
        )

        log.info(
            "Phase 1 started",
            extra={
                "domain": domain,
                "plugins": [p.NAME for p in plugins],
                "count": len(plugins),
            },
        )
        console.rule(
            f"[bold cyan]Phase 1 — Multi-Source Asset Discovery[/bold cyan]  "
            f"[dim]target: {domain}[/dim]"
        )
        console.print(
            f"  [dim]Running [bold]{len(plugins)}[/bold] discovery plugins …[/dim]\n"
        )

        # Semaphore limits simultaneous tool executions
        sem = asyncio.Semaphore(self._config.phase1.max_concurrent_tools)

        async def _bounded(plugin: BasePlugin) -> PluginResult:
            async with sem:
                return await plugin.execute(ctx)

        # Fire all plugins concurrently
        plugin_results: list[PluginResult[list[Subdomain]]] = await asyncio.gather(
            *[_bounded(p) for p in plugins], return_exceptions=False
        )

        # --- Merge ---
        merged = _merge_subdomains(plugin_results)
        result.subdomains = list(merged.values())
        result.total_discovered = sum(
            len(r.data) for r in plugin_results if r.success and r.data
        )
        result.source_breakdown = _source_breakdown(plugin_results)
        result.finalise()

        log.info(
            "Phase 1 merge complete",
            extra={
                "domain": domain,
                "unique": result.unique_discovered,
                "total": result.total_discovered,
            },
        )

        # --- Persist to DB ---
        async with self._db as db:
            await db.bulk_upsert_subdomains(result.subdomains, domain)

        # --- Write output files ---
        await self._write_outputs(result)

        # --- Summary ---
        _print_summary(result)

        # --- Cleanup HTTP session ---
        await close_session()

        return result

    # ------------------------------------------------------------------
    # Output writers
    # ------------------------------------------------------------------

    async def _write_outputs(self, result: DiscoveryResult) -> None:
        """Write subdomains.txt and subdomains.json."""
        base = Path(self._config.output.base_dir)
        base.mkdir(parents=True, exist_ok=True)

        # Plain text — one hostname per line, alphabetically sorted
        txt_path = Path(self._config.output.subdomains_txt)
        hosts_sorted = sorted(s.host for s in result.subdomains)
        txt_path.write_text("\n".join(hosts_sorted) + "\n", encoding="utf-8")
        log.info("Wrote subdomains.txt", extra={"path": str(txt_path), "count": len(hosts_sorted)})

        # JSON — full DiscoveryResult with metadata
        json_path = Path(self._config.output.subdomains_json)
        payload = {
            "domain": result.domain,
            "unique_discovered": result.unique_discovered,
            "total_discovered": result.total_discovered,
            "source_breakdown": result.source_breakdown,
            "duration_seconds": result.duration_seconds,
            "started_at": result.started_at.isoformat() if result.started_at else None,
            "finished_at": result.finished_at.isoformat() if result.finished_at else None,
            "errors": result.errors,
            "subdomains": [
                {
                    "host": s.host,
                    "sources": s.sources,
                    "discovered_at": s.discovered_at.isoformat(),
                    "is_wildcard": s.is_wildcard,
                }
                for s in sorted(result.subdomains, key=lambda s: s.host)
            ],
        }
        json_path.write_text(
            json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        log.info("Wrote subdomains.json", extra={"path": str(json_path)})
