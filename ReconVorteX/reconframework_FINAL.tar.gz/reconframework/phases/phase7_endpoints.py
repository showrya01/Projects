"""
phases/phase7_endpoints.py
============================
Phase 7 — Sensitive Endpoint Discovery Orchestrator

Workflow
--------
1. Load URL list from Phase 6 (urls.json or urls.txt).
2. Run match_urls() — pure pattern matching, zero network requests.
3. Apply min_severity filter from config.
4. Build Phase 11 score contributions per host (grouped).
5. Write output/sensitive_endpoints.txt  (one URL per line).
6. Write output/sensitive_endpoints.json (full structured findings).
7. Print Rich summary grouped by severity.

Integration
-----------
Reads  : output/urls.json  (Phase 6)
         output/urls.txt   (Phase 6 fallback)
Writes : output/sensitive_endpoints.txt
         output/sensitive_endpoints.json
"""

from __future__ import annotations

import json
import logging
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

from rich import box
from rich.console import Console
from rich.table import Table

from core.config import FrameworkConfig
from plugins.endpoints.matcher import EndpointFinding, match_urls, severity_passes
from plugins.endpoints.patterns import Severity

log     = logging.getLogger(__name__)
console = Console(stderr=True)

_SEVERITY_COLOUR = {
    Severity.CRITICAL: "bold bright_red",
    Severity.HIGH:     "bright_red",
    Severity.MEDIUM:   "bright_yellow",
    Severity.LOW:      "bright_green",
    Severity.INFO:     "dim white",
}


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

async def run_phase7(
    domain: str,
    config: FrameworkConfig,
    *,
    urls: list[str] | None = None,
) -> list[EndpointFinding]:
    """
    Execute Phase 7.

    Parameters
    ----------
    domain : Target domain string.
    config : Loaded FrameworkConfig.
    urls   : Optional pre-loaded URL list (from Phase 6 in-memory feed).
             If None, loads from output/urls.json or output/urls.txt.

    Returns
    -------
    List of EndpointFinding objects sorted CRITICAL → INFO.
    Also returns per-host Phase 11 score map in config metadata.
    """
    started = datetime.now(timezone.utc)
    log.info("Phase 7 starting", extra={"domain": domain})

    cfg = config.phase7

    # ------------------------------------------------------------------
    # 1. Load URLs
    # ------------------------------------------------------------------
    url_list = urls or _load_urls(config)
    if not url_list:
        log.warning("No URLs to analyse — did Phase 6 run?", extra={"domain": domain})
        return []

    log.info("Analysing URLs", extra={"count": len(url_list), "domain": domain})

    # ------------------------------------------------------------------
    # 2. Pattern match (pure, no I/O)
    # ------------------------------------------------------------------
    min_sev = Severity(cfg.min_severity.upper())
    findings = match_urls(url_list, min_severity=min_sev)

    if cfg.max_findings and len(findings) > cfg.max_findings:
        findings = findings[: cfg.max_findings]

    log.info(
        "Pattern matching complete",
        extra={"findings": len(findings), "urls_analysed": len(url_list)},
    )

    # ------------------------------------------------------------------
    # 3. Build Phase 11 score map  { host → total_score }
    # ------------------------------------------------------------------
    phase11_scores: dict[str, int] = defaultdict(int)
    if cfg.feed_phase11:
        score_map = {
            Severity.CRITICAL: cfg.score_critical,
            Severity.HIGH:     cfg.score_high,
            Severity.MEDIUM:   cfg.score_medium,
            Severity.LOW:      cfg.score_low,
            Severity.INFO:     0,
        }
        for f in findings:
            if f.host:
                phase11_scores[f.host] += score_map.get(f.severity, 0)

    # ------------------------------------------------------------------
    # 4. Write outputs
    # ------------------------------------------------------------------
    out_dir = Path(config.output.base_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    txt_path  = Path(config.output.sensitive_endpoints_txt)
    json_path = txt_path.with_suffix(".json")

    _write_txt(findings, txt_path)
    _write_json(findings, dict(phase11_scores), domain, json_path)

    log.info(
        "Phase 7 outputs written",
        extra={"txt": str(txt_path), "json": str(json_path)},
    )

    # ------------------------------------------------------------------
    # 5. Summary
    # ------------------------------------------------------------------
    elapsed = (datetime.now(timezone.utc) - started).total_seconds()
    _print_summary(findings, domain, elapsed, dict(phase11_scores))

    return findings


# ---------------------------------------------------------------------------
# Loaders
# ---------------------------------------------------------------------------

def _load_urls(config: FrameworkConfig) -> list[str]:
    """Load URL list from Phase 6 JSON or TXT output."""
    json_path = Path(config.output.urls_txt.replace(".txt", ".json"))
    txt_path  = Path(config.output.urls_txt)

    if json_path.exists():
        try:
            with json_path.open() as fh:
                data = json.load(fh)
            if isinstance(data, dict) and "urls" in data:
                return data["urls"]
            if isinstance(data, list):
                return data
        except Exception as exc:
            log.warning("Failed to load urls.json", extra={"error": str(exc)})

    if txt_path.exists():
        return [l.strip() for l in txt_path.read_text().splitlines() if l.strip()]

    return []


# ---------------------------------------------------------------------------
# Writers
# ---------------------------------------------------------------------------

def _write_txt(findings: list[EndpointFinding], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [f.url for f in findings]
    # Deduplicate while preserving order
    seen: set[str] = set()
    unique: list[str] = []
    for l in lines:
        if l not in seen:
            seen.add(l)
            unique.append(l)
    path.write_text("\n".join(unique) + ("\n" if unique else ""))
    log.info("Wrote sensitive_endpoints.txt", extra={"path": str(path), "count": len(unique)})


def _write_json(
    findings:      list[EndpointFinding],
    phase11_scores: dict[str, int],
    domain:        str,
    path:          Path,
) -> None:
    # Distribution by severity
    dist: dict[str, int] = defaultdict(int)
    for f in findings:
        dist[f.severity.value] += 1

    # Category breakdown
    cat_dist: dict[str, int] = defaultdict(int)
    for f in findings:
        cat_dist[f.category.value] += 1

    payload = {
        "meta": {
            "domain":       domain,
            "total":        len(findings),
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "severity_distribution": dict(dist),
            "category_distribution": dict(cat_dist),
        },
        "phase11_score_contributions": phase11_scores,
        "findings": [f.to_dict() for f in findings],
    }

    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as fh:
        json.dump(payload, fh, indent=2)
    log.info("Wrote sensitive_endpoints.json", extra={"path": str(path)})


# ---------------------------------------------------------------------------
# Rich summary
# ---------------------------------------------------------------------------

def _print_summary(
    findings:      list[EndpointFinding],
    domain:        str,
    elapsed:       float,
    phase11_scores: dict[str, int],
) -> None:
    console.rule(f"[bold cyan]Phase 7 — Sensitive Endpoint Discovery[/] · {domain}")

    dist: dict[str, int] = defaultdict(int)
    for f in findings:
        dist[f.severity.value] += 1

    console.print(
        f"\n"
        f"  [bold red]◈  CRITICAL :[/] {dist.get('CRITICAL', 0)}\n"
        f"  [red]◈  HIGH     :[/] {dist.get('HIGH', 0)}\n"
        f"  [yellow]◈  MEDIUM   :[/] {dist.get('MEDIUM', 0)}\n"
        f"  [green]◈  LOW      :[/] {dist.get('LOW', 0)}\n"
        f"  [dim]◈  INFO     :[/] {dist.get('INFO', 0)}\n"
        f"  [bold blue]⏱  Duration  :[/] {elapsed:.2f}s\n"
    )

    # Top 25 findings
    top = findings[:25]
    if top:
        tbl = Table(
            title=f"Top Sensitive Endpoints ({len(top)} of {len(findings)})",
            box=box.SIMPLE_HEAD,
            show_edge=False,
        )
        tbl.add_column("Sev",         width=10)
        tbl.add_column("URL",         style="bright_white", max_width=50, no_wrap=True)
        tbl.add_column("Pattern",     style="cyan",  width=20, no_wrap=True)
        tbl.add_column("Category",    style="dim",   width=18, no_wrap=True)
        tbl.add_column("P11 Score",   justify="right", width=10)

        for f in top:
            sev_str = f"[{_SEVERITY_COLOUR[f.severity]}]{f.severity.value}[/]"
            tbl.add_row(
                sev_str,
                f.url,
                f.pattern_name,
                f.category.value,
                str(f.phase11_score),
            )
        console.print(tbl)

    # Phase 11 top contributors
    if phase11_scores:
        top_hosts = sorted(phase11_scores.items(), key=lambda x: -x[1])[:10]
        h_tbl = Table(
            title="Phase 11 Score Contributions (top 10 hosts)",
            box=box.SIMPLE_HEAD,
            show_edge=False,
        )
        h_tbl.add_column("Host",  style="bright_white", min_width=35)
        h_tbl.add_column("Score", style="bright_red",   justify="right", width=8)
        for host, score in top_hosts:
            h_tbl.add_row(host, str(score))
        console.print(h_tbl)

    console.rule()
