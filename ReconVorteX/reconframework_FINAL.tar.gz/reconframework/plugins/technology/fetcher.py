"""
plugins/technology/fetcher.py
================================
Lightweight async HTTP fetcher used by Phase 3 to re-probe live hosts
and collect response headers + HTML body for fingerprinting.

Why re-fetch instead of reusing Phase 2 data?
---------------------------------------------
Phase 2 stores only the *metadata* of each live host (status, title, IP…).
Fingerprinting needs the raw response headers and the HTML body, which
Phase 2 discards after title extraction.

This fetcher is deliberately minimal:
  • No redirect following beyond what's needed (just final URL).
  • Reads up to cfg.max_body_bytes (default 128 KB) — enough for all meta tags.
  • Returns a RawProbeResult ready for TechFingerprinter.match().
  • Concurrent via asyncio.Semaphore — same pattern as Phase 2.
"""

from __future__ import annotations

import asyncio
import logging
import re
import time
from http.cookies import SimpleCookie

import aiohttp
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from core.config import Phase3Config
from plugins.technology.fingerprinter import RawProbeResult

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Cookie header parser
# ---------------------------------------------------------------------------

def _parse_cookies(set_cookie_header: str) -> dict[str, str]:
    """Parse a Set-Cookie header string into a name→value dict."""
    cookies: dict[str, str] = {}
    # aiohttp joins multiple Set-Cookie headers with '; '
    for part in set_cookie_header.split(", "):
        try:
            sc = SimpleCookie(part)
            for k, v in sc.items():
                cookies[k] = v.value
        except Exception:  # noqa: BLE001
            pass
    return cookies


# ---------------------------------------------------------------------------
# Phase 3 fetcher
# ---------------------------------------------------------------------------

class Phase3Fetcher:
    """
    Async HTTP fetcher that produces RawProbeResult objects.

    Use as an async context manager to share the aiohttp session:

        async with Phase3Fetcher(cfg) as fetcher:
            results = await fetcher.fetch_all(live_hosts)
    """

    def __init__(self, cfg: Phase3Config) -> None:
        self._cfg = cfg
        self._session: aiohttp.ClientSession | None = None
        self._sem: asyncio.Semaphore | None = None

    async def __aenter__(self) -> "Phase3Fetcher":
        connector = aiohttp.TCPConnector(
            ssl=False,
            limit=self._cfg.concurrency + 20,
            ttl_dns_cache=300,
        )
        timeout = aiohttp.ClientTimeout(total=self._cfg.timeout_s)
        self._session = aiohttp.ClientSession(
            connector=connector,
            timeout=timeout,
            headers={"User-Agent": self._cfg.user_agent},
        )
        self._sem = asyncio.Semaphore(self._cfg.concurrency)
        return self

    async def __aexit__(self, *_) -> None:
        if self._session:
            await self._session.close()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def fetch_all(
        self,
        hosts: list[tuple[str, str, list[str]]],
        # Each entry: (url, host, phase2_techs)
    ) -> list[RawProbeResult]:
        """
        Fetch all hosts concurrently under the semaphore.

        Returns one RawProbeResult per host (even on error — body will be empty).
        """
        tasks = [self._fetch_one(url, host, p2techs) for url, host, p2techs in hosts]
        return await asyncio.gather(*tasks)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    async def _fetch_one(
        self,
        url: str,
        host: str,
        phase2_techs: list[str],
    ) -> RawProbeResult:
        assert self._sem is not None
        assert self._session is not None

        async with self._sem:
            try:
                return await self._do_fetch(url, host, phase2_techs)
            except Exception as exc:  # noqa: BLE001
                log.debug(
                    "Phase3 fetch failed",
                    extra={"url": url, "error": str(exc)},
                )
                # Return an empty probe so fingerprinting still runs
                # (Phase 2 tech list will still be merged)
                return RawProbeResult(
                    url=url,
                    host=host,
                    phase2_techs=phase2_techs,
                )

    @retry(
        stop=stop_after_attempt(2),
        wait=wait_exponential(min=0.5, max=2.0),
        retry=retry_if_exception_type((aiohttp.ClientConnectorError, asyncio.TimeoutError)),
        reraise=False,
    )
    async def _do_fetch(
        self,
        url: str,
        host: str,
        phase2_techs: list[str],
    ) -> RawProbeResult:
        """Perform the actual HTTP GET and build a RawProbeResult."""
        async with self._session.get(  # type: ignore[union-attr]
            url,
            allow_redirects=True,
            max_redirects=3,
            ssl=False,
        ) as resp:
            # Read headers
            headers: dict[str, str] = dict(resp.headers)

            # Parse cookies from Set-Cookie header
            cookies = _parse_cookies(headers.get("Set-Cookie", ""))

            # Read body (limited)
            body = await resp.content.read(self._cfg.max_body_bytes)

        return RawProbeResult(
            url=str(resp.url),
            host=host,
            response_headers=headers,
            body_bytes=body,
            cookies=cookies,
            phase2_techs=phase2_techs,
        )
