"""
plugins/technology/fingerprinter.py
=====================================
Core technology fingerprinting engine for ReconFramework Phase 3.

Input
-----
A RawProbeResult carrying:
  • url, host
  • response_headers (dict[str, str])
  • body_bytes (bytes)
  • cookies (dict[str, str])
  • phase2_techs (list[str])  — from httpx -tech-detect in Phase 2

Output
------
A TechMatch per detected technology with:
  • name, category, confidence, matched_rules, version (if parseable)

The fingerprinter is stateless and thread-safe — instantiate once and
call match() concurrently from any number of async tasks.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import NamedTuple

from plugins.technology.signatures import COMPILED_SIGNATURES, Signature, TechCategory


# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------

@dataclass
class RawProbeResult:
    """Everything the fingerprinter needs about one HTTP response."""

    url: str
    host: str
    response_headers: dict[str, str] = field(default_factory=dict)
    body_bytes: bytes = b""
    cookies: dict[str, str] = field(default_factory=dict)
    phase2_techs: list[str] = field(default_factory=list)

    # Lazily decoded HTML body (populated by fingerprinter)
    _body_text: str | None = field(default=None, repr=False)

    def body_text(self) -> str:
        if self._body_text is None:
            self._body_text = self.body_bytes.decode(errors="replace")
        return self._body_text


@dataclass
class TechMatch:
    """A single technology detection result."""

    name: str
    category: TechCategory
    confidence: float            # 0.0 – 1.0 (boosted if multiple rules fire)
    matched_rules: list[str]     # human-readable description of each rule that fired
    version: str | None = None   # extracted version string if available
    implied_by: str | None = None  # set if this tech was inferred from another


# ---------------------------------------------------------------------------
# Version extraction helpers
# ---------------------------------------------------------------------------

_VERSION_PATTERNS: dict[str, list[str]] = {
    "WordPress":   [r'content="WordPress ([\d.]+)"', r"WordPress/([\d.]+)"],
    "Drupal":      [r"Drupal ([\d.]+)", r"/core/([\d.]+)"],
    "Joomla":      [r"Joomla! ([\d.]+)", r'"version":"([\d.]+)"'],
    "PHP":         [r"PHP/([\d.]+)"],
    "Apache":      [r"Apache/([\d.]+)"],
    "Nginx":       [r"nginx/([\d.]+)"],
    "IIS":         [r"Microsoft-IIS/([\d.]+)"],
    "jQuery":      [r"jquery[/-]([\d.]+)", r"jQuery v([\d.]+)"],
    "Bootstrap":   [r"bootstrap/([\d.]+)", r"Bootstrap v([\d.]+)"],
    "React":       [r"react@([\d.]+)", r'"version":\s*"([\d.]+)".*react'],
    "Angular":     [r"angular/([\d.]+)", r'ng-version=["\']([^"\']+)["\']'],
    "Vue.js":      [r"vue@([\d.]+)", r"Vue\.version\s*=\s*['\"]([^'\"]+)['\"]"],
    "Jenkins":     [r'<li>Jenkins\s*([\d.]+)', r"Jenkins/([\d.]+)"],
    "Grafana":     [r'"version":\s*"([\d.]+)"', r"Grafana\s*v([\d.]+)"],
}

_FLAGS = re.IGNORECASE | re.DOTALL


def _extract_version(name: str, text: str) -> str | None:
    """Try to extract a version string for the named technology."""
    patterns = _VERSION_PATTERNS.get(name, [])
    for pat in patterns:
        m = re.search(pat, text, _FLAGS)
        if m:
            return m.group(1)
    return None


# ---------------------------------------------------------------------------
# Fingerprinter
# ---------------------------------------------------------------------------

class TechFingerprinter:
    """
    Stateless fingerprinting engine.

    Usage:
        fp = TechFingerprinter()
        matches = fp.match(probe_result)
    """

    def __init__(self, signatures: list[Signature] | None = None) -> None:
        self._sigs = signatures if signatures is not None else COMPILED_SIGNATURES

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def match(self, probe: RawProbeResult) -> list[TechMatch]:
        """
        Run all signatures against the probe result.

        Returns a deduplicated, confidence-sorted list of TechMatch objects.
        Phase 2 technologies are merged in at a baseline confidence of 0.6
        if no stronger evidence was found.
        """
        matches: dict[str, TechMatch] = {}

        headers_lower = {k.lower(): v for k, v in probe.response_headers.items()}
        cookies_lower = {k.lower(): v for k, v in probe.cookies.items()}
        body = probe.body_text()
        url  = probe.url.lower()

        # --- Run each signature ---
        for sig in sorted(self._sigs, key=lambda s: s.priority):
            fired_rules: list[str] = []
            rule_confidences: list[float] = []

            # 1. Header patterns
            for header_name, compiled_pats in sig._compiled_headers.items():
                header_val = headers_lower.get(header_name, "")
                # Some headers (Set-Cookie) may appear multiple times
                # aiohttp returns them as a single combined string
                if not header_val:
                    continue
                for pat in compiled_pats:
                    if pat.search(header_val):
                        fired_rules.append(f"header:{header_name}")
                        rule_confidences.append(sig.confidence_base)
                        break

            # 2. Cookie patterns
            for cookie_name in sig.cookie_patterns:
                cookie_lower = cookie_name.lower()
                if any(cookie_lower in k for k in cookies_lower):
                    fired_rules.append(f"cookie:{cookie_name}")
                    rule_confidences.append(sig.confidence_base * 0.85)
                    break
                # Also check Set-Cookie header directly
                set_cookie = headers_lower.get("set-cookie", "")
                if cookie_lower in set_cookie.lower():
                    fired_rules.append(f"set-cookie:{cookie_name}")
                    rule_confidences.append(sig.confidence_base * 0.85)
                    break

            # 3. HTML body patterns
            html_hits = 0
            for pat in sig._compiled_html:
                if pat.search(body):
                    html_hits += 1
                    fired_rules.append(f"html:{pat.pattern[:40]}")
                    # Each additional HTML match boosts confidence slightly
                    rule_confidences.append(
                        sig.confidence_base * (0.75 + min(html_hits - 1, 3) * 0.05)
                    )

            # 4. Meta patterns (inside <head>)
            head_slice = body[:4096]  # meta tags are near the top
            for pat in sig._compiled_meta:
                if pat.search(head_slice):
                    fired_rules.append(f"meta:{pat.pattern[:40]}")
                    rule_confidences.append(sig.confidence_base * 0.95)

            # 5. Script src patterns
            for pat in sig._compiled_scripts:
                if pat.search(body):
                    fired_rules.append(f"script:{pat.pattern[:40]}")
                    rule_confidences.append(sig.confidence_base * 0.80)

            # 6. Link href patterns
            for pat in sig._compiled_links:
                if pat.search(body):
                    fired_rules.append(f"link:{pat.pattern[:40]}")
                    rule_confidences.append(sig.confidence_base * 0.75)

            # 7. URL patterns
            for pat in sig._compiled_url:
                if pat.search(url):
                    fired_rules.append(f"url:{pat.pattern[:40]}")
                    rule_confidences.append(sig.confidence_base * 0.65)

            if not fired_rules:
                continue

            # Deduplicate rule labels
            fired_rules = list(dict.fromkeys(fired_rules))

            # Confidence = highest individual score,
            # boosted +0.05 for each additional independent rule (capped at 0.99)
            base_conf = max(rule_confidences)
            bonus = min((len(set(r.split(":")[0] for r in fired_rules)) - 1) * 0.05, 0.15)
            confidence = min(base_conf + bonus, 0.99)

            # Version extraction (runs on full body + headers combined)
            combined_text = body + "\n" + " ".join(headers_lower.values())
            version = _extract_version(sig.name, combined_text)

            if sig.name in matches:
                existing = matches[sig.name]
                if confidence > existing.confidence:
                    matches[sig.name] = TechMatch(
                        name=sig.name,
                        category=sig.category,
                        confidence=confidence,
                        matched_rules=fired_rules,
                        version=version or existing.version,
                    )
            else:
                matches[sig.name] = TechMatch(
                    name=sig.name,
                    category=sig.category,
                    confidence=confidence,
                    matched_rules=fired_rules,
                    version=version,
                )

        # --- Resolve implies ---
        implied: dict[str, TechMatch] = {}
        for match in list(matches.values()):
            sig_obj = next((s for s in self._sigs if s.name == match.name), None)
            if sig_obj:
                for implied_name in sig_obj.implies:
                    if implied_name not in matches and implied_name not in implied:
                        implied[implied_name] = TechMatch(
                            name=implied_name,
                            category=self._category_for(implied_name),
                            confidence=round(match.confidence * 0.75, 2),
                            matched_rules=[f"implied_by:{match.name}"],
                            implied_by=match.name,
                        )
        matches.update(implied)

        # --- Merge Phase 2 techs at baseline confidence ---
        for tech_name in probe.phase2_techs:
            if tech_name and tech_name not in matches:
                matches[tech_name] = TechMatch(
                    name=tech_name,
                    category=TechCategory.OTHER,
                    confidence=0.60,
                    matched_rules=["phase2:httpx-tech-detect"],
                )
            elif tech_name in matches:
                # Phase 2 confirms — slight confidence boost
                existing = matches[tech_name]
                if "phase2:httpx-tech-detect" not in existing.matched_rules:
                    existing.matched_rules.append("phase2:httpx-tech-detect")
                    existing.confidence = min(existing.confidence + 0.03, 0.99)

        # --- Sort: by confidence desc, then name asc ---
        return sorted(matches.values(), key=lambda m: (-m.confidence, m.name))

    def _category_for(self, name: str) -> TechCategory:
        for sig in self._sigs:
            if sig.name == name:
                return sig.category
        return TechCategory.OTHER
