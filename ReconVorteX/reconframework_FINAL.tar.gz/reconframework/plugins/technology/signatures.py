"""
plugins/technology/signatures.py
==================================
Technology signature database for ReconFramework Phase 3.

Each Signature defines HOW to detect a technology:
  • header_patterns   — HTTP response headers (header_name → regex list)
  • html_patterns     — Raw HTML body regexes
  • meta_patterns     — <meta> tag content regexes
  • script_patterns   — <script src="..."> URL regexes
  • link_patterns     — <link href="..."> URL regexes
  • cookie_patterns   — Cookie name substrings (case-insensitive)
  • url_patterns      — Applied against the HOST URL itself

confidence_base: float [0.0–1.0]
  Starting confidence when this signature matches.
  Confidence is boosted when multiple independent rules fire.

implies: list[str]
  Names of other technologies inferred if this one is detected.
  E.g. WordPress → PHP, Apache/Nginx, MySQL

Priority: Higher = shown/scored first in reports.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum


# ---------------------------------------------------------------------------
# Category enum
# ---------------------------------------------------------------------------

class TechCategory(str, Enum):
    CMS          = "cms"
    WEB_SERVER   = "web_server"
    LANGUAGE     = "language"
    FRAMEWORK    = "framework"
    JS_FRAMEWORK = "js_framework"
    ADMIN_PANEL  = "admin_panel"
    MONITORING   = "monitoring"
    CI_CD        = "ci_cd"
    DATABASE     = "database"
    CLOUD        = "cloud"
    SECURITY     = "security"
    OTHER        = "other"


# ---------------------------------------------------------------------------
# Signature dataclass
# ---------------------------------------------------------------------------

@dataclass
class Signature:
    name: str
    category: TechCategory
    confidence_base: float                        # 0.0 – 1.0
    priority: int = 50                            # lower = higher priority

    # Matching rules (all optional; any match fires the signature)
    header_patterns: dict[str, list[str]] = field(default_factory=dict)
    html_patterns:   list[str] = field(default_factory=list)
    meta_patterns:   list[str] = field(default_factory=list)
    script_patterns: list[str] = field(default_factory=list)
    link_patterns:   list[str] = field(default_factory=list)
    cookie_patterns: list[str] = field(default_factory=list)
    url_patterns:    list[str] = field(default_factory=list)
    implies:         list[str] = field(default_factory=list)

    # Compiled patterns (populated by _compile())
    _compiled_headers:  dict[str, list[re.Pattern]] = field(default_factory=dict, repr=False)
    _compiled_html:     list[re.Pattern] = field(default_factory=list, repr=False)
    _compiled_meta:     list[re.Pattern] = field(default_factory=list, repr=False)
    _compiled_scripts:  list[re.Pattern] = field(default_factory=list, repr=False)
    _compiled_links:    list[re.Pattern] = field(default_factory=list, repr=False)
    _compiled_url:      list[re.Pattern] = field(default_factory=list, repr=False)

    def compile(self) -> "Signature":
        """Pre-compile all regex patterns. Call once at startup."""
        flags = re.IGNORECASE | re.DOTALL

        self._compiled_headers = {
            h.lower(): [re.compile(p, flags) for p in pats]
            for h, pats in self.header_patterns.items()
        }
        self._compiled_html    = [re.compile(p, flags) for p in self.html_patterns]
        self._compiled_meta    = [re.compile(p, flags) for p in self.meta_patterns]
        self._compiled_scripts = [re.compile(p, flags) for p in self.script_patterns]
        self._compiled_links   = [re.compile(p, flags) for p in self.link_patterns]
        self._compiled_url     = [re.compile(p, flags) for p in self.url_patterns]
        return self


# ---------------------------------------------------------------------------
# Signature registry
# ---------------------------------------------------------------------------

SIGNATURES: list[Signature] = [

    # ===================================================================
    # WEB SERVERS
    # ===================================================================

    Signature(
        name="Nginx",
        category=TechCategory.WEB_SERVER,
        confidence_base=0.95,
        priority=10,
        header_patterns={"server": [r"nginx"]},
        html_patterns=[r"<hr><center>nginx</center>"],
    ),

    Signature(
        name="Apache",
        category=TechCategory.WEB_SERVER,
        confidence_base=0.95,
        priority=10,
        header_patterns={"server": [r"apache"]},
        html_patterns=[
            r"Apache/([\d.]+)",
            r"<address>Apache",
        ],
    ),

    Signature(
        name="IIS",
        category=TechCategory.WEB_SERVER,
        confidence_base=0.95,
        priority=10,
        header_patterns={
            "server": [r"Microsoft-IIS"],
            "x-powered-by": [r"ASP\.NET"],
        },
    ),

    Signature(
        name="LiteSpeed",
        category=TechCategory.WEB_SERVER,
        confidence_base=0.90,
        priority=10,
        header_patterns={"server": [r"LiteSpeed"]},
    ),

    Signature(
        name="Caddy",
        category=TechCategory.WEB_SERVER,
        confidence_base=0.90,
        priority=10,
        header_patterns={"server": [r"Caddy"]},
    ),

    # ===================================================================
    # LANGUAGES / RUNTIMES
    # ===================================================================

    Signature(
        name="PHP",
        category=TechCategory.LANGUAGE,
        confidence_base=0.90,
        priority=15,
        header_patterns={
            "x-powered-by": [r"PHP/([\d.]+)"],
            "set-cookie":   [r"PHPSESSID"],
        },
        cookie_patterns=["PHPSESSID"],
        html_patterns=[r"\.php[\?#\"']"],
    ),

    Signature(
        name="ASP.NET",
        category=TechCategory.LANGUAGE,
        confidence_base=0.90,
        priority=15,
        header_patterns={
            "x-powered-by": [r"ASP\.NET"],
            "x-aspnet-version": [r".+"],
            "set-cookie": [r"ASP\.NET_SessionId"],
        },
        cookie_patterns=["ASP.NET_SessionId", "ASPSESSIONID"],
    ),

    Signature(
        name="Python",
        category=TechCategory.LANGUAGE,
        confidence_base=0.75,
        priority=15,
        header_patterns={
            "x-powered-by": [r"Python"],
            "server": [r"(gunicorn|uvicorn|waitress|werkzeug)"],
        },
    ),

    Signature(
        name="Ruby",
        category=TechCategory.LANGUAGE,
        confidence_base=0.75,
        priority=15,
        header_patterns={
            "x-powered-by": [r"Phusion Passenger|Ruby"],
            "server": [r"Passenger|WEBrick|Puma"],
            "set-cookie": [r"_session_id"],
        },
    ),

    Signature(
        name="Node.js",
        category=TechCategory.LANGUAGE,
        confidence_base=0.80,
        priority=15,
        header_patterns={
            "x-powered-by": [r"Express"],
            "server": [r"node\.js"],
        },
    ),

    # ===================================================================
    # CMS
    # ===================================================================

    Signature(
        name="WordPress",
        category=TechCategory.CMS,
        confidence_base=0.95,
        priority=20,
        header_patterns={
            "link": [r"rel=.https://api\.w\.org/"],
            "x-pingback": [r"/xmlrpc\.php"],
        },
        html_patterns=[
            r"/wp-content/",
            r"/wp-includes/",
            r'content="WordPress',
            r"wp-json",
            r'id=["\']wpadminbar["\']',
        ],
        meta_patterns=[
            r'name=["\']generator["\'][^>]+WordPress',
            r'WordPress[\s]([\d.]+)',
        ],
        script_patterns=[r"/wp-content/", r"/wp-includes/"],
        link_patterns=[r"/wp-content/", r"wp-json"],
        cookie_patterns=["wordpress_logged_in", "wp-settings", "wordpress_test_cookie"],
        implies=["PHP", "MySQL"],
    ),

    Signature(
        name="Drupal",
        category=TechCategory.CMS,
        confidence_base=0.92,
        priority=20,
        header_patterns={
            "x-generator": [r"Drupal"],
            "x-drupal-cache": [r".+"],
            "x-drupal-dynamic-cache": [r".+"],
        },
        html_patterns=[
            r"Drupal\.settings",
            r"/sites/(default|all)/",
            r"drupal\.js",
            r'data-drupal-',
            r'"drupalSettings"',
            r"drupalSettings",
        ],
        meta_patterns=[
            r'name=["\']generator["\'][^>]+Drupal',
        ],
        cookie_patterns=["SESS", "SSESS"],
        implies=["PHP"],
    ),

    Signature(
        name="Joomla",
        category=TechCategory.CMS,
        confidence_base=0.92,
        priority=20,
        html_patterns=[
            r"/media/jui/",
            r"/media/system/js/",
            r"Joomla!",
            r"option=com_",
            r"/components/com_",
        ],
        meta_patterns=[
            r'name=["\']generator["\'][^>]+Joomla',
        ],
        cookie_patterns=["joomla_user_state", "joomla_remember_me"],
        implies=["PHP"],
    ),

    Signature(
        name="Magento",
        category=TechCategory.CMS,
        confidence_base=0.90,
        priority=20,
        html_patterns=[
            r"Mage\.Cookies",
            r"/skin/frontend/",
            r"Magento",
            r"/js/mage/",
        ],
        cookie_patterns=["frontend", "adminhtml"],
        implies=["PHP"],
    ),

    Signature(
        name="Shopify",
        category=TechCategory.CMS,
        confidence_base=0.92,
        priority=20,
        html_patterns=[
            r"cdn\.shopify\.com",
            r"Shopify\.theme",
            r"myshopify\.com",
        ],
        script_patterns=[r"cdn\.shopify\.com"],
        header_patterns={"x-shopid": [r".+"]},
    ),

    Signature(
        name="Ghost",
        category=TechCategory.CMS,
        confidence_base=0.88,
        priority=20,
        html_patterns=[r"ghost\.js", r"/ghost/"],
        meta_patterns=[r'name=["\']generator["\'][^>]+Ghost'],
        link_patterns=[r"ghost/"],
        implies=["Node.js"],
    ),

    # ===================================================================
    # BACKEND FRAMEWORKS
    # ===================================================================

    Signature(
        name="Laravel",
        category=TechCategory.FRAMEWORK,
        confidence_base=0.88,
        priority=25,
        cookie_patterns=["laravel_session", "XSRF-TOKEN"],
        header_patterns={
            "set-cookie": [r"laravel_session"],
            "x-powered-by": [r"Laravel"],
        },
        html_patterns=[
            r"laravel",
            r'name=["\']_token["\']',
        ],
        implies=["PHP"],
    ),

    Signature(
        name="Django",
        category=TechCategory.FRAMEWORK,
        confidence_base=0.85,
        priority=25,
        cookie_patterns=["csrftoken", "sessionid", "django"],
        header_patterns={
            "set-cookie": [r"csrftoken|django"],
            "x-frame-options": [r"SAMEORIGIN"],
        },
        html_patterns=[
            r'name=["\']csrfmiddlewaretoken["\']',
            r"django",
        ],
        implies=["Python"],
    ),

    Signature(
        name="Flask",
        category=TechCategory.FRAMEWORK,
        confidence_base=0.80,
        priority=25,
        cookie_patterns=["session"],
        header_patterns={"server": [r"Werkzeug"]},
        implies=["Python"],
    ),

    Signature(
        name="Spring Boot",
        category=TechCategory.FRAMEWORK,
        confidence_base=0.85,
        priority=25,
        header_patterns={
            "x-application-context": [r".+"],
            "server": [r"Apache-Coyote|Tomcat"],
        },
        html_patterns=[r"Spring"],
        url_patterns=[r"actuator|/api/v\d"],
    ),

    Signature(
        name="Ruby on Rails",
        category=TechCategory.FRAMEWORK,
        confidence_base=0.85,
        priority=25,
        cookie_patterns=["_rails_session", "_session_id"],
        header_patterns={
            "set-cookie": [r"_rails_session"],
            "x-runtime": [r"[\d.]+"],
            "x-request-id": [r"[\w-]+"],
        },
        html_patterns=[r'name=["\']authenticity_token["\']'],
        implies=["Ruby"],
    ),

    Signature(
        name="Express",
        category=TechCategory.FRAMEWORK,
        confidence_base=0.80,
        priority=25,
        header_patterns={"x-powered-by": [r"Express"]},
        implies=["Node.js"],
    ),

    Signature(
        name="FastAPI",
        category=TechCategory.FRAMEWORK,
        confidence_base=0.82,
        priority=25,
        html_patterns=[r"FastAPI", r"ReDoc", r"Swagger UI"],
        url_patterns=[r"/docs|/redoc|/openapi\.json"],
        implies=["Python"],
    ),

    # ===================================================================
    # JAVASCRIPT FRAMEWORKS / LIBRARIES
    # ===================================================================

    Signature(
        name="React",
        category=TechCategory.JS_FRAMEWORK,
        confidence_base=0.85,
        priority=30,
        html_patterns=[
            r'data-reactroot',
            r'data-reactid',
            r"__REACT_DEVTOOLS",
            r"react\.development\.js|react\.production\.min\.js",
            r"_reactFiber|__reactFiber",
        ],
        script_patterns=[
            r"react(\.min)?\.js",
            r"react-dom",
            r"/static/js/(main|bundle|chunk)\.",
        ],
        meta_patterns=[r'name=["\']next-head-count["\']'],
    ),

    Signature(
        name="Next.js",
        category=TechCategory.JS_FRAMEWORK,
        confidence_base=0.88,
        priority=30,
        html_patterns=[
            r"__NEXT_DATA__",
            r"_next/static",
            r"__nextjs",
        ],
        script_patterns=[r"_next/static"],
        header_patterns={"x-powered-by": [r"Next\.js"]},
        implies=["React", "Node.js"],
    ),

    Signature(
        name="Angular",
        category=TechCategory.JS_FRAMEWORK,
        confidence_base=0.85,
        priority=30,
        html_patterns=[
            r"ng-version",
            r"ng-app",
            r"ng-controller",
            r"angular\.js|angular\.min\.js",
            r'<app-root',
        ],
        script_patterns=[
            r"angular(\.min)?\.js",
            r"zone\.js",
            r"runtime\.[a-f0-9]+\.js",
        ],
    ),

    Signature(
        name="Vue.js",
        category=TechCategory.JS_FRAMEWORK,
        confidence_base=0.85,
        priority=30,
        html_patterns=[
            r"Vue\.js",
            r"__vue__",
            r"v-bind:|v-if|v-for|v-model",
            r"vue\.runtime",
        ],
        script_patterns=[
            r"vue(\.min)?\.js",
            r"vue\.runtime",
            r"vuex",
        ],
    ),

    Signature(
        name="jQuery",
        category=TechCategory.JS_FRAMEWORK,
        confidence_base=0.80,
        priority=35,
        html_patterns=[r"jquery", r"jQuery"],
        script_patterns=[r"jquery([-.\d]*)?(\.min)?\.js"],
    ),

    Signature(
        name="Bootstrap",
        category=TechCategory.JS_FRAMEWORK,
        confidence_base=0.78,
        priority=35,
        html_patterns=[
            r'class=["\'][^"\']*\b(container|row|col-|navbar)\b',
            r"bootstrap",
        ],
        script_patterns=[r"bootstrap(\.bundle)?(\.min)?\.js"],
        link_patterns=[r"bootstrap(\.min)?\.css"],
    ),

    Signature(
        name="Nuxt.js",
        category=TechCategory.JS_FRAMEWORK,
        confidence_base=0.88,
        priority=30,
        html_patterns=[r"__NUXT__", r"_nuxt/"],
        script_patterns=[r"_nuxt/"],
        implies=["Vue.js", "Node.js"],
    ),

    # ===================================================================
    # ADMIN PANELS (high bug-bounty value)
    # ===================================================================

    Signature(
        name="Jenkins",
        category=TechCategory.CI_CD,
        confidence_base=0.95,
        priority=5,
        html_patterns=[
            r"Jenkins",
            r"hudson",
            r'id=["\']jenkins["\']',
            r"<title>Dashboard \[Jenkins\]",
            r"jenkins\.js",
        ],
        header_patterns={
            "x-jenkins": [r".+"],
            "x-jenkins-session": [r".+"],
        },
        url_patterns=[r"/jenkins", r"/hudson"],
        cookie_patterns=["JSESSIONID.jenkins", "jenkins-remember-me"],
    ),

    Signature(
        name="Grafana",
        category=TechCategory.MONITORING,
        confidence_base=0.95,
        priority=5,
        html_patterns=[
            r"Grafana",
            r"grafana",
            r'app="grafana"',
            r'"version":\s*"Grafana',
        ],
        header_patterns={"x-grafana-org-id": [r".+"]},
        url_patterns=[r"/grafana", r"grafana\."],
        script_patterns=[r"grafana"],
    ),

    Signature(
        name="Jira",
        category=TechCategory.ADMIN_PANEL,
        confidence_base=0.95,
        priority=5,
        html_patterns=[
            r"JIRA",
            r"Jira",
            r"atlassian",
            r'id=["\']jira["\']',
            r"jira-frontend",
        ],
        meta_patterns=[r'name=["\']application-name["\'][^>]+JIRA'],
        header_patterns={"x-asen": [r".+"], "atl-traceid": [r".+"]},
        url_patterns=[r"/jira", r"jira\."],
        cookie_patterns=["JSESSIONID", "atlassian.xsrf.token"],
    ),

    Signature(
        name="Confluence",
        category=TechCategory.ADMIN_PANEL,
        confidence_base=0.95,
        priority=5,
        html_patterns=[
            r"Confluence",
            r"confluence",
            r"atlassian-confluence",
        ],
        cookie_patterns=["confluence", "atlassian.xsrf.token"],
        url_patterns=[r"/confluence"],
    ),

    Signature(
        name="Kibana",
        category=TechCategory.MONITORING,
        confidence_base=0.95,
        priority=5,
        html_patterns=[
            r"Kibana",
            r"kibana",
            r"kbn-",
            r'"kbnVersion"',
        ],
        header_patterns={"kbn-name": [r"kibana"]},
        url_patterns=[r"/kibana", r":5601"],
    ),

    Signature(
        name="SonarQube",
        category=TechCategory.CI_CD,
        confidence_base=0.95,
        priority=5,
        html_patterns=[
            r"SonarQube",
            r"sonarqube",
            r"sq-navbar",
            r'"SonarQube"',
        ],
        url_patterns=[r"/sonar", r"sonar\."],
        meta_patterns=[r'name=["\']application-name["\'][^>]+SonarQube'],
    ),

    Signature(
        name="GitLab",
        category=TechCategory.CI_CD,
        confidence_base=0.95,
        priority=5,
        html_patterns=[
            r"GitLab",
            r'content=["\']GitLab',
            r"gl-header",
            r"gitlab-ci",
        ],
        meta_patterns=[r'name=["\']generator["\'][^>]+GitLab'],
        cookie_patterns=["_gitlab_session"],
        url_patterns=[r"/gitlab"],
    ),

    Signature(
        name="phpMyAdmin",
        category=TechCategory.ADMIN_PANEL,
        confidence_base=0.95,
        priority=5,
        html_patterns=[
            r"phpMyAdmin",
            r"phpmyadmin",
            r"PMA_VERSION",
        ],
        meta_patterns=[r'name=["\']generator["\'][^>]+phpMyAdmin'],
        cookie_patterns=["phpMyAdmin", "pma_lang"],
        url_patterns=[r"/phpmyadmin", r"/pma"],
        implies=["PHP", "MySQL"],
    ),

    Signature(
        name="Prometheus",
        category=TechCategory.MONITORING,
        confidence_base=0.90,
        priority=5,
        html_patterns=[r"Prometheus", r"/metrics"],
        url_patterns=[r"/prometheus", r":9090"],
    ),

    Signature(
        name="Portainer",
        category=TechCategory.ADMIN_PANEL,
        confidence_base=0.90,
        priority=5,
        html_patterns=[r"Portainer", r"portainer"],
        url_patterns=[r"/portainer", r":9000"],
    ),

    Signature(
        name="Rancher",
        category=TechCategory.ADMIN_PANEL,
        confidence_base=0.90,
        priority=5,
        html_patterns=[r"Rancher", r"rancher"],
        url_patterns=[r"/rancher"],
    ),

    # ===================================================================
    # CDN / CLOUD
    # ===================================================================

    Signature(
        name="Cloudflare",
        category=TechCategory.CLOUD,
        confidence_base=0.90,
        priority=40,
        header_patterns={
            "server": [r"cloudflare"],
            "cf-ray": [r".+"],
            "cf-cache-status": [r".+"],
        },
    ),

    Signature(
        name="AWS CloudFront",
        category=TechCategory.CLOUD,
        confidence_base=0.90,
        priority=40,
        header_patterns={
            "x-amz-cf-id": [r".+"],
            "x-amz-cf-pop": [r".+"],
            "via": [r"CloudFront"],
        },
    ),

    Signature(
        name="Fastly",
        category=TechCategory.CLOUD,
        confidence_base=0.88,
        priority=40,
        header_patterns={
            "x-served-by": [r"cache-"],
            "x-cache": [r"HIT|MISS"],
            "fastly-restarts": [r".+"],
        },
    ),

    Signature(
        name="Akamai",
        category=TechCategory.CLOUD,
        confidence_base=0.88,
        priority=40,
        header_patterns={
            "x-check-cacheable": [r".+"],
            "x-akamai-transformed": [r".+"],
            "server": [r"AkamaiGHost"],
        },
    ),

    # ===================================================================
    # SECURITY
    # ===================================================================

    Signature(
        name="reCAPTCHA",
        category=TechCategory.SECURITY,
        confidence_base=0.85,
        priority=50,
        html_patterns=[r"recaptcha", r"g-recaptcha"],
        script_patterns=[r"recaptcha\.js", r"recaptcha/api"],
    ),

    Signature(
        name="Sucuri",
        category=TechCategory.SECURITY,
        confidence_base=0.88,
        priority=45,
        header_patterns={"x-sucuri-id": [r".+"], "x-sucuri-cache": [r".+"]},
    ),

    Signature(
        name="ModSecurity",
        category=TechCategory.SECURITY,
        confidence_base=0.75,
        priority=45,
        header_patterns={"server": [r"mod_security|ModSecurity"]},
    ),

    # ===================================================================
    # API / DOCS
    # ===================================================================

    Signature(
        name="Swagger UI",
        category=TechCategory.OTHER,
        confidence_base=0.90,
        priority=10,
        html_patterns=[
            r"swagger-ui",
            r"SwaggerUI",
            r"swagger\.json",
            r"api-docs",
        ],
        url_patterns=[r"/swagger", r"/api-docs", r"/swagger-ui"],
        script_patterns=[r"swagger-ui"],
    ),

    Signature(
        name="GraphQL",
        category=TechCategory.OTHER,
        confidence_base=0.88,
        priority=10,
        html_patterns=[r"graphql", r"GraphiQL", r"GraphQL Playground"],
        url_patterns=[r"/graphql", r"/graphiql"],
    ),

]


# ---------------------------------------------------------------------------
# Compile all signatures at module import time
# ---------------------------------------------------------------------------

def get_compiled_signatures() -> list[Signature]:
    """Return signatures with all regex patterns pre-compiled."""
    return [sig.compile() for sig in SIGNATURES]


# Singleton — import this in fingerprinter.py
COMPILED_SIGNATURES: list[Signature] = get_compiled_signatures()
