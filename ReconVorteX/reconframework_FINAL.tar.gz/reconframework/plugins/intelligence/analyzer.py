"""
plugins/intelligence/analyzer.py
==================================
Asset Intelligence Analyzer for Phase 4.

Takes a combined view of Phase 1/2/3 data per asset and runs every
IntelRule against it, producing an AssetIntelligence record with:
  • risk_level   — CRITICAL / HIGH / MEDIUM / LOW / INFO
  • score        — raw numeric score for sorting
  • reasons      — human descriptions of every rule that fired
  • confidence   — weighted average across fired rules
  • tags         — deduplicated semantic labels

Design
------
The analyzer is stateless — create once, call analyse() in any coroutine.
Login-form and open-redirect detection is performed inline via regex so
Phase 4 needs no extra HTTP round-trips (it works from stored Phase 2
body data or the live_hosts.json redirect_chain field).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from core.config import Phase4Config
from core.models import AssetIntelligence, RiskLevel
from plugins.intelligence.rules import COMPILED_RULES, IntelRule, RuleCategory

# ---------------------------------------------------------------------------
# Login-form detection helpers
# ---------------------------------------------------------------------------

# Patterns that strongly suggest a login form is present
_LOGIN_FORM_PATTERNS: list[re.Pattern] = [
    re.compile(p, re.IGNORECASE | re.DOTALL)
    for p in [
        r'<form[^>]*(login|signin|auth|password)[^>]*>',
        r'<input[^>]*type=["\']password["\']',
        r'name=["\'](password|passwd|pwd|pass)["\']',
        r'(action|href)=["\'][^"\']*/(login|signin|auth|logon)["\']',
        r'<button[^>]*>(sign[\s-]?in|log[\s-]?in|login)</button>',
    ]
]

# Patterns that flag open redirects in a URL string
_OPEN_REDIRECT_PARAMS: re.Pattern = re.compile(
    r'[?&](redirect|return|next|url|goto|redir|dest|destination|callback|redirect_uri)'
    r'=https?://',
    re.IGNORECASE,
)


def _detect_login_form(html_body: str) -> bool:
    return any(p.search(html_body) for p in _LOGIN_FORM_PATTERNS)


def _detect_open_redirect(redirect_chain: list[str], target_domain: str) -> bool:
    """
    Return True if any URL in the redirect chain redirects to an external domain,
    OR if any URL contains an open-redirect query parameter pointing off-domain.
    """
    domain_root = target_domain.lower()
    for url in redirect_chain:
        url_lower = url.lower()
        # External-domain redirect
        if url_lower.startswith("http") and domain_root not in url_lower:
            return True
        # Open-redirect parameter
        if _OPEN_REDIRECT_PARAMS.search(url_lower):
            return True
    return False


# ---------------------------------------------------------------------------
# Asset context (input)
# ---------------------------------------------------------------------------

@dataclass
class AssetContext:
    """
    Unified view of one asset across all three completed phases.

    Fields map directly to what is stored in live_hosts.json /
    technologies.json / subdomains.json.
    """

    host:           str
    url:            str
    status_code:    int | None       = None
    title:          str | None       = None
    redirect_chain: list[str]        = field(default_factory=list)
    ip_address:     str | None       = None
    web_server:     str | None       = None
    technologies:   list[str]        = field(default_factory=list)
    html_body:      str              = ""    # populated when available
    domain:         str              = ""    # root domain for redirect checks


# ---------------------------------------------------------------------------
# Analyser
# ---------------------------------------------------------------------------

@dataclass
class RuleFiring:
    rule:       IntelRule
    confidence: float


class AssetAnalyzer:
    """
    Stateless intelligence analyser.

    Usage:
        analyzer = AssetAnalyzer(cfg.phase4)
        result   = analyzer.analyse(context)
    """

    def __init__(self, cfg: Phase4Config) -> None:
        self._cfg   = cfg
        self._rules = COMPILED_RULES

    # ------------------------------------------------------------------
    # Public
    # ------------------------------------------------------------------

    def analyse(self, ctx: AssetContext) -> AssetIntelligence | None:
        """
        Run all enabled rules against the asset context.

        Returns None if the asset scores below min_confidence on all rules
        (i.e. totally uninteresting).
        """
        # Pre-compute signals once
        login_form_present  = _detect_login_form(ctx.html_body) if ctx.html_body else False
        open_redirect_found = _detect_open_redirect(ctx.redirect_chain, ctx.domain)

        firings: list[RuleFiring] = []

        for rule in self._rules:
            if not self._rule_enabled(rule):
                continue
            if self._rule_fires(rule, ctx, login_form_present, open_redirect_found):
                firings.append(RuleFiring(rule=rule, confidence=rule.confidence))

        if not firings:
            return None

        # --- Aggregate ---
        total_score     = sum(f.rule.score for f in firings)
        avg_confidence  = sum(f.confidence for f in firings) / len(firings)

        if avg_confidence < self._cfg.min_confidence:
            return None

        reasons = [f.rule.description for f in firings]
        tags    = sorted({tag for f in firings for tag in f.rule.tags})

        risk = self._score_to_risk(total_score)

        return AssetIntelligence(
            host=ctx.host,
            url=ctx.url,
            risk_level=risk,
            reasons=reasons,
            confidence=round(min(avg_confidence, 0.99), 3),
            tags=tags,
        )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _rule_enabled(self, rule: IntelRule) -> bool:
        cfg = self._cfg
        return {
            RuleCategory.HOSTNAME:   cfg.enable_hostname_analysis,
            RuleCategory.TITLE:      cfg.enable_title_analysis,
            RuleCategory.TECHNOLOGY: cfg.enable_tech_analysis,
            RuleCategory.BEHAVIOR:   cfg.enable_behavior_analysis,
            RuleCategory.NETWORK:    True,
        }.get(rule.category, True)

    @staticmethod
    def _rule_fires(
        rule:               IntelRule,
        ctx:                AssetContext,
        login_form_present: bool,
        open_redirect:      bool,
    ) -> bool:
        """Return True if any matcher on the rule hits the asset context."""

        # Hostname regex
        if rule._hostname_compiled:
            if rule._hostname_compiled.search(ctx.host):
                return True

        # Title regex
        if rule._title_compiled and ctx.title:
            if rule._title_compiled.search(ctx.title):
                return True

        # Technology membership
        if rule.tech_names:
            tech_set = {t.lower() for t in ctx.technologies}
            if any(tn.lower() in tech_set for tn in rule.tech_names):
                return True

        # HTTP status code
        if rule.status_codes and ctx.status_code in rule.status_codes:
            return True

        # Login form signal
        if rule.has_login_form is True and login_form_present:
            return True
        if rule.has_login_form is False and not login_form_present:
            return True

        # Open redirect signal
        if rule.has_open_redirect is True and open_redirect:
            return True

        return False

    def _score_to_risk(self, score: int) -> RiskLevel:
        cfg = self._cfg
        if score >= cfg.score_critical:
            return RiskLevel.CRITICAL
        if score >= cfg.score_high:
            return RiskLevel.HIGH
        if score >= cfg.score_medium:
            return RiskLevel.MEDIUM
        if score >= cfg.score_low:
            return RiskLevel.LOW
        return RiskLevel.INFO
