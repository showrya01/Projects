"""
plugins/intelligence/rules.py
================================
Asset Intelligence scoring rules for Phase 4.

Architecture
------------
Each IntelRule defines:
  • A unique name and human description.
  • One or more matchers (hostname_re, title_re, tech_names, status_codes, …).
  • A score contribution (+2 to +20).
  • A confidence weight (0.0–1.0).
  • A list of semantic tags added to the asset when the rule fires.
  • An optional category label used for grouping in reports.

The Analyser iterates all rules against an AssetContext, sums the scores,
and derives the risk tier from the Phase4Config thresholds.

Adding a new rule:
  Just append to INTEL_RULES — no other files need changing.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum


class RuleCategory(str, Enum):
    HOSTNAME   = "hostname"
    TITLE      = "title"
    TECHNOLOGY = "technology"
    BEHAVIOR   = "behavior"
    NETWORK    = "network"


@dataclass
class IntelRule:
    """A single scoring rule applied to one asset."""

    name:        str
    description: str
    category:    RuleCategory
    score:       int            # Points added when this rule fires
    confidence:  float          # Confidence contribution (0.0–1.0)
    tags:        list[str] = field(default_factory=list)

    # --- Matchers (any non-None matcher that matches fires the rule) ---

    # Regex applied to the hostname (e.g. "sub.example.com")
    hostname_re:  str | None = None
    # Regex applied to the page title
    title_re:     str | None = None
    # Any of these technology names present in tech list fires the rule
    tech_names:   list[str]  = field(default_factory=list)
    # Any of these HTTP status codes fires the rule
    status_codes: list[int]  = field(default_factory=list)
    # True = fires when a login form is detected; False = fires when absent; None = ignore
    has_login_form: bool | None = None
    # True = fires when any redirect has an external domain
    has_open_redirect: bool | None = None

    # Compiled regex (populated by compile())
    _hostname_compiled: re.Pattern | None = field(default=None, repr=False)
    _title_compiled:    re.Pattern | None = field(default=None, repr=False)

    def compile(self) -> "IntelRule":
        flags = re.IGNORECASE
        if self.hostname_re:
            self._hostname_compiled = re.compile(self.hostname_re, flags)
        if self.title_re:
            self._title_compiled = re.compile(self.title_re, flags)
        return self


# ---------------------------------------------------------------------------
# Rule definitions
# ---------------------------------------------------------------------------

INTEL_RULES: list[IntelRule] = [

    # ===================================================================
    # HOSTNAME — keywords that scream "interesting target"
    # ===================================================================

    IntelRule(
        name="hostname_admin",
        description="Hostname contains 'admin' — likely an admin panel",
        category=RuleCategory.HOSTNAME,
        score=7, confidence=0.85,
        tags=["admin-panel", "high-value"],
        hostname_re=r"(^|\.)admin[\.\-]|[\.\-]admin\.|^admin\.",
    ),
    IntelRule(
        name="hostname_panel",
        description="Hostname contains 'panel' — likely a control panel",
        category=RuleCategory.HOSTNAME,
        score=7, confidence=0.80,
        tags=["admin-panel", "high-value"],
        hostname_re=r"[\.\-]panel[\.\-]|^panel\.",
    ),
    IntelRule(
        name="hostname_dashboard",
        description="Hostname contains 'dashboard'",
        category=RuleCategory.HOSTNAME,
        score=6, confidence=0.80,
        tags=["dashboard", "high-value"],
        hostname_re=r"[\.\-]dashboard[\.\-]|^dashboard\.",
    ),
    IntelRule(
        name="hostname_portal",
        description="Hostname contains 'portal' — employee/customer portal",
        category=RuleCategory.HOSTNAME,
        score=5, confidence=0.75,
        tags=["portal"],
        hostname_re=r"[\.\-]portal[\.\-]|^portal\.",
    ),
    IntelRule(
        name="hostname_dev",
        description="Hostname indicates a development environment",
        category=RuleCategory.HOSTNAME,
        score=5, confidence=0.80,
        tags=["dev-environment", "lower-security"],
        hostname_re=r"(^|[\.\-])(dev|develop|development)([\.\-]|$)",
    ),
    IntelRule(
        name="hostname_test",
        description="Hostname indicates a test environment",
        category=RuleCategory.HOSTNAME,
        score=5, confidence=0.80,
        tags=["test-environment", "lower-security"],
        hostname_re=r"(^|[\.\-])(test|testing|qa)([\.\-]|$)",
    ),
    IntelRule(
        name="hostname_staging",
        description="Hostname indicates a staging environment",
        category=RuleCategory.HOSTNAME,
        score=5, confidence=0.80,
        tags=["staging-environment", "lower-security"],
        hostname_re=r"(^|[\.\-])(stag|staging)([\.\-]|$)",
    ),
    IntelRule(
        name="hostname_beta",
        description="Hostname indicates a beta/pre-release environment",
        category=RuleCategory.HOSTNAME,
        score=3, confidence=0.70,
        tags=["beta-environment"],
        hostname_re=r"(^|[\.\-])beta([\.\-]|$)",
    ),
    IntelRule(
        name="hostname_internal",
        description="Hostname suggests internal/intranet service",
        category=RuleCategory.HOSTNAME,
        score=8, confidence=0.85,
        tags=["internal", "high-value"],
        hostname_re=r"(^|[\.\-])(internal|intranet|corp|corporate)([\.\-]|$)",
    ),
    IntelRule(
        name="hostname_vpn",
        description="Hostname suggests VPN or remote-access gateway",
        category=RuleCategory.HOSTNAME,
        score=8, confidence=0.85,
        tags=["vpn", "remote-access", "high-value"],
        hostname_re=r"(^|[\.\-])(vpn|remote|ras|sslvpn|citrix)([\.\-]|$)",
    ),
    IntelRule(
        name="hostname_api",
        description="Hostname is an API endpoint",
        category=RuleCategory.HOSTNAME,
        score=4, confidence=0.75,
        tags=["api"],
        hostname_re=r"(^|[\.\-])api([\.\-]|$)",
    ),
    IntelRule(
        name="hostname_auth",
        description="Hostname is an authentication/SSO service",
        category=RuleCategory.HOSTNAME,
        score=9, confidence=0.88,
        tags=["auth", "sso", "high-value"],
        hostname_re=r"(^|[\.\-])(auth|sso|login|idp|identity|oauth)([\.\-]|$)",
    ),
    IntelRule(
        name="hostname_backup",
        description="Hostname suggests backup or storage service",
        category=RuleCategory.HOSTNAME,
        score=6, confidence=0.75,
        tags=["backup", "sensitive-data"],
        hostname_re=r"(^|[\.\-])(backup|bak|archive|storage)([\.\-]|$)",
    ),
    IntelRule(
        name="hostname_mail",
        description="Hostname is a mail server or webmail",
        category=RuleCategory.HOSTNAME,
        score=5, confidence=0.78,
        tags=["mail", "email"],
        hostname_re=r"(^|[\.\-])(mail|webmail|smtp|mx|roundcube|owa)([\.\-]|$)",
    ),
    IntelRule(
        name="hostname_git",
        description="Hostname is a source-code / git server",
        category=RuleCategory.HOSTNAME,
        score=9, confidence=0.88,
        tags=["source-code", "git", "high-value"],
        hostname_re=r"(^|[\.\-])(git|gitlab|bitbucket|svn|repo)([\.\-]|$)",
    ),
    IntelRule(
        name="hostname_ci",
        description="Hostname is a CI/CD server",
        category=RuleCategory.HOSTNAME,
        score=9, confidence=0.88,
        tags=["ci-cd", "high-value"],
        hostname_re=r"(^|[\.\-])(ci|cd|jenkins|travis|bamboo|teamcity|drone)([\.\-]|$)",
    ),
    IntelRule(
        name="hostname_monitor",
        description="Hostname is a monitoring/observability service",
        category=RuleCategory.HOSTNAME,
        score=6, confidence=0.80,
        tags=["monitoring"],
        hostname_re=r"(^|[\.\-])(monitor|grafana|kibana|prometheus|nagios|zabbix)([\.\-]|$)",
    ),
    IntelRule(
        name="hostname_db",
        description="Hostname is a database management interface",
        category=RuleCategory.HOSTNAME,
        score=10, confidence=0.88,
        tags=["database", "admin-panel", "high-value"],
        hostname_re=r"(^|[\.\-])(db|database|mysql|pgsql|mongo|redis|phpmyadmin)([\.\-]|$)",
    ),

    # ===================================================================
    # TITLE — page title keywords
    # ===================================================================

    IntelRule(
        name="title_jenkins",
        description="Page title indicates Jenkins CI server",
        category=RuleCategory.TITLE,
        score=10, confidence=0.95,
        tags=["ci-cd", "jenkins", "high-value"],
        title_re=r"jenkins",
    ),
    IntelRule(
        name="title_grafana",
        description="Page title indicates Grafana dashboard",
        category=RuleCategory.TITLE,
        score=8, confidence=0.95,
        tags=["monitoring", "grafana", "high-value"],
        title_re=r"grafana",
    ),
    IntelRule(
        name="title_jira",
        description="Page title indicates Jira project management",
        category=RuleCategory.TITLE,
        score=8, confidence=0.92,
        tags=["project-management", "jira", "high-value"],
        title_re=r"jira",
    ),
    IntelRule(
        name="title_kibana",
        description="Page title indicates Kibana log explorer",
        category=RuleCategory.TITLE,
        score=8, confidence=0.95,
        tags=["monitoring", "kibana", "high-value"],
        title_re=r"kibana",
    ),
    IntelRule(
        name="title_sonarqube",
        description="Page title indicates SonarQube code quality",
        category=RuleCategory.TITLE,
        score=8, confidence=0.95,
        tags=["ci-cd", "sonarqube", "high-value"],
        title_re=r"sonarqube",
    ),
    IntelRule(
        name="title_phpmyadmin",
        description="Page title is phpMyAdmin (DB admin panel)",
        category=RuleCategory.TITLE,
        score=10, confidence=0.97,
        tags=["database", "admin-panel", "phpmyadmin", "high-value"],
        title_re=r"phpmyadmin",
    ),
    IntelRule(
        name="title_gitlab",
        description="Page title indicates GitLab",
        category=RuleCategory.TITLE,
        score=9, confidence=0.95,
        tags=["source-code", "gitlab", "high-value"],
        title_re=r"gitlab",
    ),
    IntelRule(
        name="title_portainer",
        description="Page title indicates Portainer Docker UI",
        category=RuleCategory.TITLE,
        score=9, confidence=0.95,
        tags=["container-management", "portainer", "high-value"],
        title_re=r"portainer",
    ),
    IntelRule(
        name="title_login",
        description="Page title contains login/sign-in keywords",
        category=RuleCategory.TITLE,
        score=5, confidence=0.75,
        tags=["login-portal", "authentication"],
        title_re=r"\b(login|log in|sign[- ]?in|sign on|authenticate|access)\b",
    ),
    IntelRule(
        name="title_admin",
        description="Page title contains 'admin' or 'administration'",
        category=RuleCategory.TITLE,
        score=7, confidence=0.82,
        tags=["admin-panel"],
        title_re=r"\b(admin|administration|administrator|control panel|management console)\b",
    ),
    IntelRule(
        name="title_vpn",
        description="Page title indicates VPN / remote access portal",
        category=RuleCategory.TITLE,
        score=8, confidence=0.88,
        tags=["vpn", "remote-access", "high-value"],
        title_re=r"\b(vpn|remote access|ssl vpn|clientless|anyconnect|pulse secure)\b",
    ),
    IntelRule(
        name="title_dashboard",
        description="Page title contains 'dashboard' or 'overview'",
        category=RuleCategory.TITLE,
        score=4, confidence=0.65,
        tags=["dashboard"],
        title_re=r"\b(dashboard|overview|control center)\b",
    ),
    IntelRule(
        name="title_swagger",
        description="Page title indicates Swagger/OpenAPI docs",
        category=RuleCategory.TITLE,
        score=6, confidence=0.90,
        tags=["api-docs", "swagger"],
        title_re=r"\b(swagger|api docs?|openapi|rapidoc|redoc)\b",
    ),
    IntelRule(
        name="title_prometheus",
        description="Page title indicates Prometheus metrics",
        category=RuleCategory.TITLE,
        score=7, confidence=0.92,
        tags=["monitoring", "prometheus", "high-value"],
        title_re=r"prometheus",
    ),
    IntelRule(
        name="title_500_error",
        description="Title is a server error page (information disclosure risk)",
        category=RuleCategory.TITLE,
        score=3, confidence=0.70,
        tags=["error-page", "info-disclosure"],
        title_re=r"\b(500|internal server error|application error|exception|stack trace)\b",
    ),

    # ===================================================================
    # TECHNOLOGY — from Phase 3 fingerprinting
    # ===================================================================

    IntelRule(
        name="tech_jenkins",
        description="Jenkins CI detected via fingerprinting",
        category=RuleCategory.TECHNOLOGY,
        score=10, confidence=0.95,
        tags=["ci-cd", "jenkins", "high-value"],
        tech_names=["Jenkins"],
    ),
    IntelRule(
        name="tech_grafana",
        description="Grafana monitoring detected via fingerprinting",
        category=RuleCategory.TECHNOLOGY,
        score=8, confidence=0.95,
        tags=["monitoring", "grafana", "high-value"],
        tech_names=["Grafana"],
    ),
    IntelRule(
        name="tech_jira",
        description="Jira detected via fingerprinting",
        category=RuleCategory.TECHNOLOGY,
        score=8, confidence=0.92,
        tags=["project-management", "jira", "high-value"],
        tech_names=["Jira"],
    ),
    IntelRule(
        name="tech_kibana",
        description="Kibana detected via fingerprinting",
        category=RuleCategory.TECHNOLOGY,
        score=8, confidence=0.95,
        tags=["monitoring", "kibana", "high-value"],
        tech_names=["Kibana"],
    ),
    IntelRule(
        name="tech_sonarqube",
        description="SonarQube detected via fingerprinting",
        category=RuleCategory.TECHNOLOGY,
        score=8, confidence=0.95,
        tags=["ci-cd", "sonarqube", "high-value"],
        tech_names=["SonarQube"],
    ),
    IntelRule(
        name="tech_phpmyadmin",
        description="phpMyAdmin detected via fingerprinting",
        category=RuleCategory.TECHNOLOGY,
        score=10, confidence=0.97,
        tags=["database", "admin-panel", "high-value"],
        tech_names=["phpMyAdmin"],
    ),
    IntelRule(
        name="tech_wordpress",
        description="WordPress CMS detected — common vulnerability surface",
        category=RuleCategory.TECHNOLOGY,
        score=4, confidence=0.88,
        tags=["cms", "wordpress"],
        tech_names=["WordPress"],
    ),
    IntelRule(
        name="tech_drupal",
        description="Drupal CMS detected",
        category=RuleCategory.TECHNOLOGY,
        score=4, confidence=0.88,
        tags=["cms", "drupal"],
        tech_names=["Drupal"],
    ),
    IntelRule(
        name="tech_gitlab",
        description="GitLab source control detected",
        category=RuleCategory.TECHNOLOGY,
        score=9, confidence=0.95,
        tags=["source-code", "gitlab", "high-value"],
        tech_names=["GitLab"],
    ),
    IntelRule(
        name="tech_spring_boot",
        description="Spring Boot app with potential actuator exposure",
        category=RuleCategory.TECHNOLOGY,
        score=5, confidence=0.85,
        tags=["java", "spring-boot", "actuator-risk"],
        tech_names=["Spring Boot"],
    ),
    IntelRule(
        name="tech_laravel",
        description="Laravel framework detected",
        category=RuleCategory.TECHNOLOGY,
        score=3, confidence=0.82,
        tags=["php", "laravel"],
        tech_names=["Laravel"],
    ),
    IntelRule(
        name="tech_django",
        description="Django framework detected",
        category=RuleCategory.TECHNOLOGY,
        score=3, confidence=0.82,
        tags=["python", "django"],
        tech_names=["Django"],
    ),
    IntelRule(
        name="tech_swagger_ui",
        description="Swagger UI detected — API documentation exposed",
        category=RuleCategory.TECHNOLOGY,
        score=6, confidence=0.90,
        tags=["api-docs", "swagger"],
        tech_names=["Swagger UI"],
    ),
    IntelRule(
        name="tech_graphql",
        description="GraphQL endpoint detected",
        category=RuleCategory.TECHNOLOGY,
        score=6, confidence=0.88,
        tags=["api", "graphql"],
        tech_names=["GraphQL"],
    ),

    # ===================================================================
    # HTTP BEHAVIOUR — status codes, login forms, open redirects
    # ===================================================================

    IntelRule(
        name="behavior_401",
        description="HTTP 401 Unauthorized — hidden auth-walled resource",
        category=RuleCategory.BEHAVIOR,
        score=6, confidence=0.85,
        tags=["auth-wall", "401"],
        status_codes=[401],
    ),
    IntelRule(
        name="behavior_403",
        description="HTTP 403 Forbidden — protected resource (may be bypassable)",
        category=RuleCategory.BEHAVIOR,
        score=5, confidence=0.78,
        tags=["forbidden", "403", "bypass-candidate"],
        status_codes=[403],
    ),
    IntelRule(
        name="behavior_login_form",
        description="Login form detected in HTML body",
        category=RuleCategory.BEHAVIOR,
        score=5, confidence=0.80,
        tags=["login-portal", "authentication"],
        has_login_form=True,
    ),
    IntelRule(
        name="behavior_open_redirect",
        description="Open redirect detected in redirect chain (external domain)",
        category=RuleCategory.BEHAVIOR,
        score=8, confidence=0.85,
        tags=["open-redirect", "high-value"],
        has_open_redirect=True,
    ),
    IntelRule(
        name="behavior_500",
        description="HTTP 500 — server error, may disclose stack traces",
        category=RuleCategory.BEHAVIOR,
        score=4, confidence=0.72,
        tags=["server-error", "info-disclosure"],
        status_codes=[500, 502, 503],
    ),
]


# ---------------------------------------------------------------------------
# Compile all rules at module import time
# ---------------------------------------------------------------------------

def get_compiled_rules() -> list[IntelRule]:
    return [r.compile() for r in INTEL_RULES]


COMPILED_RULES: list[IntelRule] = get_compiled_rules()
