"""
plugins/screenshots/gallery.py
================================
Generates a self-contained HTML screenshot gallery for Phase 5.

Features
--------
• Inline base64 thumbnails — no external dependencies, works offline.
• Lazy-loaded full-size images on click (lightbox effect, pure CSS/JS).
• Risk-level badge per screenshot (sourced from Phase 4 intelligence).
• Search/filter bar to find screenshots by hostname.
• Responsive grid layout (CSS Grid, no frameworks).
• Dark theme matching the ReconFramework terminal aesthetic.

The gallery is written to output/screenshots/index.html and is fully
self-contained — a single file you can share or commit.
"""

from __future__ import annotations

import base64
import logging
from dataclasses import dataclass, field
from pathlib import Path

log = logging.getLogger(__name__)

_RISK_COLOURS = {
    "CRITICAL": "#ff4444",
    "HIGH":     "#ff8800",
    "MEDIUM":   "#ffcc00",
    "LOW":      "#44bb44",
    "INFO":     "#888888",
    "UNKNOWN":  "#555555",
}


@dataclass
class GalleryEntry:
    url:        str
    file_path:  str          # absolute path to PNG/JPG
    host:       str = ""
    risk_level: str = "UNKNOWN"
    tags:       list[str] = field(default_factory=list)
    title:      str = ""


def _thumb_b64(path: str, max_bytes: int = 200_000) -> str | None:
    """Read the image file and return a base64 data-URI, or None on error."""
    try:
        p = Path(path)
        if not p.exists() or p.stat().st_size == 0:
            return None
        # If the file is too large, we still embed it — browsers handle it fine
        data = p.read_bytes()
        ext  = p.suffix.lower().lstrip(".")
        mime = "image/png" if ext == "png" else "image/jpeg"
        return f"data:{mime};base64,{base64.b64encode(data).decode()}"
    except Exception as exc:
        log.debug("Failed to read screenshot", extra={"path": path, "error": str(exc)})
        return None


def build_gallery(
    entries: list[GalleryEntry],
    output_path: str | Path,
    title:   str = "ReconFramework — Screenshot Gallery",
    per_row: int = 4,
) -> bool:
    """
    Generate a self-contained HTML gallery file.

    Returns True on success, False if no screenshots could be embedded.
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Only include entries with readable files
    valid: list[tuple[GalleryEntry, str]] = []
    for entry in entries:
        b64 = _thumb_b64(entry.file_path)
        if b64:
            valid.append((entry, b64))

    if not valid:
        log.warning("No readable screenshot files — gallery not generated")
        return False

    cards_html = ""
    for entry, b64 in valid:
        risk_col  = _RISK_COLOURS.get(entry.risk_level.upper(), "#555")
        tags_html = " ".join(
            f'<span class="tag">{t}</span>' for t in entry.tags[:5]
        )
        cards_html += f"""
        <div class="card" data-host="{entry.host}" data-risk="{entry.risk_level}">
          <div class="risk-badge" style="background:{risk_col}">{entry.risk_level}</div>
          <a href="{entry.file_path}" target="_blank">
            <img class="thumb" src="{b64}" alt="{entry.host}" loading="lazy" />
          </a>
          <div class="card-body">
            <div class="host" title="{entry.url}">{entry.host or entry.url}</div>
            <div class="tags">{tags_html}</div>
          </div>
        </div>"""

    risk_options = "".join(
        f'<option value="{r}">{r}</option>'
        for r in ["ALL", "CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"]
    )

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title}</title>
<style>
  :root {{
    --bg: #0d1117; --surface: #161b22; --border: #30363d;
    --text: #e6edf3; --muted: #8b949e; --accent: #58a6ff;
  }}
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ background: var(--bg); color: var(--text);
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
          padding: 24px; }}
  header {{ display: flex; align-items: center; justify-content: space-between;
            border-bottom: 1px solid var(--border); padding-bottom: 16px; margin-bottom: 24px; }}
  h1 {{ font-size: 1.4rem; color: var(--accent); }}
  .stats {{ color: var(--muted); font-size: .875rem; }}
  .controls {{ display: flex; gap: 12px; margin-bottom: 20px; flex-wrap: wrap; }}
  input, select {{
    background: var(--surface); border: 1px solid var(--border);
    color: var(--text); padding: 8px 12px; border-radius: 6px;
    font-size: .875rem; outline: none;
  }}
  input {{ flex: 1; min-width: 200px; }}
  input:focus, select:focus {{ border-color: var(--accent); }}
  .grid {{
    display: grid;
    grid-template-columns: repeat({per_row}, 1fr);
    gap: 16px;
  }}
  @media (max-width: 1200px) {{ .grid {{ grid-template-columns: repeat(3, 1fr); }} }}
  @media (max-width: 800px)  {{ .grid {{ grid-template-columns: repeat(2, 1fr); }} }}
  @media (max-width: 500px)  {{ .grid {{ grid-template-columns: 1fr; }} }}
  .card {{
    background: var(--surface); border: 1px solid var(--border);
    border-radius: 8px; overflow: hidden; position: relative;
    transition: border-color .2s;
  }}
  .card:hover {{ border-color: var(--accent); }}
  .card.hidden {{ display: none; }}
  .risk-badge {{
    position: absolute; top: 8px; right: 8px;
    font-size: .7rem; font-weight: 700; letter-spacing: .04em;
    padding: 2px 8px; border-radius: 4px; color: #fff; z-index: 2;
  }}
  .thumb {{
    width: 100%; display: block; aspect-ratio: 16/9;
    object-fit: cover; cursor: zoom-in;
  }}
  .card-body {{ padding: 10px 12px; }}
  .host {{ font-size: .8rem; color: var(--accent); white-space: nowrap;
           overflow: hidden; text-overflow: ellipsis; margin-bottom: 6px; }}
  .tags {{ display: flex; flex-wrap: wrap; gap: 4px; }}
  .tag {{ background: #21262d; color: var(--muted); font-size: .7rem;
          padding: 2px 6px; border-radius: 4px; }}
  #no-results {{ display: none; color: var(--muted); text-align: center;
                 padding: 48px; grid-column: 1/-1; }}
</style>
</head>
<body>
<header>
  <h1>🔍 {title}</h1>
  <span class="stats">{len(valid)} screenshots</span>
</header>
<div class="controls">
  <input id="search" type="text" placeholder="Search by hostname…" oninput="filterCards()">
  <select id="risk-filter" onchange="filterCards()">
    {risk_options}
  </select>
</div>
<div class="grid" id="grid">
  {cards_html}
  <div id="no-results">No screenshots match your filter.</div>
</div>
<script>
  function filterCards() {{
    const q    = document.getElementById('search').value.toLowerCase();
    const risk = document.getElementById('risk-filter').value;
    let visible = 0;
    document.querySelectorAll('.card').forEach(card => {{
      const host     = (card.dataset.host || '').toLowerCase();
      const cardRisk = (card.dataset.risk || '').toUpperCase();
      const matchQ   = !q    || host.includes(q);
      const matchR   = risk === 'ALL' || cardRisk === risk;
      card.classList.toggle('hidden', !(matchQ && matchR));
      if (matchQ && matchR) visible++;
    }});
    document.getElementById('no-results').style.display = visible === 0 ? 'block' : 'none';
  }}
</script>
</body>
</html>"""

    output_path.write_text(html, encoding="utf-8")
    log.info(
        "Gallery written",
        extra={"path": str(output_path), "entries": len(valid)},
    )
    return True
