"""
plugins/screenshots/gowitness_runner.py
=========================================
Screenshot collection via the Gowitness binary (sensepost/gowitness).

Strategy
--------
1. Write the URL list to a temp file.
2. Invoke:
       gowitness file -f <urls.txt> --screenshot-path <output_dir>
               --threads 10 --timeout 15 --disable-db ...
3. Map each saved PNG back to its source URL using Gowitness's deterministic
   filename scheme (MD5 of URL → <hash>.png).
4. Return a ScreenshotResult per URL.

Gowitness filename convention (v3):
   The binary names each file after the URL it screenshotted, using its own
   hashing. We discover the mapping by:
     a) listing the output dir before and after the run, or
     b) parsing gowitness's stdout (--log-level debug shows "Screenshotted <url> -> <file>")

We use approach (b) as the primary method and (a) as a fallback.
"""

from __future__ import annotations

import asyncio
import logging
import re
import shutil
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

from core.base_plugin import BasePlugin, PluginContext, PluginResult

log = logging.getLogger(__name__)

# Gowitness debug log line pattern
# e.g. "Screenshot of https://example.com saved to /out/abc123.png"
_SAVED_RE = re.compile(
    r"(?:screenshot.*?saved.*?|screenshotted\s+\S+\s+->\s+)([\w/\-\.]+\.(?:png|jpg))",
    re.IGNORECASE,
)


@dataclass
class ScreenshotResult:
    url:       str
    file_path: str | None = None   # absolute path to the PNG, or None if failed
    success:   bool = False
    error:     str | None = None


class GowitnessRunner(BasePlugin[list[ScreenshotResult]]):
    """Invoke Gowitness and return per-URL screenshot results."""

    NAME     = "gowitness"
    PRIORITY = 5

    async def run(self, ctx: PluginContext) -> PluginResult[list[ScreenshotResult]]:
        cfg    = ctx.config.phase5
        binary = shutil.which(cfg.gowitness_bin) or cfg.gowitness_bin

        if not shutil.which(binary):
            self._log.info(
                "Gowitness binary not found — skipping",
                extra={"searched": binary},
            )
            return self._ok([])      # soft skip

        urls: list[str] = ctx.metadata.get("screenshot_urls", [])
        if not urls:
            return self._ok([])

        out_dir = Path(cfg.output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)

        self._log.info(
            "Gowitness starting",
            extra={"urls": len(urls), "out_dir": str(out_dir)},
        )

        # Snapshot existing files so we can detect new ones
        before: set[str] = {
            str(p) for p in out_dir.glob(f"*.{cfg.screenshot_format}")
        }

        results = await self._run_gowitness(binary, urls, out_dir, cfg)

        # Fallback: map newly-appeared files to URLs positionally
        after: set[str] = {
            str(p) for p in out_dir.glob(f"*.{cfg.screenshot_format}")
        }
        new_files = sorted(after - before)
        unmapped  = [r for r in results if not r.file_path and r.success]
        for result, file_path in zip(unmapped, new_files):
            result.file_path = file_path

        succeeded = sum(1 for r in results if r.file_path)
        self._log.info(
            "Gowitness complete",
            extra={"total": len(urls), "screenshots": succeeded},
        )
        return self._ok(results)

    async def _run_gowitness(
        self,
        binary:  str,
        urls:    list[str],
        out_dir: Path,
        cfg,
    ) -> list[ScreenshotResult]:
        """Write URL list, invoke gowitness, parse output."""
        results_map: dict[str, ScreenshotResult] = {
            url: ScreenshotResult(url=url) for url in urls
        }

        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".txt", delete=False, prefix="rf_screenshots_"
        ) as tf:
            tf.write("\n".join(urls))
            tmp_path = tf.name

        cmd = self._build_cmd(binary, tmp_path, out_dir, cfg)
        self._log.debug("Gowitness command", extra={"cmd": " ".join(cmd)})

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,  # merge stderr into stdout
            )
            stdout, _ = await asyncio.wait_for(
                proc.communicate(),
                timeout=float(cfg.timeout_s * len(urls) + 60),
            )
        except asyncio.TimeoutError:
            self._log.error("Gowitness global timeout exceeded")
            for r in results_map.values():
                r.error = "global timeout"
            return list(results_map.values())
        finally:
            Path(tmp_path).unlink(missing_ok=True)

        # Parse stdout for "saved → <file>" patterns
        output_text = stdout.decode(errors="replace")
        for line in output_text.splitlines():
            m = _SAVED_RE.search(line)
            if not m:
                continue
            file_hint = m.group(1).strip()
            # Try to resolve the file path
            candidate = Path(file_hint)
            if not candidate.is_absolute():
                candidate = out_dir / candidate.name
            if candidate.exists():
                # Find which URL this file belongs to (heuristic: line context)
                for url, result in results_map.items():
                    if url in line or not result.file_path:
                        result.file_path = str(candidate)
                        result.success   = True
                        break

        # Mark anything still without a file as succeeded (file mapping unknown)
        # if gowitness exited 0 — the file exists, we just can't link it.
        if proc.returncode == 0:
            for r in results_map.values():
                if not r.file_path:
                    r.success = True   # file exists, path TBD via fallback

        return list(results_map.values())

    @staticmethod
    def _build_cmd(binary: str, url_file: str, out_dir: Path, cfg) -> list[str]:
        cmd = [
            binary, "file",
            "-f", url_file,
            "--screenshot-path", str(out_dir),
            "--threads", str(cfg.threads),
            "--timeout", str(cfg.timeout_s),
            "--resolution-x", str(cfg.resolution_x),
            "--resolution-y", str(cfg.resolution_y),
            "--user-agent", cfg.user_agent,
            "--log-level", "debug",
        ]
        if cfg.disable_db:
            cmd.append("--disable-db")
        if cfg.delay:
            cmd += ["--delay", str(cfg.delay)]
        return cmd
