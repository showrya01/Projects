"""
plugins/screenshots/__init__.py
==================================
Phase 5 — Screenshot Collection plugin package.
"""

from plugins.screenshots.gallery import GalleryEntry, build_gallery
from plugins.screenshots.gowitness_runner import GowitnessRunner, ScreenshotResult

__all__ = [
    "GowitnessRunner",
    "ScreenshotResult",
    "GalleryEntry",
    "build_gallery",
]
