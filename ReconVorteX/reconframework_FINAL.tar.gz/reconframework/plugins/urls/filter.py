"""
plugins/urls/filter.py
========================
Smart URL filter for Phase 6.

Keeps a URL if ANY of these conditions is true:
  1. Its file extension is in the interesting_extensions list.
  2. It carries a parameter name in the interesting_params list.
  3. It is a bare path with no extension and no params but
     contains a security-relevant path segment (api/, admin/, etc.)

Also handles:
  • Deduplication (exact URL + normalised URL).
  • Exclusion of third-party domains.
  • Optional cap on total URLs returned.
"""

from __future__ import annotations

import re
from urllib.parse import parse_qs, urlparse

from core.config import Phase6Config


# Path segments that make an extensionless URL interesting
_INTERESTING_SEGMENTS: frozenset[str] = frozenset([
    "api", "admin", "login", "auth", "oauth", "graphql", "swagger",
    "actuator", "console", "dashboard", "panel", "portal", "manage",
    "management", "config", "setup", "install", "debug", "trace",
    "metrics", "health", "status", "backup", "upload", "download",
    "export", "import", "internal", "private", "secret", "token",
    "key", "password", "credential", "jenkins", "git", "repo",
])

# Strip common noise parameters before dedup-normalisation
_NOISE_PARAMS: frozenset[str] = frozenset([
    "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
    "fbclid", "gclid", "_ga", "ref", "referrer",
])


def _normalise(url: str) -> str:
    """Normalise a URL for deduplication (lowercase scheme+host+path, sorted params)."""
    try:
        p = urlparse(url.strip())
        qs = parse_qs(p.query, keep_blank_values=False)
        # Remove noise params
        qs = {k: v for k, v in qs.items() if k.lower() not in _NOISE_PARAMS}
        # Sort params for canonical form
        norm_qs = "&".join(f"{k}={v[0]}" for k, v in sorted(qs.items()))
        return f"{p.scheme.lower()}://{p.netloc.lower()}{p.path.lower()}"
        # Note: we intentionally ignore the query string in dedup so that
        # ?id=1 and ?id=2 collapse to one representative URL.
    except Exception:
        return url.lower()


def _has_interesting_extension(path: str, extensions: list[str]) -> bool:
    path_lower = path.lower().split("?")[0]
    return any(path_lower.endswith(ext) for ext in extensions)


def _has_interesting_param(url: str, params: list[str]) -> bool:
    try:
        qs = parse_qs(urlparse(url).query, keep_blank_values=False)
        param_names = {k.lower() for k in qs}
        return bool(param_names & {p.lower() for p in params})
    except Exception:
        return False


def _has_interesting_segment(path: str) -> bool:
    segments = {s.lower().strip("/") for s in path.split("/")}
    return bool(segments & _INTERESTING_SEGMENTS)


def _is_excluded(url: str, exclude_patterns: list[str]) -> bool:
    url_lower = url.lower()
    return any(pat.lower() in url_lower for pat in exclude_patterns)


class URLFilter:
    """
    Stateful filter / deduplicator.

    Call filter_batch() with each source's URL list; it returns only
    the new URLs that passed the smart filter and haven't been seen yet.
    """

    def __init__(self, cfg: Phase6Config) -> None:
        self._cfg      = cfg
        self._seen_norm: set[str] = set()    # normalised URLs (dedup key)
        self._seen_raw:  set[str] = set()    # exact raw URLs

    # ------------------------------------------------------------------
    # Public
    # ------------------------------------------------------------------

    def filter_batch(self, urls: list[str]) -> list[str]:
        """
        Filter and deduplicate a batch of URLs.

        Returns the subset that:
          • is not excluded by exclude_patterns
          • passes at least one interest criterion
          • has not been seen before (by normalised form)
        """
        accepted: list[str] = []
        for url in urls:
            url = url.strip()
            if not url or not url.startswith("http"):
                continue
            if _is_excluded(url, self._cfg.exclude_patterns):
                continue
            if not self._is_interesting(url):
                continue
            norm = _normalise(url)
            if norm in self._seen_norm:
                continue
            self._seen_norm.add(norm)
            self._seen_raw.add(url)
            accepted.append(url)
        return accepted

    def total_seen(self) -> int:
        return len(self._seen_raw)

    # ------------------------------------------------------------------
    # Private
    # ------------------------------------------------------------------

    def _is_interesting(self, url: str) -> bool:
        path = urlparse(url).path
        return (
            _has_interesting_extension(path, self._cfg.interesting_extensions)
            or _has_interesting_param(url, self._cfg.interesting_params)
            or _has_interesting_segment(path)
        )
