"""
plugins/urls/commoncrawl_collector.py
=========================================
Historical URL collection via the Common Crawl Index API.

Common Crawl publishes dozens of monthly crawl indexes. This plugin:
  1. Fetches the list of available indexes from collinfo.json.
  2. Picks the N most recent ones (cfg.cc_max_indexes, default 3).
  3. Queries the CC Index API for each index in parallel.
  4. Returns deduplicated URLs across all indexes.

CC Index API docs: https://index.commoncrawl.org/

Rate limits: CC is a public service — keep concurrency low (≤ 3).
"""

from __future__ import annotations

import asyncio
import json
import logging

import aiohttp
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from core.base_plugin import BasePlugin, PluginContext, PluginResult

log = logging.getLogger(__name__)

_CC_SEARCH_URL = "https://index.commoncrawl.org/{index}-index"


class CommonCrawlCollector(BasePlugin[list[str]]):
    """Fetch URLs from the Common Crawl public index API."""

    NAME     = "commoncrawl"
    PRIORITY = 15

    async def run(self, ctx: PluginContext) -> PluginResult[list[str]]:
        cfg    = ctx.config.phase6
        domain = ctx.domain

        self._log.info("Common Crawl query starting", extra={"domain": domain})

        try:
            # Step 1: get available index names
            indexes = await self._get_indexes(cfg)
            if not indexes:
                self._log.warning("No CC indexes found")
                return self._ok([])

            self._log.debug(
                "CC indexes selected",
                extra={"indexes": indexes},
            )

            # Step 2: query each index concurrently (low parallelism)
            sem  = asyncio.Semaphore(3)
            timeout = aiohttp.ClientTimeout(total=cfg.http_timeout * 2)

            async with aiohttp.ClientSession(timeout=timeout) as session:
                tasks = [
                    self._query_index(session, idx, domain, sem)
                    for idx in indexes
                ]
                batches = await asyncio.gather(*tasks, return_exceptions=True)

        except Exception as exc:
            ctx.record_error(self.NAME, f"Common Crawl failed: {exc}", exc)
            return self._fail(str(exc))

        # Merge and deduplicate across indexes
        seen:  set[str] = set()
        urls:  list[str] = []
        for batch in batches:
            if isinstance(batch, Exception):
                self._log.warning(
                    "CC index query failed",
                    extra={"error": str(batch)},
                )
                continue
            for url in batch:
                if url not in seen:
                    seen.add(url)
                    urls.append(url)

        self._log.info(
            "Common Crawl complete",
            extra={"domain": domain, "urls": len(urls)},
        )
        return self._ok(urls)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(min=2, max=8),
        retry=retry_if_exception_type((aiohttp.ClientError, asyncio.TimeoutError)),
        reraise=True,
    )
    async def _get_indexes(self, cfg) -> list[str]:
        """Return the N most recent CC index IDs (e.g. 'CC-MAIN-2024-10')."""
        timeout = aiohttp.ClientTimeout(total=cfg.http_timeout)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(cfg.cc_index_url, ssl=False) as resp:
                resp.raise_for_status()
                data = await resp.json(content_type=None)

        # data is a list of dicts with "id" and "name" keys, newest first
        ids = [entry["id"] for entry in data if "id" in entry]
        return ids[: cfg.cc_max_indexes]

    async def _query_index(
        self,
        session:  aiohttp.ClientSession,
        index_id: str,
        domain:   str,
        sem:      asyncio.Semaphore,
    ) -> list[str]:
        """Query one CC index for all URLs under *.domain."""
        url     = _CC_SEARCH_URL.format(index=index_id)
        params  = {
            "url":    f"*.{domain}",
            "output": "json",
            "fl":     "url",
            "limit":  "100000",
        }
        urls: list[str] = []

        async with sem:
            try:
                async with session.get(url, params=params, ssl=False) as resp:
                    if resp.status in (404, 400):
                        # Domain not in this index — not an error
                        return []
                    resp.raise_for_status()

                    # CC returns one JSON object per line
                    async for raw_line in resp.content:
                        line = raw_line.decode(errors="replace").strip()
                        if not line:
                            continue
                        try:
                            obj = json.loads(line)
                            if raw_url := obj.get("url"):
                                if raw_url.startswith("http"):
                                    urls.append(raw_url)
                        except json.JSONDecodeError:
                            # Occasional malformed lines — skip
                            continue
            except (aiohttp.ClientError, asyncio.TimeoutError) as exc:
                self._log.debug(
                    "CC index request failed",
                    extra={"index": index_id, "error": str(exc)},
                )
                return []

        return urls
