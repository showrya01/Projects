"""
plugins/urls/wayback_collector.py
====================================
Historical URL collection via the Wayback Machine CDX API.

Endpoint: https://web.archive.org/cdx/search/cdx
Docs:     https://github.com/internetarchive/wayback-cdx-server

Strategy
--------
1. Query CDX with output=text, fl=original, collapse=urlkey.
   collapse=urlkey means one URL per unique path — avoids millions of
   timestamped duplicates for the same endpoint.
2. Stream the response line-by-line so memory stays bounded even for
   large targets.
3. Retry up to 3× on transient failures with exponential back-off.
"""

from __future__ import annotations

import asyncio
import logging

import aiohttp
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from core.base_plugin import BasePlugin, PluginContext, PluginResult

log = logging.getLogger(__name__)


class WaybackCollector(BasePlugin[list[str]]):
    """Fetch URLs from the Wayback Machine CDX API."""

    NAME     = "wayback"
    PRIORITY = 10

    async def run(self, ctx: PluginContext) -> PluginResult[list[str]]:
        cfg    = ctx.config.phase6
        domain = ctx.domain

        self._log.info("Wayback CDX query starting", extra={"domain": domain})

        try:
            urls = await self._fetch(domain, cfg)
        except Exception as exc:
            ctx.record_error(self.NAME, f"Wayback failed: {exc}", exc)
            return self._fail(str(exc))

        self._log.info(
            "Wayback complete",
            extra={"domain": domain, "urls": len(urls)},
        )
        return self._ok(urls)

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(min=2, max=10),
        retry=retry_if_exception_type((aiohttp.ClientError, asyncio.TimeoutError)),
        reraise=True,
    )
    async def _fetch(self, domain: str, cfg) -> list[str]:
        params = {
            "url":      f"*.{domain}",
            "output":   "text",
            "fl":       "original",
            "collapse": "urlkey",       # one entry per unique path
            "limit":    str(cfg.wayback_limit),
            "filter":   "statuscode:200",  # live pages only
        }

        timeout = aiohttp.ClientTimeout(total=cfg.http_timeout * 2)
        urls: list[str] = []

        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(
                cfg.wayback_cdx_url,
                params=params,
                ssl=False,
            ) as resp:
                if resp.status == 429:
                    raise aiohttp.ClientResponseError(
                        resp.request_info, resp.history,
                        status=429, message="Rate limited by Wayback CDX",
                    )
                resp.raise_for_status()

                # Stream lines — avoids loading multi-MB body into memory at once
                async for raw_line in resp.content:
                    line = raw_line.decode(errors="replace").strip()
                    if line.startswith("http"):
                        urls.append(line)

        return urls
