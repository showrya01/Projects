"""
plugins/urls/__init__.py
==========================
Phase 6 — Historical URL Collection plugin package.

Source priority order (highest to lowest):
  1. GAU binary    — fastest, covers Wayback + CC + OTX + URLScan
  2. Wayback CDX   — authoritative archive, fine-grained control
  3. Common Crawl  — independent crawl data, good coverage

All three are always attempted; GAU missing just means less data,
not an error.
"""

from plugins.urls.commoncrawl_collector import CommonCrawlCollector
from plugins.urls.filter import URLFilter
from plugins.urls.gau_collector import GauCollector
from plugins.urls.wayback_collector import WaybackCollector

ALL_COLLECTORS = [GauCollector, WaybackCollector, CommonCrawlCollector]

__all__ = [
    "GauCollector",
    "WaybackCollector",
    "CommonCrawlCollector",
    "URLFilter",
    "ALL_COLLECTORS",
]
