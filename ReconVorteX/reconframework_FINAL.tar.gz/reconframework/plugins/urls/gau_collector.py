"""
plugins/urls/gau_collector.py
================================
Historical URL collection via the GAU binary (lc0/gau).

GAU (Get All URLs) fetches from:
  • Wayback Machine
  • Common Crawl
  • OTX AlienVault
  • URLScan

All sources are queried in a single binary call — fast and reliable.
Falls back gracefully if the binary is not in PATH.
"""

from __future__ import annotations

import asyncio
import logging
import shutil
from pathlib import Path

from core.base_plugin import BasePlugin, PluginContext, PluginResult

log = logging.getLogger(__name__)


class GauCollector(BasePlugin[list[str]]):
    """Invoke the GAU binary and return every URL it emits."""

    NAME     = "gau"
    PRIORITY = 5    # Try first — fastest when available

    async def run(self, ctx: PluginContext) -> PluginResult[list[str]]:
        cfg    = ctx.config.phase6
        binary = shutil.which(cfg.gau_bin) or cfg.gau_bin

        if not shutil.which(binary):
            self._log.info(
                "GAU binary not found — skipping",
                extra={"searched": binary},
            )
            return self._ok([])          # soft skip, not an error

        domain = ctx.domain
        self._log.info("GAU starting", extra={"domain": domain, "binary": binary})

        try:
            urls = await self._run_gau(binary, domain, cfg.tool_timeout)
        except Exception as exc:
            ctx.record_error(self.NAME, f"GAU failed: {exc}", exc)
            return self._fail(str(exc))

        self._log.info("GAU complete", extra={"domain": domain, "urls": len(urls)})
        return self._ok(urls)

    async def _run_gau(self, binary: str, domain: str, timeout: int) -> list[str]:
        cmd = [
            binary,
            "--threads", "5",
            "--retries", "2",
            "--timeout", str(timeout),
            domain,
        ]
        self._log.debug("GAU command", extra={"cmd": " ".join(cmd)})

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(),
                timeout=float(timeout),
            )
        except asyncio.TimeoutError:
            proc.kill()
            raise TimeoutError(f"GAU timed out after {timeout}s")

        if stderr:
            self._log.debug(
                "GAU stderr",
                extra={"snippet": stderr.decode(errors="replace")[:300]},
            )

        return [
            line.strip()
            for line in stdout.decode(errors="replace").splitlines()
            if line.strip().startswith("http")
        ]
