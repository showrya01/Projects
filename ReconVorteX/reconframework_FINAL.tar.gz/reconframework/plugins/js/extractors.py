"""
plugins/js/extractors.py
==========================
JavaScript intelligence extraction engine for Phase 8.

Extraction methods
------------------
1. **Regex patterns** — fast, handles minified JS, covers all finding types.
2. **AST-like structural analysis** — uses Python's ``ast`` module conceptually:
   tokenises JS assignment and object-literal patterns to identify variable
   names associated with sensitive values, avoiding the false-positive
   explosion of purely positional regex.
3. **Shannon entropy scoring** — any quoted string >= threshold is flagged
   as a potential secret regardless of context.

Finding types extracted
-----------------------
  endpoint          — /api/, /v1/, fetch(), axios(), XHR calls
  api_route         — Express router.get/post, route definitions
  api_key           — Generic API key patterns
  aws_key           — AWS Access Key IDs and Secret Access Keys
  aws_s3            — S3 bucket references
  graphql           — query/mutation definitions, GraphQL endpoint URLs
  internal_url      — Absolute URLs pointing to internal/RFC-1918 addresses
  jwt               — JWT tokens (eyJ…), signing key refs
  credential        — Username/password pairs, hardcoded auth
  source_map        — //# sourceMappingURL= directives
  commented_code    — Suspicious commented-out endpoints / credentials
  package_ref       — require() / import declarations
  secret_entropy    — High-entropy strings (possible secrets)
  secret_assignment — Variable assignments with sensitive names

Output: list[JSFinding] per analysed file.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from urllib.parse import urlparse

from plugins.js.entropy import find_high_entropy_strings, find_secret_assignments

# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class JSFinding:
    js_url:       str
    finding_type: str    # one of the types listed above
    value:        str    # the extracted value
    context:      str | None = None    # surrounding code snippet (≤120 chars)
    confidence:   float = 0.8          # 0.0–1.0


# ---------------------------------------------------------------------------
# Regex catalogue — applied to full JS source
# ---------------------------------------------------------------------------

# URL-like path patterns in JS strings
_ENDPOINT_RE = re.compile(
    r"""['"`](/(?:api|v\d+|rest|service|endpoint|rpc|gql|graphql|admin|auth|oauth|user|account|order|product|payment|upload|download|webhook|callback|internal|private|proxy)"""
    r"""(?:/[\w\-\.{}$:]+)*/?)[`'"]""",
    re.IGNORECASE,
)

# fetch() and axios() calls
_FETCH_RE = re.compile(
    r"""(?:fetch|axios(?:\.\w+)?|http\.(?:get|post|put|delete|patch))\s*\(\s*[`'"]([^`'"]{5,200})[`'"]""",
    re.IGNORECASE,
)

# XMLHttpRequest .open() calls
_XHR_RE = re.compile(
    r"""\.open\s*\(\s*['"`]\w+['"`]\s*,\s*['"`]([^'"`]{5,200})['"`]""",
    re.IGNORECASE,
)

# Express / framework router definitions
_ROUTE_RE = re.compile(
    r"""(?:router|app)\s*\.\s*(?:get|post|put|delete|patch|all|use)\s*\(\s*['"`]([^'"`]{1,200})['"`]""",
    re.IGNORECASE,
)

# Generic API key patterns (common formats)
_API_KEY_RE = re.compile(
    r"""[`'"]([A-Za-z0-9_\-]{20,60})[`'"]\s*"""
    r"""(?:#.*)?(?://.*)?$""",
    re.MULTILINE,
)

# AWS Access Key ID (starts with AKIA/ASIA/AROA/AIDA/ANPA/AIPA/AKID)
_AWS_KEY_RE = re.compile(
    r"""\b((?:AKIA|ASIA|AROA|AIDA|ANPA|AIPA|AKID)[A-Z0-9]{16})\b"""
)

# AWS Secret Access Key (40 chars, base64-ish)
_AWS_SECRET_RE = re.compile(
    r"""[`'"]([A-Za-z0-9/+=]{40})[`'"]"""
)

# S3 bucket references
_S3_RE = re.compile(
    r"""(?:s3://|s3\.amazonaws\.com/|\.s3\.)([a-z0-9.\-]{3,63})""",
    re.IGNORECASE,
)

# GraphQL query / mutation definitions
_GQL_QUERY_RE = re.compile(
    r"""\b(query|mutation|subscription)\s+(\w+)\s*[({]""",
    re.IGNORECASE,
)

# Internal/RFC-1918 absolute URLs
_INTERNAL_URL_RE = re.compile(
    r"""['"`](https?://(?:localhost|127\.0\.0\.\d+|192\.168\.\d+\.\d+|10\.\d+\.\d+\.\d+|172\.(?:1[6-9]|2\d|3[01])\.\d+\.\d+|\d+\.\d+\.\d+\.\d+)(?::\d{1,5})?(?:/[^\s'"`]*)?)['"`]""",
    re.IGNORECASE,
)

# JWT token pattern (three base64url segments separated by dots)
_JWT_RE = re.compile(
    r"""['"`](eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]*)['"`]"""
)

# Source map directives
_SOURCE_MAP_RE = re.compile(
    r"""//[#@]\s*sourceMappingURL\s*=\s*(\S+)"""
)

# Commented-out lines with sensitive patterns
_COMMENT_SECRET_RE = re.compile(
    r"""//[^\n]*(password|api[_-]?key|secret|token|auth|credential)[^\n]*""",
    re.IGNORECASE,
)

# require() / import() calls — dynamic imports and CJS require
_REQUIRE_RE = re.compile(
    r"""(?:require|import)\s*\(?['"`]([^'"`]+)['"`]\)?""",
    re.IGNORECASE,
)

# ES6 static import: import x from "pkg" | import { x } from "pkg" | import "pkg"
_ES6_IMPORT_RE = re.compile(
    r"""import\s+(?:[\w{},\s*]+\s+from\s+)?['"`]([^'"`./][^'"`]*)['"`]""",
    re.IGNORECASE,
)

# Hardcoded credential patterns (user + pass together)
_CRED_RE = re.compile(
    r"""(?:username|user|login|email)\s*[=:]\s*['"`]([^'"`]{3,80})['"`]"""
    r"""[^'"`]{0,200}"""
    r"""(?:password|passwd|pwd|pass)\s*[=:]\s*['"`]([^'"`]{3,80})['"`]""",
    re.IGNORECASE | re.DOTALL,
)


# ---------------------------------------------------------------------------
# AST-like structural context extractor
# ---------------------------------------------------------------------------

def _extract_context(source: str, match: re.Match, window: int = 60) -> str:
    """Return a ≤(2×window) char snippet around the match."""
    s = max(0, match.start() - window)
    e = min(len(source), match.end() + window)
    return source[s:e].replace("\n", " ").strip()[:240]


def _dedupe(findings: list[JSFinding]) -> list[JSFinding]:
    """Deduplicate on (finding_type, value) keeping highest confidence."""
    best: dict[tuple[str, str], JSFinding] = {}
    for f in findings:
        key = (f.finding_type, f.value)
        if key not in best or f.confidence > best[key].confidence:
            best[key] = f
    return sorted(best.values(), key=lambda f: (-f.confidence, f.finding_type))


# ---------------------------------------------------------------------------
# Main extractor
# ---------------------------------------------------------------------------

class JSExtractor:
    """
    Stateless JS extraction engine.

    Call extract(js_url, source_code) → list[JSFinding].
    """

    def __init__(self, entropy_threshold: float = 4.5,
                 min_len: int = 20, max_len: int = 200) -> None:
        self._entropy_threshold = entropy_threshold
        self._min_len = min_len
        self._max_len = max_len

    def extract(self, js_url: str, source: str) -> list[JSFinding]:
        """Run all extractors and return deduplicated findings."""
        if not source or not source.strip():
            return []

        findings: list[JSFinding] = []
        findings += self._endpoints(js_url, source)
        findings += self._api_routes(js_url, source)
        findings += self._aws_keys(js_url, source)
        findings += self._graphql(js_url, source)
        findings += self._internal_urls(js_url, source)
        findings += self._jwt_tokens(js_url, source)
        findings += self._source_maps(js_url, source)
        findings += self._commented_secrets(js_url, source)
        findings += self._package_refs(js_url, source)
        findings += self._credentials(js_url, source)
        findings += self._entropy_secrets(js_url, source)
        findings += self._assignment_secrets(js_url, source)

        return _dedupe(findings)

    # ------------------------------------------------------------------
    # Extractors
    # ------------------------------------------------------------------

    def _endpoints(self, url: str, src: str) -> list[JSFinding]:
        out = []
        for pattern, conf in [
            (_ENDPOINT_RE, 0.85),
            (_FETCH_RE,    0.90),
            (_XHR_RE,      0.88),
        ]:
            for m in pattern.finditer(src):
                val = m.group(1).strip()
                if len(val) < 3 or val.startswith("//"):
                    continue
                out.append(JSFinding(
                    js_url=url, finding_type="endpoint",
                    value=val, context=_extract_context(src, m),
                    confidence=conf,
                ))
        return out

    def _api_routes(self, url: str, src: str) -> list[JSFinding]:
        return [
            JSFinding(
                js_url=url, finding_type="api_route",
                value=m.group(1).strip(),
                context=_extract_context(src, m),
                confidence=0.88,
            )
            for m in _ROUTE_RE.finditer(src)
            if len(m.group(1).strip()) >= 1
        ]

    def _aws_keys(self, url: str, src: str) -> list[JSFinding]:
        out = []
        for m in _AWS_KEY_RE.finditer(src):
            out.append(JSFinding(
                js_url=url, finding_type="aws_key",
                value=m.group(1),
                context=_extract_context(src, m),
                confidence=0.95,
            ))
        for m in _S3_RE.finditer(src):
            out.append(JSFinding(
                js_url=url, finding_type="aws_s3",
                value=m.group(0).strip(),
                context=_extract_context(src, m),
                confidence=0.88,
            ))
        return out

    def _graphql(self, url: str, src: str) -> list[JSFinding]:
        out = []
        for m in _GQL_QUERY_RE.finditer(src):
            op_type = m.group(1)
            op_name = m.group(2)
            out.append(JSFinding(
                js_url=url, finding_type="graphql",
                value=f"{op_type} {op_name}",
                context=_extract_context(src, m),
                confidence=0.90,
            ))
        return out

    def _internal_urls(self, url: str, src: str) -> list[JSFinding]:
        return [
            JSFinding(
                js_url=url, finding_type="internal_url",
                value=m.group(1).strip(),
                context=_extract_context(src, m),
                confidence=0.92,
            )
            for m in _INTERNAL_URL_RE.finditer(src)
        ]

    def _jwt_tokens(self, url: str, src: str) -> list[JSFinding]:
        return [
            JSFinding(
                js_url=url, finding_type="jwt",
                value=m.group(1)[:80] + ("…" if len(m.group(1)) > 80 else ""),
                context=_extract_context(src, m),
                confidence=0.95,
            )
            for m in _JWT_RE.finditer(src)
        ]

    def _source_maps(self, url: str, src: str) -> list[JSFinding]:
        return [
            JSFinding(
                js_url=url, finding_type="source_map",
                value=m.group(1).strip(),
                context=_extract_context(src, m),
                confidence=0.98,
            )
            for m in _SOURCE_MAP_RE.finditer(src)
        ]

    def _commented_secrets(self, url: str, src: str) -> list[JSFinding]:
        return [
            JSFinding(
                js_url=url, finding_type="commented_code",
                value=m.group(0).strip()[:120],
                context=None,
                confidence=0.70,
            )
            for m in _COMMENT_SECRET_RE.finditer(src)
        ]

    def _package_refs(self, url: str, src: str) -> list[JSFinding]:
        seen: set[str] = set()
        out = []
        for pat in (_REQUIRE_RE, _ES6_IMPORT_RE):
            for m in pat.finditer(src):
                pkg = m.group(1).strip()
                if pkg.startswith(".") or len(pkg) < 2 or pkg in seen:
                    continue
                seen.add(pkg)
                out.append(JSFinding(
                    js_url=url, finding_type="package_ref",
                    value=pkg,
                    context=_extract_context(src, m),
                    confidence=0.80,
                ))
        return out

    def _credentials(self, url: str, src: str) -> list[JSFinding]:
        return [
            JSFinding(
                js_url=url, finding_type="credential",
                value=f"user={m.group(1)[:40]}, pass={m.group(2)[:40]}",
                context=_extract_context(src, m),
                confidence=0.85,
            )
            for m in _CRED_RE.finditer(src)
        ]

    def _entropy_secrets(self, url: str, src: str) -> list[JSFinding]:
        hits = find_high_entropy_strings(
            src,
            threshold=self._entropy_threshold,
            min_len=self._min_len,
            max_len=self._max_len,
        )
        return [
            JSFinding(
                js_url=url, finding_type="secret_entropy",
                value=h.value[:80],
                context=h.context,
                confidence=min(0.5 + (h.entropy - self._entropy_threshold) * 0.12, 0.95),
            )
            for h in hits
        ]

    def _assignment_secrets(self, url: str, src: str) -> list[JSFinding]:
        hits = find_secret_assignments(src, threshold=3.5, min_len=8)
        return [
            JSFinding(
                js_url=url, finding_type="secret_assignment",
                value=f"{h['var_name']}={h['value'][:60]}",
                context=h["context"],
                confidence=0.88,
            )
            for h in hits
        ]
