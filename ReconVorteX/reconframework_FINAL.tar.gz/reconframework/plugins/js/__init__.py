"""
plugins/js/__init__.py
========================
Phase 8 — JavaScript Intelligence plugin package.
"""

from plugins.js.entropy import EntropyHit, find_high_entropy_strings, find_secret_assignments
from plugins.js.extractors import JSExtractor, JSFinding
from plugins.js.fetcher import FetchedJS, JSDiscoveryResult, JSFetcher

__all__ = [
    "JSExtractor", "JSFinding",
    "JSFetcher", "FetchedJS", "JSDiscoveryResult",
    "EntropyHit", "find_high_entropy_strings", "find_secret_assignments",
]
