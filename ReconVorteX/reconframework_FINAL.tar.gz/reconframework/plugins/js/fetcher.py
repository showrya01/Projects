"""
plugins/js/fetcher.py
=======================
JavaScript file discovery and fetching for Phase 8.

Two discovery sources
---------------------
1. **Phase 6 URL list** — filter for .js extensions directly.
2. **Phase 2 live hosts** — fetch each page's HTML, parse <script src="…">
   tags to discover JS files not already in the Phase 6 list.

Both sets are merged, deduplicated, then fetched concurrently under a
semaphore to respect cfg.concurrency.

JS files larger than cfg.max_js_size_bytes are skipped — minified bundles
can be 5–10 MB and yield mostly noise.
"""

from __future__ import annotations

import asyncio
import logging
import re
from dataclasses import dataclass, field
from urllib.parse import urljoin, urlparse

import aiohttp

from core.config import Phase8Config

log = logging.getLogger(__name__)

# Parse <script src="..."> from HTML
_SCRIPT_SRC_RE = re.compile(
    r"""<script[^>]+src\s*=\s*['"]([^'"]+\.js[^'"]*?)['"]""",
    re.IGNORECASE,
)

# Also catch JS loaded via import() or require()
_DYNAMIC_IMPORT_RE = re.compile(
    r"""(?:import|require)\s*\(?['"`]([^'"`]+\.js[^'"`]*?)['"`]\)?""",
    re.IGNORECASE,
)


@dataclass
class FetchedJS:
    url:     str
    source:  str          # decoded JS source
    size:    int          # bytes
    status:  int


@dataclass
class JSDiscoveryResult:
    js_urls:     list[str]          = field(default_factory=list)
    fetched:     list[FetchedJS]    = field(default_factory=list)
    skipped:     list[str]          = field(default_factory=list)   # too large / error
    errors:      list[dict]         = field(default_factory=list)


class JSFetcher:
    """Discovers and fetches JavaScript files from both Phase 2 and Phase 6 data."""

    def __init__(self, cfg: Phase8Config) -> None:
        self._cfg = cfg

    async def discover_and_fetch(
        self,
        *,
        phase6_urls:  list[str],
        live_hosts:   list[dict],
    ) -> JSDiscoveryResult:
        """
        Main entry point.

        Parameters
        ----------
        phase6_urls : All URLs collected in Phase 6.
        live_hosts  : List of Phase 2 live host dicts (url, host, …).
        """
        cfg    = self._cfg
        result = JSDiscoveryResult()

        # ------------------------------------------------------------------
        # 1. Phase 6: filter .js URLs directly
        # ------------------------------------------------------------------
        js_from_p6 = [
            u for u in phase6_urls
            if self._is_js_url(u)
        ]
        log.info("JS URLs from Phase 6", extra={"count": len(js_from_p6)})

        # ------------------------------------------------------------------
        # 2. Phase 2: scrape live host pages for <script src>
        # ------------------------------------------------------------------
        js_from_scrape: list[str] = []
        if cfg.scrape_live_hosts and live_hosts:
            hosts_to_scrape = live_hosts[: cfg.max_live_hosts_to_scrape]
            js_from_scrape  = await self._scrape_script_tags(hosts_to_scrape)
            log.info(
                "JS URLs from live host scrape",
                extra={"count": len(js_from_scrape)},
            )

        # ------------------------------------------------------------------
        # 3. Merge + deduplicate
        # ------------------------------------------------------------------
        seen: set[str] = set()
        all_js: list[str] = []
        for url in js_from_p6 + js_from_scrape:
            norm = url.split("?")[0].split("#")[0]
            if norm not in seen:
                seen.add(norm)
                all_js.append(url)

        # Cap at max_js_files
        all_js = all_js[: cfg.max_js_files]
        result.js_urls = all_js
        log.info("Total unique JS files to fetch", extra={"count": len(all_js)})

        if not all_js:
            return result

        # ------------------------------------------------------------------
        # 4. Fetch all JS files concurrently
        # ------------------------------------------------------------------
        timeout   = aiohttp.ClientTimeout(total=cfg.timeout_s)
        connector = aiohttp.TCPConnector(ssl=False, limit=cfg.concurrency + 10)
        sem       = asyncio.Semaphore(cfg.concurrency)
        headers   = {"User-Agent": cfg.user_agent}

        async with aiohttp.ClientSession(
            connector=connector,
            timeout=timeout,
            headers=headers,
        ) as session:
            tasks = [
                self._fetch_one(session, url, sem, result)
                for url in all_js
            ]
            await asyncio.gather(*tasks)

        log.info(
            "JS fetch complete",
            extra={
                "fetched": len(result.fetched),
                "skipped": len(result.skipped),
                "errors":  len(result.errors),
            },
        )
        return result

    # ------------------------------------------------------------------
    # Script tag scraper
    # ------------------------------------------------------------------

    async def _scrape_script_tags(self, live_hosts: list[dict]) -> list[str]:
        """Fetch each live host page and extract <script src="..."> URLs."""
        cfg       = self._cfg
        timeout   = aiohttp.ClientTimeout(total=cfg.timeout_s)
        connector = aiohttp.TCPConnector(ssl=False, limit=cfg.concurrency + 10)
        sem       = asyncio.Semaphore(min(cfg.concurrency, 20))
        headers   = {"User-Agent": cfg.user_agent}

        discovered: list[str] = []

        async def _scrape_one(url: str) -> list[str]:
            async with sem:
                try:
                    async with session.get(url, allow_redirects=True, ssl=False) as resp:
                        if resp.status not in range(200, 400):
                            return []
                        html = await resp.content.read(131_072)  # 128 KB max
                        html_text = html.decode(errors="replace")
                        base_url  = str(resp.url)
                        return self._extract_script_urls(html_text, base_url)
                except Exception:
                    return []

        async with aiohttp.ClientSession(
            connector=connector,
            timeout=timeout,
            headers=headers,
        ) as session:
            tasks   = [_scrape_one(h.get("url", "")) for h in live_hosts if h.get("url")]
            results = await asyncio.gather(*tasks)
            for r in results:
                discovered.extend(r)

        return discovered

    @staticmethod
    def _extract_script_urls(html: str, base_url: str) -> list[str]:
        """Parse <script src> and dynamic import() paths from HTML."""
        found: list[str] = []
        for pat in (_SCRIPT_SRC_RE, _DYNAMIC_IMPORT_RE):
            for m in pat.finditer(html):
                src = m.group(1).strip()
                if not src or src.startswith("data:"):
                    continue
                # Resolve relative URLs
                if src.startswith("//"):
                    src = "https:" + src
                elif not src.startswith("http"):
                    src = urljoin(base_url, src)
                found.append(src)
        return found

    # ------------------------------------------------------------------
    # JS file fetcher
    # ------------------------------------------------------------------

    async def _fetch_one(
        self,
        session: aiohttp.ClientSession,
        url:     str,
        sem:     asyncio.Semaphore,
        result:  JSDiscoveryResult,
    ) -> None:
        cfg = self._cfg
        async with sem:
            try:
                async with session.get(url, allow_redirects=True, ssl=False) as resp:
                    if resp.status not in range(200, 300):
                        result.skipped.append(url)
                        return

                    # Check Content-Length before downloading
                    cl = resp.headers.get("Content-Length")
                    if cl and int(cl) > cfg.max_js_size_bytes:
                        log.debug(
                            "JS file too large — skipped",
                            extra={"url": url, "size": cl},
                        )
                        result.skipped.append(url)
                        return

                    raw = await resp.content.read(cfg.max_js_size_bytes + 1)

                    if len(raw) > cfg.max_js_size_bytes:
                        result.skipped.append(url)
                        return

                    source = raw.decode(errors="replace")
                    result.fetched.append(FetchedJS(
                        url=url,
                        source=source,
                        size=len(raw),
                        status=resp.status,
                    ))

            except asyncio.TimeoutError:
                result.errors.append({"url": url, "error": "timeout"})
            except Exception as exc:
                result.errors.append({"url": url, "error": str(exc)[:100]})

    @staticmethod
    def _is_js_url(url: str) -> bool:
        path = urlparse(url).path.lower().split("?")[0]
        return path.endswith(".js") or path.endswith(".mjs") or path.endswith(".cjs")
