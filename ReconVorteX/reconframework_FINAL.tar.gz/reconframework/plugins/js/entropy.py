"""
plugins/js/entropy.py
=======================
Shannon entropy scoring for JavaScript secret detection.

High-entropy strings are statistically likely to be secrets (API keys,
tokens, passwords) rather than natural-language text. This module:

  1. Calculates Shannon entropy for a string over its character set.
  2. Applies character-set heuristics to avoid false positives:
       • Base64 strings  (A-Za-z0-9+/=)
       • Hex strings     (0-9a-f)
       • Alphanumeric    (A-Za-z0-9)
  3. Filters strings below a minimum length and above a maximum.

Typical entropy thresholds:
  • English text:        ~3.5–4.0 bits/char
  • Random Base64 key:   ~5.5–6.0 bits/char
  • Good threshold:      ≥ 4.5 bits/char (catches most secrets, few false positives)

Reference: Trufflehog / detect-secrets entropy methodology.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass

# Character sets used for entropy calculation
_BASE64_CHARS = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=")
_HEX_CHARS    = set("0123456789abcdefABCDEF")
_ALNUM_CHARS  = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-")

# Regex to extract candidate high-entropy strings from JS source
# Matches quoted string values (single or double quoted)
_QUOTED_STRING_RE = re.compile(
    r"""(?:['"`])([A-Za-z0-9+/=_\-]{20,200})(?:['"`])""",
    re.MULTILINE,
)

# Commonly assigned variable names that suggest secrets
_SECRET_VAR_NAMES = frozenset([
    "key", "secret", "token", "password", "passwd", "pwd", "api_key",
    "apikey", "api_secret", "auth", "auth_token", "access_token",
    "refresh_token", "private_key", "client_secret", "client_id",
    "consumer_key", "consumer_secret", "app_key", "app_secret",
    "service_key", "encryption_key", "signing_key", "hmac_key",
    "jwt_secret", "session_secret", "cookie_secret", "secret_key",
    "database_password", "db_pass", "smtp_pass",
])

# Regex that catches `varName = "value"` or `varName: "value"` assignments
_ASSIGNMENT_RE = re.compile(
    r"""(?:const|let|var|)\s*"""
    r"""([\w_]+)\s*[=:]\s*"""
    r"""['"`]([A-Za-z0-9+/=_\-]{8,200})['"`]""",
    re.IGNORECASE | re.MULTILINE,
)


@dataclass
class EntropyHit:
    value:    str
    entropy:  float
    charset:  str         # "base64" | "hex" | "alnum"
    context:  str | None  # surrounding code snippet


def shannon_entropy(s: str, charset: set[str]) -> float:
    """
    Calculate Shannon entropy of string `s` over the given charset.
    Returns 0.0 if the string contains characters outside the charset.
    """
    if not s or not all(c in charset for c in s):
        return 0.0
    freq: dict[str, int] = {}
    for c in s:
        freq[c] = freq.get(c, 0) + 1
    n = len(s)
    return -sum((count / n) * math.log2(count / n) for count in freq.values())


def _best_entropy(s: str) -> tuple[float, str]:
    """Return (entropy, charset_name) for the charset that gives highest entropy."""
    results = [
        (shannon_entropy(s, _BASE64_CHARS), "base64"),
        (shannon_entropy(s, _HEX_CHARS),    "hex"),
        (shannon_entropy(s, _ALNUM_CHARS),  "alnum"),
    ]
    return max(results, key=lambda x: x[0])


def find_high_entropy_strings(
    source:    str,
    threshold: float = 4.5,
    min_len:   int   = 20,
    max_len:   int   = 200,
) -> list[EntropyHit]:
    """
    Scan JavaScript source for high-entropy quoted strings.

    Returns list of EntropyHit objects sorted by entropy descending.
    Deduplicates identical values.
    """
    hits: dict[str, EntropyHit] = {}

    for m in _QUOTED_STRING_RE.finditer(source):
        value = m.group(1)
        if not (min_len <= len(value) <= max_len):
            continue

        entropy, charset = _best_entropy(value)
        if entropy < threshold:
            continue

        if value not in hits or hits[value].entropy < entropy:
            # Extract surrounding context (±40 chars)
            start  = max(0, m.start() - 40)
            end    = min(len(source), m.end() + 40)
            context = source[start:end].replace("\n", " ").strip()

            hits[value] = EntropyHit(
                value=value,
                entropy=round(entropy, 3),
                charset=charset,
                context=context,
            )

    return sorted(hits.values(), key=lambda h: -h.entropy)


def find_secret_assignments(
    source:    str,
    threshold: float = 3.5,   # lower bar when variable name is suspicious
    min_len:   int   = 8,
) -> list[dict[str, str]]:
    """
    Find assignment patterns where the variable name suggests a secret
    and the value has at least moderate entropy.

    E.g.:
        const API_KEY = "xK9pLm2nQr..."
        let password   = "S3cur3P@ss!"
        { token: "eyJhbG..." }
    """
    hits: list[dict[str, str]] = []
    seen: set[str] = set()

    for m in _ASSIGNMENT_RE.finditer(source):
        var_name = m.group(1).lower().rstrip("_")
        value    = m.group(2)

        if var_name not in _SECRET_VAR_NAMES:
            continue
        if len(value) < min_len:
            continue
        if value in seen:
            continue

        entropy, charset = _best_entropy(value)
        if entropy < threshold:
            continue

        seen.add(value)
        start   = max(0, m.start() - 20)
        end     = min(len(source), m.end() + 20)
        context = source[start:end].replace("\n", " ").strip()

        hits.append({
            "var_name": m.group(1),
            "value":    value,
            "entropy":  str(round(entropy, 3)),
            "charset":  charset,
            "context":  context,
        })

    return hits
