"""
plugins/scanner/nuclei_scanner.py
====================================
Safe vulnerability scanning via Nuclei binary.

Runs templates tagged:
  misconfig, exposure, exposed-panels, cve, security-headers, tech

Only non-intrusive templates are used — no active exploitation,
no fuzzing, no authentication attempts.

Command (JSON per line):
    nuclei -l targets.txt -tags misconfig,exposure,...
           -severity info,low,medium,high,critical
           -json -silent -no-interactsh
"""

from __future__ import annotations

import asyncio
import json
import logging
import shutil
import tempfile
from pathlib import Path

from core.base_plugin import BasePlugin, PluginContext, PluginResult
from core.models import NucleiFinding

log = logging.getLogger(__name__)

# Map Nuclei severity strings to our canonical values
_SEV_MAP = {
    "info":     "info",
    "low":      "low",
    "medium":   "medium",
    "high":     "high",
    "critical": "critical",
    "unknown":  "info",
}


class NucleiScanner(BasePlugin[list[NucleiFinding]]):
    """
    Run Nuclei safe templates against a list of live host URLs.

    Context metadata expected:
        ctx.metadata["scan_urls"] — list of full URLs to scan
    """

    NAME     = "nuclei_scanner"
    PRIORITY = 5

    async def run(self, ctx: PluginContext) -> PluginResult[list[NucleiFinding]]:
        cfg    = ctx.config.phase10
        binary = shutil.which(cfg.nuclei_bin) or cfg.nuclei_bin

        if not shutil.which(binary):
            self._log.info(
                "Nuclei binary not found — skipping",
                extra={"searched": binary},
            )
            return self._ok([])

        urls: list[str] = ctx.metadata.get("scan_urls", [])
        if not urls:
            return self._ok([])

        self._log.info(
            "Nuclei scan starting",
            extra={
                "urls": len(urls),
                "tags": cfg.nuclei_tags,
                "severity": cfg.nuclei_severity,
            },
        )

        try:
            findings = await self._run_nuclei(binary, urls, cfg)
        except Exception as exc:
            ctx.record_error(self.NAME, f"Nuclei scan failed: {exc}", exc)
            return self._fail(str(exc))

        self._log.info(
            "Nuclei scan complete",
            extra={"findings": len(findings)},
        )
        return self._ok(findings)

    async def _run_nuclei(
        self,
        binary: str,
        urls:   list[str],
        cfg,
    ) -> list[NucleiFinding]:
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".txt", delete=False, prefix="rf_nuclei10_"
        ) as tf:
            tf.write("\n".join(urls))
            tmp_path = tf.name

        cmd = [
            binary,
            "-l",        tmp_path,
            "-tags",     cfg.nuclei_tags,
            "-severity", cfg.nuclei_severity,
            "-json",
            "-silent",
            "-no-interactsh",       # disable OOB — keep scans contained
            "-timeout",  str(cfg.timeout_s),
            "-c",        str(min(cfg.concurrency, 100)),
        ]

        self._log.debug("Nuclei command", extra={"cmd": " ".join(cmd)})

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(),
                timeout=float(cfg.tool_timeout),
            )
        finally:
            Path(tmp_path).unlink(missing_ok=True)

        if stderr:
            self._log.debug(
                "Nuclei stderr",
                extra={"snippet": stderr.decode(errors="replace")[:300]},
            )

        return list(self._parse_output(stdout.decode(errors="replace")))

    @staticmethod
    def _parse_output(output: str) -> list[NucleiFinding]:
        findings: list[NucleiFinding] = []
        for line in output.splitlines():
            line = line.strip()
            if not line or not line.startswith("{"):
                continue
            try:
                data = json.loads(line)

                info     = data.get("info", {})
                host_raw = data.get("host", data.get("matched-at", ""))
                host     = (
                    host_raw
                    .replace("https://", "")
                    .replace("http://", "")
                    .split("/")[0]
                    .split(":")[0]
                )

                findings.append(NucleiFinding(
                    host=host,
                    template_id=data.get("template-id", "unknown"),
                    name=info.get("name", data.get("template-id", "unknown")),
                    severity=_SEV_MAP.get(
                        info.get("severity", "unknown").lower(), "info"
                    ),
                    matched_at=data.get("matched-at"),
                    description=info.get("description"),
                    tags=info.get("tags", []),
                ))
            except (json.JSONDecodeError, KeyError, AttributeError):
                continue

        return findings
