"""
plugins/scanner/header_checker.py
====================================
Pure-Python security header analysis for Phase 10.

Always runs regardless of Nuclei availability. Checks every live host
for missing or misconfigured HTTP security headers and produces
NucleiFinding-compatible records that feed directly into Phase 11.

Checks performed
----------------
CRITICAL / HIGH:
  • Missing Strict-Transport-Security (HSTS)       → HIGH
  • CORS wildcard (Access-Control-Allow-Origin: *)  → HIGH
  • Missing Content-Security-Policy (CSP)           → HIGH
  • Unsafe CSP directives (unsafe-inline/eval)      → MEDIUM

MEDIUM:
  • Missing X-Frame-Options                         → MEDIUM
  • Missing X-Content-Type-Options                  → MEDIUM
  • Cookies missing Secure or HttpOnly flags        → MEDIUM

LOW / INFO:
  • Missing Referrer-Policy                         → LOW
  • Missing Permissions-Policy                      → LOW
  • Server header version disclosure                → LOW
  • X-Powered-By header present                     → LOW
  • Missing X-XSS-Protection (legacy)               → INFO
  • Deprecated X-XSS-Protection: 1 (not 1;mode=block) → INFO
  • HTTP accessible without redirect to HTTPS       → MEDIUM
  • Cache-Control missing on authenticated pages    → INFO
"""

from __future__ import annotations

import asyncio
import logging
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone

import aiohttp

from core.models import NucleiFinding

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Header check definition
# ---------------------------------------------------------------------------

@dataclass
class HeaderCheck:
    """Definition of one header security check."""
    check_id:    str
    name:        str
    severity:    str          # info | low | medium | high | critical
    description: str
    tags:        list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Individual check functions
# ---------------------------------------------------------------------------

def _check_hsts(headers: dict, url: str) -> list[HeaderCheck] | None:
    if not url.startswith("https://"):
        return None                         # only relevant for HTTPS
    val = headers.get("strict-transport-security", "")
    if not val:
        return HeaderCheck(
            check_id="missing-hsts",
            name="Missing Strict-Transport-Security",
            severity="high",
            description="HSTS header absent — browser can be downgraded to HTTP.",
            tags=["security-headers", "hsts", "misconfig"],
        )
    # Check max-age is not too short (< 1 year = 31536000)
    m = re.search(r"max-age\s*=\s*(\d+)", val, re.IGNORECASE)
    if m and int(m.group(1)) < 31_536_000:
        return HeaderCheck(
            check_id="short-hsts-maxage",
            name="HSTS max-age Too Short",
            severity="medium",
            description=f"HSTS max-age={m.group(1)} — recommend ≥ 31536000 (1 year).",
            tags=["security-headers", "hsts"],
        )
    return None


def _check_csp(headers: dict) -> list[HeaderCheck]:
    issues: list[HeaderCheck] = []
    val = headers.get("content-security-policy", "")
    if not val:
        issues.append(HeaderCheck(
            check_id="missing-csp",
            name="Missing Content-Security-Policy",
            severity="high",
            description="No CSP header — XSS and data injection attacks not mitigated.",
            tags=["security-headers", "csp", "misconfig"],
        ))
        return issues
    # Check for unsafe directives
    lower = val.lower()
    if "'unsafe-inline'" in lower:
        issues.append(HeaderCheck(
            check_id="csp-unsafe-inline",
            name="CSP Contains 'unsafe-inline'",
            severity="medium",
            description="CSP allows inline scripts/styles — degrades XSS protection.",
            tags=["security-headers", "csp"],
        ))
    if "'unsafe-eval'" in lower:
        issues.append(HeaderCheck(
            check_id="csp-unsafe-eval",
            name="CSP Contains 'unsafe-eval'",
            severity="medium",
            description="CSP allows eval() — code injection risk.",
            tags=["security-headers", "csp"],
        ))
    if "default-src *" in lower or "script-src *" in lower:
        issues.append(HeaderCheck(
            check_id="csp-wildcard-src",
            name="CSP Uses Wildcard Source",
            severity="medium",
            description="CSP uses '*' as source — defeats XSS protection.",
            tags=["security-headers", "csp"],
        ))
    return issues


def _check_xframe(headers: dict) -> HeaderCheck | None:
    val = headers.get("x-frame-options", "")
    if not val:
        return HeaderCheck(
            check_id="missing-x-frame-options",
            name="Missing X-Frame-Options",
            severity="medium",
            description="No X-Frame-Options — clickjacking attacks possible.",
            tags=["security-headers", "clickjacking"],
        )
    return None


def _check_xcto(headers: dict) -> HeaderCheck | None:
    val = headers.get("x-content-type-options", "")
    if not val:
        return HeaderCheck(
            check_id="missing-xcto",
            name="Missing X-Content-Type-Options",
            severity="medium",
            description="No X-Content-Type-Options: nosniff — MIME-sniffing attacks possible.",
            tags=["security-headers", "mime-sniffing"],
        )
    return None


def _check_referrer(headers: dict) -> HeaderCheck | None:
    if not headers.get("referrer-policy", ""):
        return HeaderCheck(
            check_id="missing-referrer-policy",
            name="Missing Referrer-Policy",
            severity="low",
            description="No Referrer-Policy — sensitive URL paths may leak via Referer header.",
            tags=["security-headers", "info-disclosure"],
        )
    return None


def _check_permissions(headers: dict) -> HeaderCheck | None:
    if not headers.get("permissions-policy", "") and \
       not headers.get("feature-policy", ""):
        return HeaderCheck(
            check_id="missing-permissions-policy",
            name="Missing Permissions-Policy",
            severity="low",
            description="No Permissions-Policy — browser features not restricted.",
            tags=["security-headers"],
        )
    return None


def _check_cors(headers: dict) -> HeaderCheck | None:
    acao = headers.get("access-control-allow-origin", "")
    if acao == "*":
        credentials = headers.get("access-control-allow-credentials", "").lower()
        if credentials == "true":
            return HeaderCheck(
                check_id="cors-wildcard-with-credentials",
                name="CORS Wildcard With Credentials",
                severity="critical",
                description="ACAO: * with ACAC: true — credentials exposed to any origin.",
                tags=["cors", "misconfig", "high-impact"],
            )
        return HeaderCheck(
            check_id="cors-wildcard",
            name="CORS Wildcard (Access-Control-Allow-Origin: *)",
            severity="high",
            description="Any origin can read API responses — verify this is intentional.",
            tags=["cors", "misconfig"],
        )
    return None


def _check_server_disclosure(headers: dict) -> HeaderCheck | None:
    server = headers.get("server", "")
    # Only flag if version info is present
    if server and re.search(r"[\d.]{3,}", server):
        return HeaderCheck(
            check_id="server-version-disclosure",
            name="Server Version Disclosure",
            severity="low",
            description=f"Server header reveals version: '{server[:60]}' — aids targeted attacks.",
            tags=["info-disclosure", "tech"],
        )
    return None


def _check_x_powered_by(headers: dict) -> HeaderCheck | None:
    xpb = headers.get("x-powered-by", "")
    if xpb:
        return HeaderCheck(
            check_id="x-powered-by-disclosure",
            name="X-Powered-By Header Present",
            severity="low",
            description=f"X-Powered-By: '{xpb[:60]}' reveals technology stack.",
            tags=["info-disclosure", "tech"],
        )
    return None


def _check_xss_protection(headers: dict) -> HeaderCheck | None:
    val = headers.get("x-xss-protection", "")
    if not val:
        return HeaderCheck(
            check_id="missing-xss-protection",
            name="Missing X-XSS-Protection (Legacy)",
            severity="info",
            description="X-XSS-Protection absent — deprecated but still checked by some scanners.",
            tags=["security-headers"],
        )
    return None


def _check_cookies(set_cookie: str) -> list[HeaderCheck]:
    """Parse Set-Cookie header and flag missing Secure/HttpOnly flags."""
    issues: list[HeaderCheck] = []
    if not set_cookie:
        return issues
    # Each cookie is separated by comma, but commas also appear in dates.
    # Simple heuristic: split on ", " only when followed by a word=
    cookies = re.split(r",\s*(?=[a-zA-Z])", set_cookie)
    for cookie in cookies:
        cookie_lower = cookie.lower()
        name_match   = re.match(r"([^=;]+)=", cookie)
        name         = name_match.group(1).strip() if name_match else "unknown"

        if "secure" not in cookie_lower and "localhost" not in cookie_lower:
            issues.append(HeaderCheck(
                check_id="cookie-missing-secure",
                name=f"Cookie Missing Secure Flag: {name[:40]}",
                severity="medium",
                description=f"Cookie '{name[:40]}' lacks Secure flag — transmitted over HTTP.",
                tags=["cookies", "misconfig"],
            ))
        if "httponly" not in cookie_lower:
            issues.append(HeaderCheck(
                check_id="cookie-missing-httponly",
                name=f"Cookie Missing HttpOnly Flag: {name[:40]}",
                severity="medium",
                description=f"Cookie '{name[:40]}' lacks HttpOnly — accessible via JavaScript.",
                tags=["cookies", "misconfig"],
            ))
    return issues


# ---------------------------------------------------------------------------
# Checker class
# ---------------------------------------------------------------------------

class HeaderChecker:
    """
    Async security header analyser.

    For each URL, makes one GET request and runs all header checks.
    Results are NucleiFinding objects compatible with Phase 11 scoring.
    """

    def __init__(self, cfg) -> None:
        self._cfg = cfg

    async def check_all(self, urls: list[str]) -> list[NucleiFinding]:
        cfg       = self._cfg
        sem       = asyncio.Semaphore(cfg.concurrency)
        timeout   = aiohttp.ClientTimeout(total=cfg.header_timeout_s)
        connector = aiohttp.TCPConnector(ssl=False, limit=cfg.concurrency + 20)
        headers   = {"User-Agent": cfg.user_agent}

        async with aiohttp.ClientSession(
            connector=connector,
            timeout=timeout,
            headers=headers,
        ) as session:
            tasks = [
                self._check_one(session, url, sem)
                for url in urls
            ]
            all_results = await asyncio.gather(*tasks, return_exceptions=True)

        findings: list[NucleiFinding] = []
        for batch in all_results:
            if isinstance(batch, list):
                findings.extend(batch)
        return findings

    async def _check_one(
        self,
        session: aiohttp.ClientSession,
        url:     str,
        sem:     asyncio.Semaphore,
    ) -> list[NucleiFinding]:
        async with sem:
            try:
                async with session.get(
                    url,
                    allow_redirects=True,
                    ssl=False,
                    max_redirects=3,
                ) as resp:
                    headers    = {k.lower(): v for k, v in resp.headers.items()}
                    final_url  = str(resp.url)
                    set_cookie = resp.headers.get("Set-Cookie", "")
                    host = final_url.replace("https://", "").replace("http://", "").split("/")[0]
            except Exception:
                return []

        checks: list[HeaderCheck | None] = []

        # Run all checks
        hsts = _check_hsts(headers, final_url)
        checks.append(hsts)

        checks += _check_csp(headers)
        checks.append(_check_xframe(headers))
        checks.append(_check_xcto(headers))
        checks.append(_check_referrer(headers))
        checks.append(_check_permissions(headers))
        checks.append(_check_cors(headers))
        checks.append(_check_server_disclosure(headers))
        checks.append(_check_x_powered_by(headers))
        checks.append(_check_xss_protection(headers))
        checks += _check_cookies(set_cookie)

        # Convert to NucleiFinding
        findings: list[NucleiFinding] = []
        for chk in checks:
            if chk is None:
                continue
            findings.append(NucleiFinding(
                host=host,
                template_id=chk.check_id,
                name=chk.name,
                severity=chk.severity,
                matched_at=url,
                description=chk.description,
                tags=chk.tags,
            ))

        return findings
