"""
plugins/takeover/nuclei_runner.py
====================================
Subdomain takeover detection via Nuclei takeover templates.

Uses the `takeover` tag from projectdiscovery/nuclei-templates.

Command:
    nuclei -l targets.txt -tags takeover -json -severity info,low,medium,high,critical
"""

from __future__ import annotations

import asyncio
import json
import logging
import shutil
import tempfile
from pathlib import Path

from core.base_plugin import BasePlugin, PluginContext, PluginResult
from plugins.takeover.http_checker import TakeoverCandidate

log = logging.getLogger(__name__)


class NucleiTakeoverRunner(BasePlugin[list[TakeoverCandidate]]):
    """Run Nuclei takeover templates and return findings."""

    NAME     = "nuclei_takeover"
    PRIORITY = 10

    async def run(self, ctx: PluginContext) -> PluginResult[list[TakeoverCandidate]]:
        cfg    = ctx.config.phase9
        binary = shutil.which(cfg.nuclei_bin) or cfg.nuclei_bin

        if not shutil.which(binary):
            self._log.info("Nuclei binary not found — skipping", extra={"searched": binary})
            return self._ok([])

        hosts: list[str] = ctx.metadata.get("takeover_hosts", [])
        if not hosts:
            return self._ok([])

        self._log.info(
            "Nuclei takeover scan starting",
            extra={"hosts": len(hosts), "binary": binary},
        )

        try:
            candidates = await self._run_nuclei(binary, hosts, cfg)
        except Exception as exc:
            ctx.record_error(self.NAME, f"Nuclei failed: {exc}", exc)
            return self._fail(str(exc))

        self._log.info("Nuclei takeover scan complete", extra={"findings": len(candidates)})
        return self._ok(candidates)

    async def _run_nuclei(
        self,
        binary: str,
        hosts:  list[str],
        cfg,
    ) -> list[TakeoverCandidate]:
        # Write targets — Nuclei expects full URLs or hosts
        targets = [
            (f"https://{h}" if not h.startswith("http") else h)
            for h in hosts
        ]

        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".txt", delete=False, prefix="rf_nuclei_to_"
        ) as tf:
            tf.write("\n".join(targets))
            tmp_path = tf.name

        cmd = [
            binary,
            "-l",        tmp_path,
            "-tags",     cfg.nuclei_takeover_tags,
            "-severity", cfg.nuclei_severity,
            "-json",
            "-silent",
            "-no-interactsh",  # disable OOB — keep scans self-contained
        ]

        self._log.debug("Nuclei command", extra={"cmd": " ".join(cmd)})

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await asyncio.wait_for(
                proc.communicate(),
                timeout=float(cfg.tool_timeout),
            )
        finally:
            Path(tmp_path).unlink(missing_ok=True)

        candidates: list[TakeoverCandidate] = []
        for line in stdout.decode(errors="replace").splitlines():
            line = line.strip()
            if not line or not line.startswith("{"):
                continue
            try:
                data     = json.loads(line)
                host_raw = data.get("host", data.get("matched-at", ""))
                host     = host_raw.replace("https://", "").replace("http://", "").split("/")[0]
                template = data.get("template-id", "unknown")
                name     = data.get("info", {}).get("name", template)
                severity = data.get("info", {}).get("severity", "unknown")

                candidates.append(TakeoverCandidate(
                    host=host,
                    url=host_raw if host_raw.startswith("http") else f"https://{host}",
                    service=name,
                    fingerprint=template,
                    confidence=cfg.conf_nuclei,
                    method="nuclei",
                    evidence=[
                        f"Nuclei template: {template}",
                        f"Severity: {severity}",
                    ],
                ))
            except (json.JSONDecodeError, KeyError, AttributeError):
                continue

        return candidates
