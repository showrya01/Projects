"""
plugins/takeover/__init__.py
================================
Phase 9 — Subdomain Takeover Detection plugin package.
"""

from plugins.takeover.fingerprints import COMPILED_FINGERPRINTS, TakeoverFingerprint
from plugins.takeover.http_checker import HTTPTakeoverChecker, TakeoverCandidate
from plugins.takeover.nuclei_runner import NucleiTakeoverRunner
from plugins.takeover.subzy_runner import SubzyRunner

__all__ = [
    "TakeoverFingerprint", "COMPILED_FINGERPRINTS",
    "TakeoverCandidate", "HTTPTakeoverChecker",
    "SubzyRunner", "NucleiTakeoverRunner",
]
