"""
plugins/takeover/http_checker.py
===================================
Pure-Python async subdomain takeover checker.

Strategy
--------
For each subdomain:
  1. Attempt HTTP + HTTPS request (concurrent).
  2. Check response body and status code against every fingerprint.
  3. Additionally check CNAME via the response URL (after redirects)
     and the ``Via`` / ``X-Served-By`` / ``Server`` headers.
  4. Return a TakeoverCandidate if any fingerprint matches.

This runs regardless of whether Subzy/Nuclei are available — it is the
always-on fallback and first-pass filter.

DNS CNAME resolution
--------------------
We avoid requiring dnspython by inferring the CNAME from:
  a) The redirect URL (aiohttp follows redirects, final URL reveals CDN).
  b) HTTP headers: ``Server``, ``X-Powered-By``, ``Via``, ``X-Cache``.
  c) An asyncio executor call to ``socket.getfqdn()`` / ``socket.getaddrinfo()``.
"""

from __future__ import annotations

import asyncio
import logging
import re
import socket
from dataclasses import dataclass, field
from urllib.parse import urlparse

import aiohttp

from core.config import Phase9Config
from plugins.takeover.fingerprints import COMPILED_FINGERPRINTS, TakeoverFingerprint

log = logging.getLogger(__name__)

# Headers that might reveal the underlying CDN/service
_CDN_HEADERS = [
    "server", "via", "x-served-by", "x-cache",
    "x-amz-cf-id",       # CloudFront
    "x-nf-request-id",   # Netlify
    "x-heroku-queue-wait-time",  # Heroku
    "x-github-request-id",       # GitHub
    "x-ms-ref",          # Azure
    "fly-request-id",    # Fly.io
    "x-render-origin-server",    # Render
    "x-vercel-id",       # Vercel
]


@dataclass
class TakeoverCandidate:
    """A subdomain that may be vulnerable to takeover."""

    host:        str
    url:         str
    service:     str
    fingerprint: str                 # which body/cname pattern matched
    confidence:  float
    cname_hint:  str | None = None   # inferred CNAME/CDN info
    status_code: int | None = None
    method:      str = "http_check"  # "http_check" | "subzy" | "nuclei"
    evidence:    list[str] = field(default_factory=list)


class HTTPTakeoverChecker:
    """
    Async HTTP-based takeover checker.

    Instantiate once, call check_all() with a list of hostnames.
    """

    def __init__(self, cfg: Phase9Config) -> None:
        self._cfg = cfg

    async def check_all(self, hosts: list[str]) -> list[TakeoverCandidate]:
        """
        Check all hosts concurrently.

        Returns a list of TakeoverCandidate objects.
        """
        cfg       = self._cfg
        sem       = asyncio.Semaphore(cfg.concurrency)
        timeout   = aiohttp.ClientTimeout(total=cfg.timeout_s)
        connector = aiohttp.TCPConnector(ssl=False, limit=cfg.concurrency + 20)
        headers   = {"User-Agent": cfg.user_agent}

        async with aiohttp.ClientSession(
            connector=connector,
            timeout=timeout,
            headers=headers,
        ) as session:
            tasks = [
                self._check_host(session, host, sem)
                for host in hosts
            ]
            results = await asyncio.gather(*tasks, return_exceptions=True)

        candidates: list[TakeoverCandidate] = []
        for r in results:
            if isinstance(r, TakeoverCandidate):
                candidates.append(r)
        return candidates

    async def _check_host(
        self,
        session: aiohttp.ClientSession,
        host:    str,
        sem:     asyncio.Semaphore,
    ) -> TakeoverCandidate | None:
        """Check one host — try HTTPS then HTTP."""
        async with sem:
            for scheme in ("https", "http"):
                url = f"{scheme}://{host}"
                result = await self._probe(session, url, host)
                if result:
                    return result
            return None

    async def _probe(
        self,
        session: aiohttp.ClientSession,
        url:     str,
        host:    str,
    ) -> TakeoverCandidate | None:
        """Make one HTTP request and run fingerprint matching."""
        try:
            async with session.get(
                url,
                allow_redirects=True,
                ssl=False,
                max_redirects=5,
            ) as resp:
                status   = resp.status
                body     = (await resp.content.read(65_536)).decode(errors="replace")
                headers  = {k.lower(): v for k, v in resp.headers.items()}
                final_url = str(resp.url)

        except asyncio.TimeoutError:
            return None
        except Exception:
            return None

        # Build a combined "CNAME hint" from redirect URL + response headers
        cname_hint = self._infer_cname(final_url, headers, host)

        # Run against every fingerprint
        for fp in COMPILED_FINGERPRINTS:
            candidate = self._match_fingerprint(
                fp, host, url, status, body, cname_hint
            )
            if candidate:
                return candidate

        return None

    def _infer_cname(
        self, final_url: str, headers: dict, original_host: str
    ) -> str | None:
        """
        Infer the underlying CNAME / CDN from redirect URL and headers.
        Returns a string hint or None.
        """
        hints: list[str] = []

        # 1. Final URL after redirects may reveal CDN domain
        final_host = urlparse(final_url).hostname or ""
        if final_host and final_host != original_host:
            hints.append(final_host)

        # 2. Service-specific headers
        for h in _CDN_HEADERS:
            if v := headers.get(h):
                hints.append(f"{h}:{v[:80]}")

        return " | ".join(hints) if hints else None

    @staticmethod
    def _match_fingerprint(
        fp:         TakeoverFingerprint,
        host:       str,
        url:        str,
        status:     int,
        body:       str,
        cname_hint: str | None,
    ) -> TakeoverCandidate | None:
        """
        Apply a single fingerprint to the probe result.

        Returns a TakeoverCandidate if a match is found, else None.
        """
        cname_match = bool(cname_hint and fp.matches_cname(cname_hint))
        body_match  = fp.matches_body(body) if body else False
        status_ok   = status in fp.status_codes if fp.status_codes else True

        # Need at least one signal to flag
        if not (cname_match or (body_match and status_ok)):
            return None

        # Calculate confidence
        if cname_match and body_match and status_ok:
            confidence = 0.90
            matched    = "cname+body"
        elif body_match and status_ok:
            confidence = 0.75
            matched    = "body"
        elif cname_match:
            confidence = 0.60
            matched    = "cname"
        else:
            return None

        evidence: list[str] = []
        if cname_match:
            evidence.append(f"CNAME hint matches {fp.service}")
        if body_match:
            evidence.append(f"Response body contains {fp.service} unclaimed fingerprint")
        if status_ok:
            evidence.append(f"HTTP {status} (expected for unclaimed {fp.service})")

        return TakeoverCandidate(
            host=host,
            url=url,
            service=fp.service,
            fingerprint=matched,
            confidence=confidence,
            cname_hint=cname_hint,
            status_code=status,
            method="http_check",
            evidence=evidence,
        )
