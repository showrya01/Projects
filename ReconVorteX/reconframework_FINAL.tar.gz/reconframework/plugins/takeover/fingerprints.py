"""
plugins/takeover/fingerprints.py
===================================
Subdomain takeover fingerprint database.

Each TakeoverFingerprint defines how to detect a vulnerable/unclaimed
service that a subdomain CNAME is pointing to.

Detection method
----------------
Two independent signals, either of which confirms a takeover candidate:

1. **CNAME pattern** — the subdomain's CNAME target matches a regex.
   E.g. `*.github.io` CNAMEs pointing at GitHub Pages.

2. **HTTP body fingerprint** — the HTTP response body (or status code)
   contains a known error string that the service emits when no project
   is configured for the domain.
   E.g. GitHub Pages returns "There isn't a GitHub Pages site here."

Confidence matrix (set in http_checker.py):
  CNAME match only:          0.60  (probable — CNAME points to vulnerable service)
  HTTP body match only:      0.75  (possible — service fingerprint, no DNS data)
  CNAME + HTTP body match:   0.90  (high — strong two-signal confirmation)
  Subzy confirmed:           0.95
  Nuclei confirmed:          0.97

References
----------
• https://github.com/EdOverflow/can-i-take-over-xyz
• https://github.com/punk-security/dnsReaper/blob/main/providers
• https://github.com/projectdiscovery/nuclei-templates (dns/takeover)
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field


@dataclass
class TakeoverFingerprint:
    """Fingerprint for one cloud service / hosting provider."""

    service:        str              # Human-readable service name
    cname_patterns: list[str]        # Regex patterns matched against CNAME target
    body_patterns:  list[str]        # Regex patterns matched against HTTP response body
    status_codes:   list[int]        # HTTP status codes that indicate unclaimed (usually 404)
    edge_cases:     str = ""         # Notes on false-positive edge cases
    confidence_boost: float = 0.0    # Added to base confidence when this FP matches

    # Compiled (populated by compile())
    _cname_compiled: list[re.Pattern] = field(default_factory=list, repr=False)
    _body_compiled:  list[re.Pattern] = field(default_factory=list, repr=False)

    def compile(self) -> "TakeoverFingerprint":
        flags = re.IGNORECASE | re.DOTALL
        self._cname_compiled = [re.compile(p, re.IGNORECASE) for p in self.cname_patterns]
        self._body_compiled  = [re.compile(p, flags) for p in self.body_patterns]
        return self

    def matches_cname(self, cname: str) -> bool:
        return any(p.search(cname) for p in self._cname_compiled)

    def matches_body(self, body: str) -> bool:
        return any(p.search(body) for p in self._body_compiled)


# ---------------------------------------------------------------------------
# Fingerprint registry
# ---------------------------------------------------------------------------

TAKEOVER_FINGERPRINTS: list[TakeoverFingerprint] = [

    TakeoverFingerprint(
        service="GitHub Pages",
        cname_patterns=[r"\.github\.io$", r"github\.io"],
        body_patterns=[
            r"There isn't a GitHub Pages site here",
            r"For root URLs.*?GitHub Pages",
            r"404 There is no GitHub Pages site here",
        ],
        status_codes=[404],
        edge_cases="Verify CNAME is project/user page. github.io with 404 + body fingerprint = confirmed.",
    ),

    TakeoverFingerprint(
        service="Heroku",
        cname_patterns=[
            r"\.herokuapp\.com$",
            r"\.herokudns\.com$",
            r"heroku\.com$",
        ],
        body_patterns=[
            r"no such app",
            r"herokucdn\.com/error-pages/no-such-app",
            r"There's nothing here",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="Netlify",
        cname_patterns=[r"\.netlify\.app$", r"\.netlify\.com$", r"netlify\.com"],
        body_patterns=[
            r"Not Found - Request ID",
            r"netlify.*?page not found",
            r"No sites here!",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="AWS S3",
        cname_patterns=[
            r"\.s3\.amazonaws\.com$",
            r"\.s3-website[.-]",
            r"s3\.amazonaws\.com",
        ],
        body_patterns=[
            r"<Code>NoSuchBucket</Code>",
            r"The specified bucket does not exist",
            r"NoSuchBucket",
        ],
        status_codes=[404, 403],
        edge_cases="403 can mean bucket exists but is private — only flag 404 with NoSuchBucket body.",
    ),

    TakeoverFingerprint(
        service="AWS Elastic Beanstalk",
        cname_patterns=[r"\.elasticbeanstalk\.com$"],
        body_patterns=[
            r"404 Not Found",
            r"No Application",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="Azure App Service",
        cname_patterns=[
            r"\.azurewebsites\.net$",
            r"\.azure-mobile\.net$",
            r"\.cloudapp\.net$",
        ],
        body_patterns=[
            r"404 Web Site not found",
            r"Microsoft Azure App Service",
            r"The resource you are looking for has been removed",
            r"404 - Website not found",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="Azure Traffic Manager",
        cname_patterns=[r"\.trafficmanager\.net$"],
        body_patterns=[
            r"404",
            r"Traffic Manager",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="Shopify",
        cname_patterns=[r"\.myshopify\.com$", r"shops\.myshopify\.com"],
        body_patterns=[
            r"Sorry, this shop is currently unavailable",
            r"this shop is currently unavailable",
            r"Only one step left",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="Fastly",
        cname_patterns=[r"\.fastly\.net$", r"fastly\.net"],
        body_patterns=[
            r"Fastly error: unknown domain",
            r"Please check that this domain has been added to a service",
        ],
        status_codes=[500, 404],
    ),

    TakeoverFingerprint(
        service="Ghost",
        cname_patterns=[r"\.ghost\.io$", r"ghost\.io"],
        body_patterns=[
            r"The thing you were looking for is no longer here",
            r"404.*?Ghost",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="Tumblr",
        cname_patterns=[r"\.tumblr\.com$", r"domains\.tumblr\.com"],
        body_patterns=[
            r"Whatever you were looking for doesn't currently exist",
            r"There's nothing here",
        ],
        status_codes=[404, 410],
    ),

    TakeoverFingerprint(
        service="WordPress.com",
        cname_patterns=[r"\.wordpress\.com$", r"wordpress\.com"],
        body_patterns=[
            r"Do you want to register \S+\.wordpress\.com\?",
            r"doesn't exist",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="Zendesk",
        cname_patterns=[r"\.zendesk\.com$", r"zendesk\.com"],
        body_patterns=[
            r"Oops, this help center no longer exists",
            r"Help Center Closed",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="HubSpot",
        cname_patterns=[r"\.hubspot\.com$", r"\.hs-sites\.com$", r"\.hubspotpagebuilder\.com$"],
        body_patterns=[
            r"Domain not found",
            r"does not exist in our system",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="Pantheon",
        cname_patterns=[r"\.pantheonsite\.io$", r"pantheon\.io"],
        body_patterns=[
            r"The gods are wise",
            r"404 error.*?Pantheon",
            r"There's nothing here",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="Surge.sh",
        cname_patterns=[r"\.surge\.sh$", r"surge\.sh"],
        body_patterns=[
            r"project not found",
            r"doesn't exist",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="Readme.io",
        cname_patterns=[r"\.readme\.io$", r"\.readme\.com$"],
        body_patterns=[
            r"Project doesnt exist",
            r"project doesn't exist",
            r"readme\.io.*?404",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="UserVoice",
        cname_patterns=[r"\.uservoice\.com$"],
        body_patterns=[
            r"This UserVoice subdomain is currently available",
            r"uservoice\.com.*?404",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="Desk.com",
        cname_patterns=[r"\.desk\.com$"],
        body_patterns=[
            r"Sorry, We Couldn't Find That Page",
            r"Help Center.*?Unavailable",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="SendGrid",
        cname_patterns=[r"em\..*?\.sendgrid\.net$", r"\.sendgrid\.net$"],
        body_patterns=[
            r"The domain you are looking for doesn't exist",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="Fly.io",
        cname_patterns=[r"\.fly\.dev$", r"fly\.io"],
        body_patterns=[
            r"404.*?fly\.io",
            r"This site is not available",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="Render",
        cname_patterns=[r"\.onrender\.com$"],
        body_patterns=[
            r"does not exist",
            r"No service found",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="Vercel",
        cname_patterns=[r"\.vercel\.app$", r"cname\.vercel-dns\.com$"],
        body_patterns=[
            r"The deployment you are trying to access does not exist",
            r"404: NOT_FOUND",
            r"This Deployment has been deleted",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="DigitalOcean App Platform",
        cname_patterns=[r"\.ondigitalocean\.app$"],
        body_patterns=[
            r"Domain Not Found",
            r"404",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="Squarespace",
        cname_patterns=[r"\.squarespace\.com$", r"squarespace\.com"],
        body_patterns=[
            r"No Such Account",
            r"this domain is not associated",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="Intercom",
        cname_patterns=[r"\.intercom\.help$", r"custom\.intercom\.help"],
        body_patterns=[
            r"Uh oh. That page doesn't exist",
            r"Page not found",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="Cargo",
        cname_patterns=[r"\.cargocollective\.com$"],
        body_patterns=[
            r"404 Not Found",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="Webflow",
        cname_patterns=[r"\.webflow\.io$", r"proxy\.webflow\.com$"],
        body_patterns=[
            r"The page you are looking for doesn't exist",
            r"404 Page Not Found",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="Strikingly",
        cname_patterns=[r"\.strikingly\.com$", r"s\.strikinglydns\.com$"],
        body_patterns=[
            r"page not found",
            r"BUILD A WEBSITE",
        ],
        status_codes=[404],
    ),

    TakeoverFingerprint(
        service="Launchrock",
        cname_patterns=[r"\.launchrock\.com$"],
        body_patterns=[
            r"It looks like you may have taken a wrong turn",
        ],
        status_codes=[404],
    ),
]


# ---------------------------------------------------------------------------
# Compile at import time
# ---------------------------------------------------------------------------

def get_compiled_fingerprints() -> list[TakeoverFingerprint]:
    return [fp.compile() for fp in TAKEOVER_FINGERPRINTS]


COMPILED_FINGERPRINTS: list[TakeoverFingerprint] = get_compiled_fingerprints()
