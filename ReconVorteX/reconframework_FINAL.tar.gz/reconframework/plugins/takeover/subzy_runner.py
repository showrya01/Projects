"""
plugins/takeover/subzy_runner.py
===================================
Subdomain takeover detection via the Subzy binary (PentestIT/subzy).

Subzy checks subdomains against its built-in fingerprint database
and outputs JSON results per vulnerable host.

Command:
    subzy run --targets subdomains.txt --output json --hide-fails

JSON output per finding:
    {"subdomain": "test.example.com", "service": "GitHub", "vulnerable": true}
"""

from __future__ import annotations

import asyncio
import json
import logging
import shutil
import tempfile
from pathlib import Path

from core.base_plugin import BasePlugin, PluginContext, PluginResult
from plugins.takeover.http_checker import TakeoverCandidate

log = logging.getLogger(__name__)


class SubzyRunner(BasePlugin[list[TakeoverCandidate]]):
    """Run Subzy against a list of subdomains and return findings."""

    NAME     = "subzy"
    PRIORITY = 5

    async def run(self, ctx: PluginContext) -> PluginResult[list[TakeoverCandidate]]:
        cfg    = ctx.config.phase9
        binary = shutil.which(cfg.subzy_bin) or cfg.subzy_bin

        if not shutil.which(binary):
            self._log.info("Subzy binary not found — skipping", extra={"searched": binary})
            return self._ok([])

        hosts: list[str] = ctx.metadata.get("takeover_hosts", [])
        if not hosts:
            return self._ok([])

        self._log.info("Subzy starting", extra={"hosts": len(hosts), "binary": binary})

        try:
            candidates = await self._run_subzy(binary, hosts, cfg)
        except Exception as exc:
            ctx.record_error(self.NAME, f"Subzy failed: {exc}", exc)
            return self._fail(str(exc))

        self._log.info("Subzy complete", extra={"findings": len(candidates)})
        return self._ok(candidates)

    async def _run_subzy(
        self,
        binary: str,
        hosts:  list[str],
        cfg,
    ) -> list[TakeoverCandidate]:
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".txt", delete=False, prefix="rf_subzy_"
        ) as tf:
            tf.write("\n".join(hosts))
            tmp_path = tf.name

        cmd = [
            binary, "run",
            "--targets", tmp_path,
            "--output",  "json",
            "--hide-fails",
            "--timeout",  str(cfg.timeout_s),
            "--concurrency", str(min(cfg.concurrency, 50)),
        ]

        self._log.debug("Subzy command", extra={"cmd": " ".join(cmd)})

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(),
                timeout=float(cfg.tool_timeout),
            )
        finally:
            Path(tmp_path).unlink(missing_ok=True)

        if stderr:
            self._log.debug(
                "Subzy stderr",
                extra={"snippet": stderr.decode(errors="replace")[:300]},
            )

        candidates: list[TakeoverCandidate] = []
        for line in stdout.decode(errors="replace").splitlines():
            line = line.strip()
            if not line or not line.startswith("{"):
                continue
            try:
                data = json.loads(line)
                if not data.get("vulnerable"):
                    continue
                host    = data.get("subdomain", "")
                service = data.get("service", "Unknown")
                candidates.append(TakeoverCandidate(
                    host=host,
                    url=f"https://{host}",
                    service=service,
                    fingerprint=data.get("type", "subzy-confirmed"),
                    confidence=cfg.conf_subzy,
                    method="subzy",
                    evidence=[f"Subzy confirmed vulnerable: {service}"],
                ))
            except (json.JSONDecodeError, KeyError):
                continue

        return candidates
