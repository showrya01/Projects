"""
plugins/live_hosts/aiohttp_prober.py
======================================
Pure-Python live host prober using aiohttp.

Used when the httpx binary is unavailable or fails.

Behaviour
---------
• Probes both http:// and https:// for each hostname concurrently.
• Follows up to max_redirects redirects, recording the full chain.
• Extracts <title> from the response body (up to max_body_bytes).
• Reads Server header for web_server.
• Resolves IP via aiohttp's connector (no extra DNS call).
• Retries transient errors (connection reset, timeout) up to retry_attempts.
• Semaphore-bounded to cfg.concurrency parallel requests.
"""

from __future__ import annotations

import asyncio
import re
import socket
import time
from urllib.parse import urlparse

import aiohttp
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from core.base_plugin import BasePlugin, PluginContext, PluginResult
from core.models import LiveHost

# Extract <title>...</title> case-insensitively, strip whitespace
_TITLE_RE = re.compile(rb"<title[^>]*>(.*?)</title>", re.IGNORECASE | re.DOTALL)
_MAX_TITLE_LEN = 256


def _extract_title(body: bytes) -> str | None:
    m = _TITLE_RE.search(body)
    if not m:
        return None
    raw = m.group(1).decode(errors="replace").strip()
    # Collapse whitespace
    title = " ".join(raw.split())
    return title[:_MAX_TITLE_LEN] or None


def _resolve_ip(hostname: str) -> str | None:
    """Best-effort synchronous DNS resolve (called once per host in executor)."""
    try:
        return socket.gethostbyname(hostname)
    except OSError:
        return None


class AiohttpProber(BasePlugin[list[LiveHost]]):
    """
    Pure-Python fallback prober.

    Invoked by the Phase 2 orchestrator when the httpx binary is absent.
    """

    NAME = "aiohttp_prober"
    PRIORITY = 10

    async def run(self, ctx: PluginContext) -> PluginResult[list[LiveHost]]:
        cfg = ctx.config.phase2
        hosts: list[str] = ctx.metadata.get("subdomains", [])

        if not hosts:
            return self._fail("No subdomains provided in ctx.metadata['subdomains']")

        self._log.info(
            "aiohttp fallback probe starting",
            extra={"host_count": len(hosts), "concurrency": cfg.concurrency},
        )

        live = await self._probe_all(hosts, cfg)

        self._log.info(
            "aiohttp probe complete",
            extra={"probed": len(hosts), "live": len(live)},
        )
        return self._ok(live)

    # ------------------------------------------------------------------
    # Core probe logic
    # ------------------------------------------------------------------

    async def _probe_all(self, hosts: list[str], cfg) -> list[LiveHost]:
        sem = asyncio.Semaphore(cfg.concurrency)
        live_codes = set(cfg.live_status_codes)

        connector = aiohttp.TCPConnector(
            ssl=False,
            limit=cfg.concurrency + 50,  # connector pool slightly larger than sem
            ttl_dns_cache=300,
        )
        timeout = aiohttp.ClientTimeout(total=cfg.timeout_s)
        headers = {"User-Agent": cfg.fallback_user_agent}

        async with aiohttp.ClientSession(
            connector=connector,
            timeout=timeout,
            headers=headers,
        ) as session:
            tasks = [
                self._probe_host(session, host, cfg, sem, live_codes)
                for host in hosts
            ]
            results = await asyncio.gather(*tasks, return_exceptions=True)

        live: list[LiveHost] = []
        for r in results:
            if isinstance(r, LiveHost):
                live.append(r)
            # Exceptions are already logged inside _probe_host
        return live

    async def _probe_host(
        self,
        session: aiohttp.ClientSession,
        hostname: str,
        cfg,
        sem: asyncio.Semaphore,
        live_codes: set[int],
    ) -> LiveHost | None:
        """
        Probe http:// and https:// for a single hostname.
        Returns the best LiveHost or None.
        """
        async with sem:
            candidates: list[LiveHost | None] = []

            for scheme in (["https", "http"] if cfg.probe_https else ["http"]):
                if scheme == "http" and not cfg.probe_http:
                    continue
                url = f"{scheme}://{hostname}"
                result = await self._fetch(session, url, cfg, live_codes)
                candidates.append(result)
                # If HTTPS succeeded, skip HTTP (no need to try both)
                if result and scheme == "https":
                    break

            # Prefer HTTPS result, then HTTP
            for c in candidates:
                if c is not None:
                    return c
            return None

    async def _fetch(
        self,
        session: aiohttp.ClientSession,
        url: str,
        cfg,
        live_codes: set[int],
    ) -> LiveHost | None:
        """Single URL fetch with redirect tracking."""
        redirect_chain: list[str] = []
        t0 = time.perf_counter()

        try:
            result = await self._fetch_with_retry(
                session, url, cfg, redirect_chain
            )
        except Exception:
            return None

        if result is None:
            return None

        status, final_url, headers, body = result
        elapsed_ms = (time.perf_counter() - t0) * 1000

        if status not in live_codes:
            return None

        hostname = urlparse(final_url).hostname or urlparse(url).hostname or url
        title = _extract_title(body) if body else None
        server = headers.get("Server") or headers.get("server")
        cl_raw = headers.get("Content-Length") or headers.get("content-length")
        content_length = int(cl_raw) if cl_raw and cl_raw.isdigit() else len(body or b"")

        # Resolve IP (sync — cheap, already cached by connector)
        loop = asyncio.get_event_loop()
        ip = await loop.run_in_executor(None, _resolve_ip, hostname)

        return LiveHost(
            url=final_url,
            host=hostname,
            status_code=status,
            title=title,
            redirect_chain=redirect_chain,
            ip_address=ip,
            web_server=server,
            content_length=content_length,
            technologies=[],    # Phase 3 handles fingerprinting
            response_time_ms=round(elapsed_ms, 2),
        )

    @retry(
        stop=stop_after_attempt(2),
        wait=wait_exponential(min=0.5, max=2.0),
        retry=retry_if_exception_type((aiohttp.ClientConnectorError, asyncio.TimeoutError)),
        reraise=False,
    )
    async def _fetch_with_retry(
        self,
        session: aiohttp.ClientSession,
        url: str,
        cfg,
        redirect_chain: list[str],
    ) -> tuple[int, str, dict, bytes] | None:
        """
        Perform the actual HTTP request.

        Returns (status, final_url, response_headers, body_bytes) or None.
        Manual redirect tracking so we can record the chain.
        """
        current_url = url
        redirects_followed = 0

        while redirects_followed <= cfg.max_redirects:
            try:
                async with session.get(
                    current_url,
                    allow_redirects=False,   # manual redirect tracking
                    ssl=False,
                ) as resp:
                    status = resp.status

                    # Track redirect
                    if status in (301, 302, 303, 307, 308):
                        location = resp.headers.get("Location")
                        if not location:
                            # No location header — treat as final response
                            body = await resp.content.read(cfg.max_body_bytes)
                            return status, str(resp.url), dict(resp.headers), body

                        redirect_chain.append(current_url)
                        # Handle relative redirects
                        if location.startswith("/"):
                            parsed = urlparse(current_url)
                            location = f"{parsed.scheme}://{parsed.netloc}{location}"
                        elif not location.startswith("http"):
                            parsed = urlparse(current_url)
                            location = f"{parsed.scheme}://{parsed.netloc}/{location.lstrip('/')}"

                        current_url = location
                        redirects_followed += 1
                        continue

                    # Final response
                    body = await resp.content.read(cfg.max_body_bytes)
                    return status, str(resp.url), dict(resp.headers), body

            except (aiohttp.ServerConnectionError, aiohttp.ClientOSError):
                return None

        # Exceeded max redirects
        self._log.debug(
            "Max redirects exceeded",
            extra={"url": url, "limit": cfg.max_redirects},
        )
        return None
