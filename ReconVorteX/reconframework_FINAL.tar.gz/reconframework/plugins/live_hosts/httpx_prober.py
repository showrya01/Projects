"""
plugins/live_hosts/httpx_prober.py
====================================
Live host discovery using the httpx binary (projectdiscovery/httpx).

Strategy
--------
1. Write the hostname list to a temp file.
2. Invoke:  httpx -l <file> -json -threads 150 -timeout 10 ...
3. Parse one JSON object per stdout line into LiveHost models.
4. Return the full list to the orchestrator.

httpx JSON line schema (subset we care about):
{
  "url": "https://sub.example.com",
  "host": "sub.example.com",
  "status-code": 200,
  "title": "Page Title",
  "webserver": "nginx/1.18.0",
  "content-length": 12345,
  "ip": "1.2.3.4",
  "tech": ["Bootstrap:4.3.1", "jQuery:3.4.1"],
  "chain-status-codes": [301, 200],
  "redirect-chain": ["http://sub.example.com"],
  "response-time": "342ms",
  "a": ["1.2.3.4"],
}
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import shutil
import tempfile
from pathlib import Path

from core.base_plugin import BasePlugin, PluginContext, PluginResult
from core.models import LiveHost

log = logging.getLogger(__name__)

_TIME_RE = re.compile(r"([\d.]+)")  # extract numeric part from "342ms"


def _parse_response_time(raw: str | None) -> float | None:
    """Convert httpx response-time string (e.g. '342ms', '1.2s') to ms float."""
    if not raw:
        return None
    m = _TIME_RE.search(raw)
    if not m:
        return None
    val = float(m.group(1))
    return val * 1000 if raw.endswith("s") and not raw.endswith("ms") else val


def _parse_line(line: str, live_codes: set[int]) -> LiveHost | None:
    """Parse one httpx JSON line into a LiveHost.  Returns None on skip/error."""
    try:
        data = json.loads(line)
    except json.JSONDecodeError:
        return None

    status = data.get("status-code") or data.get("status_code")
    if status not in live_codes:
        return None

    url   = data.get("url", "")
    host  = data.get("host") or data.get("input", "").lstrip("https://").lstrip("http://")

    # Redirect chain — httpx can give us chain-status-codes and redirect-chain
    redirect_chain: list[str] = data.get("redirect-chain") or []

    # Technologies — list of "Name:version" strings
    techs: list[str] = data.get("tech") or data.get("technologies") or []
    tech_names = [t.split(":")[0] for t in techs]

    return LiveHost(
        url=url,
        host=host,
        status_code=status,
        title=data.get("title"),
        redirect_chain=redirect_chain,
        ip_address=data.get("ip") or (data.get("a") or [None])[0],
        web_server=data.get("webserver") or data.get("web-server"),
        content_length=data.get("content-length"),
        technologies=tech_names,
        response_time_ms=_parse_response_time(data.get("response-time")),
    )


class HttpxBinaryProber(BasePlugin[list[LiveHost]]):
    """
    Probe a list of hostnames using the httpx binary.

    Returns a list of LiveHost objects.
    Raises RuntimeError if the binary is not found (caller falls back).
    """

    NAME = "httpx_binary"
    PRIORITY = 5

    async def run(self, ctx: PluginContext) -> PluginResult[list[LiveHost]]:
        cfg = ctx.config.phase2
        binary = shutil.which(cfg.httpx_bin) or cfg.httpx_bin

        if not shutil.which(binary):
            return self._fail(f"httpx binary not found at '{binary}'")

        # Retrieve subdomain list injected by orchestrator
        hosts: list[str] = ctx.metadata.get("subdomains", [])
        if not hosts:
            return self._fail("No subdomains provided in ctx.metadata['subdomains']")

        self._log.info(
            "httpx binary probe starting",
            extra={"binary": binary, "host_count": len(hosts), "threads": cfg.concurrency},
        )

        live_hosts = await self._run_httpx(binary, hosts, cfg)
        self._log.info(
            "httpx binary probe complete",
            extra={"total_probed": len(hosts), "live": len(live_hosts)},
        )
        return self._ok(live_hosts)

    async def _run_httpx(
        self,
        binary: str,
        hosts: list[str],
        cfg,  # Phase2Config
    ) -> list[LiveHost]:
        live_codes = set(cfg.live_status_codes)

        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".txt", delete=False, prefix="rf_hosts_"
        ) as tf:
            tf.write("\n".join(hosts))
            tmp_path = tf.name

        cmd = [
            binary,
            "-l", tmp_path,
            "-json",
            "-threads", str(cfg.concurrency),
            "-timeout", str(cfg.timeout_s),
            "-max-redirects", str(cfg.max_redirects),
            "-silent",
            *cfg.httpx_flags,
        ]
        if not cfg.follow_redirects and "-follow-redirects" in cmd:
            cmd.remove("-follow-redirects")

        self._log.debug("httpx command", extra={"cmd": " ".join(cmd)})

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await proc.communicate()
        finally:
            Path(tmp_path).unlink(missing_ok=True)

        if stderr:
            self._log.debug("httpx stderr", extra={"stderr": stderr.decode(errors="replace")[:500]})

        results: list[LiveHost] = []
        for raw_line in stdout.decode(errors="replace").splitlines():
            raw_line = raw_line.strip()
            if not raw_line:
                continue
            host = _parse_line(raw_line, live_codes)
            if host:
                results.append(host)

        return results
