"""
plugins/live_hosts/__init__.py
================================
Exports Phase 2 probers in order of preference.

The orchestrator tries PREFERRED first; on failure, uses FALLBACK.
"""

from plugins.live_hosts.aiohttp_prober import AiohttpProber
from plugins.live_hosts.httpx_prober import HttpxBinaryProber

# Tried in order — first success wins
PREFERRED = HttpxBinaryProber
FALLBACK  = AiohttpProber

__all__ = ["HttpxBinaryProber", "AiohttpProber", "PREFERRED", "FALLBACK"]
