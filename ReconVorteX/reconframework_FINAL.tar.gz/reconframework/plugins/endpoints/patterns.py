"""
plugins/endpoints/patterns.py
================================
Sensitive endpoint pattern library for Phase 7.

Each EndpointPattern defines:
  • A unique name and human description.
  • The category it belongs to (env_secrets, source_control, …).
  • A severity tier (CRITICAL / HIGH / MEDIUM / LOW / INFO).
  • A list of regex patterns applied against the URL path (+ optional query).
  • A phase11_score — points fed into the Phase 11 Risk Scoring Engine.
  • Optional tags for report grouping.

Coverage (full — all spec items + extended):
  1.  Environment & Secrets       — .env*, credentials, private keys
  2.  Source Control              — .git, .svn, .hg, .bzr
  3.  Backup & Archive Files      — .zip, .tar.gz, .sql, .bak, db dumps
  4.  Configuration Files         — web.config, settings.py, wp-config, app.yml
  5.  API Documentation           — swagger, openapi, graphql, api-docs, redoc
  6.  Admin Panels                — /admin, /administrator, /panel, /dashboard
  7.  Debug & Diagnostic          — phpinfo, /debug, /trace, actuator endpoints
  8.  Cloud & Infrastructure      — AWS metadata, GCP metadata, Azure IMDS
  9.  CI/CD & DevOps              — Jenkinsfile, .travis.yml, .gitlab-ci.yml
  10. Authentication & JWT        — /oauth, /token, /.well-known, /auth
  11. Package Managers            — package.json, composer.json, requirements.txt
  12. Framework Internals         — Rails info, Webpack HMR, Django internals
  13. Sensitive Data Files        — passwords.txt, secrets.yml, private.key
  14. Robots & Discovery          — robots.txt, sitemap.xml, security.txt
  15. Log & Error Files           — *.log, error.log, access.log, debug.log
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum


class Severity(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH     = "HIGH"
    MEDIUM   = "MEDIUM"
    LOW      = "LOW"
    INFO     = "INFO"


class PatternCategory(str, Enum):
    ENV_SECRETS    = "env_secrets"
    SOURCE_CONTROL = "source_control"
    BACKUP         = "backup"
    CONFIG         = "config"
    API_DOCS       = "api_docs"
    ADMIN          = "admin"
    DEBUG          = "debug"
    CLOUD          = "cloud"
    CI_CD          = "ci_cd"
    AUTH           = "auth"
    PACKAGE        = "package_manager"
    FRAMEWORK      = "framework_internal"
    SENSITIVE_DATA = "sensitive_data"
    DISCOVERY      = "discovery"
    LOGS           = "logs"


_SEVERITY_ORDER = {
    Severity.CRITICAL: 0,
    Severity.HIGH:     1,
    Severity.MEDIUM:   2,
    Severity.LOW:      3,
    Severity.INFO:     4,
}


@dataclass
class EndpointPattern:
    name:        str
    description: str
    category:    PatternCategory
    severity:    Severity
    phase11_score: int
    tags:        list[str] = field(default_factory=list)

    # Regex patterns applied to the lowercase URL path (and query string)
    path_patterns: list[str] = field(default_factory=list)

    # Pre-compiled patterns (populated by compile())
    _compiled: list[re.Pattern] = field(default_factory=list, repr=False)

    def compile(self) -> "EndpointPattern":
        self._compiled = [
            re.compile(p, re.IGNORECASE) for p in self.path_patterns
        ]
        return self

    def matches(self, url_path: str) -> bool:
        """Return True if any compiled pattern matches the URL path."""
        return any(p.search(url_path) for p in self._compiled)


# ---------------------------------------------------------------------------
# Pattern definitions
# ---------------------------------------------------------------------------

ENDPOINT_PATTERNS: list[EndpointPattern] = [

    # ===================================================================
    # 1. ENVIRONMENT & SECRETS
    # ===================================================================

    EndpointPattern(
        name="env_file",
        description=".env file — may contain DB passwords, API keys, secrets",
        category=PatternCategory.ENV_SECRETS,
        severity=Severity.CRITICAL,
        phase11_score=10,
        tags=["secrets", "credentials"],
        path_patterns=[
            r"/\.env$",
            r"/\.env\.(local|prod|production|staging|dev|development|test|backup|example|sample)$",
            r"/env\.txt$",
        ],
    ),
    EndpointPattern(
        name="env_docker",
        description="Docker / docker-compose environment file",
        category=PatternCategory.ENV_SECRETS,
        severity=Severity.CRITICAL,
        phase11_score=10,
        tags=["secrets", "docker"],
        path_patterns=[
            r"/docker-compose\.ya?ml$",
            r"/\.dockerenv$",
            r"/docker\.env$",
        ],
    ),
    EndpointPattern(
        name="private_key",
        description="Private key file (.pem, .key, .p12, .pfx)",
        category=PatternCategory.ENV_SECRETS,
        severity=Severity.CRITICAL,
        phase11_score=10,
        tags=["secrets", "crypto"],
        path_patterns=[
            r"\.(pem|key|p12|pfx|crt|cer|der)$",
            r"private[_-]?key",
            r"id_rsa",
            r"id_dsa",
            r"id_ecdsa",
            r"id_ed25519",
        ],
    ),
    EndpointPattern(
        name="aws_credentials",
        description="AWS credentials or config file",
        category=PatternCategory.ENV_SECRETS,
        severity=Severity.CRITICAL,
        phase11_score=10,
        tags=["secrets", "aws", "cloud"],
        path_patterns=[
            r"/\.aws/(credentials|config)$",
            r"/aws[_-]?(credentials|secrets|keys?)\.?(txt|json|cfg|ini)?$",
        ],
    ),
    EndpointPattern(
        name="credentials_file",
        description="Generic credentials / secrets file",
        category=PatternCategory.ENV_SECRETS,
        severity=Severity.CRITICAL,
        phase11_score=10,
        tags=["secrets", "credentials"],
        path_patterns=[
            r"/(credentials|secrets?|passwords?|passwd|shadow)\.(txt|json|xml|yaml|yml|cfg|ini|env)$",
            r"/secret[_-]?key",
            r"/api[_-]?key",
            r"/auth[_-]?token",
        ],
    ),

    # ===================================================================
    # 2. SOURCE CONTROL
    # ===================================================================

    EndpointPattern(
        name="git_config",
        description=".git directory exposed — source code leak",
        category=PatternCategory.SOURCE_CONTROL,
        severity=Severity.CRITICAL,
        phase11_score=10,
        tags=["source-code", "git"],
        path_patterns=[
            r"/\.git(/|$)",
            r"/\.git/config$",
            r"/\.git/HEAD$",
            r"/\.git/COMMIT_EDITMSG$",
            r"/\.git/index$",
        ],
    ),
    EndpointPattern(
        name="svn_exposed",
        description=".svn directory exposed",
        category=PatternCategory.SOURCE_CONTROL,
        severity=Severity.CRITICAL,
        phase11_score=10,
        tags=["source-code", "svn"],
        path_patterns=[
            r"/\.svn(/|$)",
            r"/\.svn/entries$",
            r"/\.svn/wc\.db$",
        ],
    ),
    EndpointPattern(
        name="hg_exposed",
        description=".hg (Mercurial) directory exposed",
        category=PatternCategory.SOURCE_CONTROL,
        severity=Severity.HIGH,
        phase11_score=7,
        tags=["source-code", "mercurial"],
        path_patterns=[r"/\.hg(/|$)"],
    ),
    EndpointPattern(
        name="ds_store",
        description=".DS_Store file — macOS finder metadata, reveals directory structure",
        category=PatternCategory.SOURCE_CONTROL,
        severity=Severity.MEDIUM,
        phase11_score=4,
        tags=["info-disclosure"],
        path_patterns=[r"/\.DS_Store$"],
    ),

    # ===================================================================
    # 3. BACKUP & ARCHIVE FILES
    # ===================================================================

    EndpointPattern(
        name="backup_archive",
        description="Backup archive file — potential full source/data dump",
        category=PatternCategory.BACKUP,
        severity=Severity.CRITICAL,
        phase11_score=10,
        tags=["backup", "data-leak"],
        path_patterns=[
            r"\.(zip|tar\.gz|tar\.bz2|tgz|7z|rar|tar)$",
            r"(backup|back[_-]?up|bak|bkp|dump|archive)[^/]*\.(zip|tar\.gz|tgz|7z|sql|gz)$",
        ],
    ),
    EndpointPattern(
        name="sql_dump",
        description="SQL dump file — database contents exposed",
        category=PatternCategory.BACKUP,
        severity=Severity.CRITICAL,
        phase11_score=10,
        tags=["backup", "database", "data-leak"],
        path_patterns=[
            r"\.(sql|sql\.gz|sql\.bz2)$",
            r"(dump|backup|export|data)[^/]*\.sql",
            r"db\.(sql|dump|bak)$",
        ],
    ),
    EndpointPattern(
        name="bak_file",
        description="Generic .bak backup file",
        category=PatternCategory.BACKUP,
        severity=Severity.HIGH,
        phase11_score=7,
        tags=["backup"],
        path_patterns=[
            r"\.(bak|orig|old|save|swp|swo|~)$",
            r"~$",
        ],
    ),
    EndpointPattern(
        name="log_archive",
        description="Archived log file",
        category=PatternCategory.BACKUP,
        severity=Severity.MEDIUM,
        phase11_score=4,
        tags=["backup", "logs"],
        path_patterns=[r"\.(log\.gz|log\.zip|log\.bz2)$"],
    ),

    # ===================================================================
    # 4. CONFIGURATION FILES
    # ===================================================================

    EndpointPattern(
        name="web_config",
        description="Web server / app configuration file",
        category=PatternCategory.CONFIG,
        severity=Severity.HIGH,
        phase11_score=7,
        tags=["config", "info-disclosure"],
        path_patterns=[
            r"/web\.config$",
            r"/web\.xml$",
            r"/app\.config$",
            r"/applicationContext\.xml$",
            r"/struts\.xml$",
            r"/hibernate\.cfg\.xml$",
        ],
    ),
    EndpointPattern(
        name="wp_config",
        description="WordPress configuration — DB credentials",
        category=PatternCategory.CONFIG,
        severity=Severity.CRITICAL,
        phase11_score=10,
        tags=["config", "wordpress", "credentials"],
        path_patterns=[
            r"/wp-config\.php$",
            r"/wp-config\.php\.bak$",
            r"/wp-config\.php~$",
        ],
    ),
    EndpointPattern(
        name="php_config",
        description="PHP configuration or settings file",
        category=PatternCategory.CONFIG,
        severity=Severity.HIGH,
        phase11_score=7,
        tags=["config", "php"],
        path_patterns=[
            r"/config\.php$",
            r"/configuration\.php$",
            r"/settings\.php$",
            r"/database\.php$",
            r"/db\.php$",
            r"/connect\.php$",
        ],
    ),
    EndpointPattern(
        name="django_settings",
        description="Django settings file",
        category=PatternCategory.CONFIG,
        severity=Severity.HIGH,
        phase11_score=7,
        tags=["config", "django", "python"],
        path_patterns=[
            r"/settings\.py$",
            r"/local_settings\.py$",
            r"/production\.py$",
        ],
    ),
    EndpointPattern(
        name="rails_config",
        description="Ruby on Rails configuration file",
        category=PatternCategory.CONFIG,
        severity=Severity.HIGH,
        phase11_score=7,
        tags=["config", "rails"],
        path_patterns=[
            r"/database\.yml$",
            r"/secrets\.yml$",
            r"/credentials\.yml\.enc$",
            r"/master\.key$",
        ],
    ),
    EndpointPattern(
        name="laravel_env",
        description="Laravel .env configuration",
        category=PatternCategory.CONFIG,
        severity=Severity.CRITICAL,
        phase11_score=10,
        tags=["config", "laravel", "credentials"],
        path_patterns=[r"/\.env$"],   # covered by env_file too — belt and braces
    ),
    EndpointPattern(
        name="htaccess",
        description=".htaccess or .htpasswd file",
        category=PatternCategory.CONFIG,
        severity=Severity.MEDIUM,
        phase11_score=4,
        tags=["config", "apache"],
        path_patterns=[
            r"/\.htaccess$",
            r"/\.htpasswd$",
            r"/\.htdigest$",
        ],
    ),
    EndpointPattern(
        name="nginx_config",
        description="Nginx configuration file",
        category=PatternCategory.CONFIG,
        severity=Severity.MEDIUM,
        phase11_score=4,
        tags=["config", "nginx"],
        path_patterns=[
            r"/nginx\.conf$",
            r"/nginx[^/]*\.conf$",
        ],
    ),

    # ===================================================================
    # 5. API DOCUMENTATION
    # ===================================================================

    EndpointPattern(
        name="swagger",
        description="Swagger / OpenAPI specification — full API surface exposed",
        category=PatternCategory.API_DOCS,
        severity=Severity.HIGH,
        phase11_score=7,
        tags=["api-docs", "swagger"],
        path_patterns=[
            r"/swagger\.json$",
            r"/swagger\.yaml$",
            r"/swagger\.yml$",
            r"/swagger-ui(\.html)?(/|$)",
            r"/api-docs(/|$)",
            r"/openapi\.json$",
            r"/openapi\.yaml$",
            r"/v[0-9]+/swagger",
            r"/api/swagger",
        ],
    ),
    EndpointPattern(
        name="graphql_endpoint",
        description="GraphQL endpoint — introspection may expose full schema",
        category=PatternCategory.API_DOCS,
        severity=Severity.HIGH,
        phase11_score=7,
        tags=["api", "graphql"],
        path_patterns=[
            r"/graphql(/|$|\?)",
            r"/graphiql(/|$)",
            r"/graph(/|$)",
            r"/__graphql(/|$)",
        ],
    ),
    EndpointPattern(
        name="redoc",
        description="ReDoc API documentation page",
        category=PatternCategory.API_DOCS,
        severity=Severity.MEDIUM,
        phase11_score=4,
        tags=["api-docs"],
        path_patterns=[r"/redoc(/|$)", r"/api/redoc"],
    ),
    EndpointPattern(
        name="wsdl",
        description="WSDL (SOAP service definition)",
        category=PatternCategory.API_DOCS,
        severity=Severity.MEDIUM,
        phase11_score=4,
        tags=["api-docs", "soap"],
        path_patterns=[r"\?wsdl$", r"\.wsdl$"],
    ),

    # ===================================================================
    # 6. ADMIN PANELS
    # ===================================================================

    EndpointPattern(
        name="admin_panel",
        description="Admin panel endpoint",
        category=PatternCategory.ADMIN,
        severity=Severity.HIGH,
        phase11_score=7,
        tags=["admin-panel"],
        path_patterns=[
            r"/(admin|administrator|admin_area|wp-admin|wp-login\.php)(/|$)",
            r"/(cpanel|plesk|webmin|directadmin)(/|$)",
            r"/admin\.php$",
            r"/panel(/|$)",
            r"/controlpanel(/|$)",
            r"/manage(/|$)",
        ],
    ),
    EndpointPattern(
        name="phpmyadmin",
        description="phpMyAdmin database admin panel",
        category=PatternCategory.ADMIN,
        severity=Severity.CRITICAL,
        phase11_score=10,
        tags=["admin-panel", "database", "phpmyadmin"],
        path_patterns=[
            r"/(phpmyadmin|pma|myadmin|mysql)(/|$)",
        ],
    ),

    # ===================================================================
    # 7. DEBUG & DIAGNOSTIC
    # ===================================================================

    EndpointPattern(
        name="phpinfo",
        description="phpinfo() page — full server configuration disclosure",
        category=PatternCategory.DEBUG,
        severity=Severity.HIGH,
        phase11_score=7,
        tags=["debug", "info-disclosure", "php"],
        path_patterns=[
            r"/(phpinfo|info|php_info)\.php$",
            r"/\?phpinfo",
        ],
    ),
    EndpointPattern(
        name="spring_actuator",
        description="Spring Boot Actuator endpoint — metrics, env, heap dump",
        category=PatternCategory.DEBUG,
        severity=Severity.HIGH,
        phase11_score=7,
        tags=["debug", "spring-boot", "actuator"],
        path_patterns=[
            r"/actuator(/|$)",
            r"/actuator/(env|beans|heapdump|mappings|info|health|metrics|threaddump|loggers)(/|$)",
        ],
    ),
    EndpointPattern(
        name="debug_endpoint",
        description="Debug, trace, or diagnostic endpoint",
        category=PatternCategory.DEBUG,
        severity=Severity.MEDIUM,
        phase11_score=4,
        tags=["debug"],
        path_patterns=[
            r"/(debug|trace|diagnostics|profiler)(/|$|\?)",
            r"/\?debug",
            r"/_debug(/|$)",
            r"/debug\.php$",
        ],
    ),
    EndpointPattern(
        name="server_status",
        description="Apache/Nginx server-status or server-info page",
        category=PatternCategory.DEBUG,
        severity=Severity.MEDIUM,
        phase11_score=4,
        tags=["debug", "info-disclosure"],
        path_patterns=[
            r"/server-status(/|$)",
            r"/server-info(/|$)",
            r"/nginx_status(/|$)",
            r"/status(/|$|\?)",
        ],
    ),
    EndpointPattern(
        name="error_page",
        description="Exposed error or exception page",
        category=PatternCategory.DEBUG,
        severity=Severity.LOW,
        phase11_score=2,
        tags=["debug", "error-page"],
        path_patterns=[
            r"/error(/|$|\?)",
            r"/exception(/|$)",
            r"/(500|404|403)\.html?$",
        ],
    ),

    # ===================================================================
    # 8. CLOUD & INFRASTRUCTURE METADATA
    # ===================================================================

    EndpointPattern(
        name="aws_metadata",
        description="AWS EC2 instance metadata endpoint (SSRF target)",
        category=PatternCategory.CLOUD,
        severity=Severity.CRITICAL,
        phase11_score=10,
        tags=["cloud", "aws", "ssrf"],
        path_patterns=[
            r"/latest/meta-data",
            r"/169\.254\.169\.254",
            r"/iam/security-credentials",
        ],
    ),
    EndpointPattern(
        name="gcp_metadata",
        description="GCP instance metadata endpoint (SSRF target)",
        category=PatternCategory.CLOUD,
        severity=Severity.CRITICAL,
        phase11_score=10,
        tags=["cloud", "gcp", "ssrf"],
        path_patterns=[
            r"/computeMetadata/v1",
            r"metadata\.google\.internal",
        ],
    ),
    EndpointPattern(
        name="kubernetes_api",
        description="Kubernetes API or dashboard endpoint",
        category=PatternCategory.CLOUD,
        severity=Severity.CRITICAL,
        phase11_score=10,
        tags=["cloud", "kubernetes"],
        path_patterns=[
            r"/api/v1/(pods|secrets|namespaces)",
            r"/(kubernetes|k8s)(/|$)",
            r"/:(\d+)/(api|version)$",
        ],
    ),

    # ===================================================================
    # 9. CI/CD & DEVOPS
    # ===================================================================

    EndpointPattern(
        name="jenkins",
        description="Jenkins CI endpoint",
        category=PatternCategory.CI_CD,
        severity=Severity.HIGH,
        phase11_score=7,
        tags=["ci-cd", "jenkins"],
        path_patterns=[
            r"/jenkins(/|$)",
            r"/jenkins/script(/|$)",
            r"/job/[^/]+/build",
        ],
    ),
    EndpointPattern(
        name="cicd_config",
        description="CI/CD configuration file",
        category=PatternCategory.CI_CD,
        severity=Severity.HIGH,
        phase11_score=7,
        tags=["ci-cd", "config"],
        path_patterns=[
            r"/Jenkinsfile$",
            r"/\.travis\.yml$",
            r"/\.circleci/config\.yml$",
            r"/\.gitlab-ci\.yml$",
            r"/\.github/workflows/[^/]+\.ya?ml$",
            r"/azure-pipelines\.yml$",
            r"/bitbucket-pipelines\.yml$",
            r"/Makefile$",
        ],
    ),
    EndpointPattern(
        name="docker_compose",
        description="Docker Compose file — service definitions, credentials",
        category=PatternCategory.CI_CD,
        severity=Severity.HIGH,
        phase11_score=7,
        tags=["ci-cd", "docker"],
        path_patterns=[
            r"/docker-compose(\.override)?\.ya?ml$",
            r"/Dockerfile$",
            r"/\.dockerignore$",
        ],
    ),

    # ===================================================================
    # 10. AUTHENTICATION & JWT
    # ===================================================================

    EndpointPattern(
        name="oauth_endpoints",
        description="OAuth / authentication endpoint",
        category=PatternCategory.AUTH,
        severity=Severity.MEDIUM,
        phase11_score=4,
        tags=["auth", "oauth"],
        path_patterns=[
            r"/(oauth|oauth2)(/|$)",
            r"/\.well-known/(openid-configuration|jwks\.json|oauth-authorization-server)$",
            r"/connect/(authorize|token|introspect|userinfo)(/|$)",
        ],
    ),
    EndpointPattern(
        name="token_endpoint",
        description="Token issuance or refresh endpoint",
        category=PatternCategory.AUTH,
        severity=Severity.HIGH,
        phase11_score=7,
        tags=["auth", "jwt"],
        path_patterns=[
            r"/api/(token|refresh|access_token)(/|$)",
            r"/auth/token(/|$)",
            r"/v[0-9]+/token(/|$)",
        ],
    ),
    EndpointPattern(
        name="jwt_secret_file",
        description="JWT secret or signing key file",
        category=PatternCategory.AUTH,
        severity=Severity.CRITICAL,
        phase11_score=10,
        tags=["auth", "jwt", "secrets"],
        path_patterns=[
            r"/jwt[_-]?secret",
            r"/signing[_-]?key",
            r"/jwks\.json$",
        ],
    ),

    # ===================================================================
    # 11. PACKAGE MANAGERS
    # ===================================================================

    EndpointPattern(
        name="npm_package",
        description="NPM package.json — dependency list, scripts, metadata",
        category=PatternCategory.PACKAGE,
        severity=Severity.LOW,
        phase11_score=2,
        tags=["package-manager", "npm"],
        path_patterns=[
            r"/package\.json$",
            r"/package-lock\.json$",
            r"/yarn\.lock$",
            r"/npm-shrinkwrap\.json$",
            r"/\.npmrc$",
        ],
    ),
    EndpointPattern(
        name="composer_json",
        description="PHP Composer package file",
        category=PatternCategory.PACKAGE,
        severity=Severity.LOW,
        phase11_score=2,
        tags=["package-manager", "php", "composer"],
        path_patterns=[
            r"/composer\.(json|lock)$",
            r"/vendor/autoload\.php$",
        ],
    ),
    EndpointPattern(
        name="python_requirements",
        description="Python requirements / Pipfile",
        category=PatternCategory.PACKAGE,
        severity=Severity.LOW,
        phase11_score=2,
        tags=["package-manager", "python"],
        path_patterns=[
            r"/requirements([-_]?\w*)?\.txt$",
            r"/Pipfile(\.lock)?$",
            r"/pyproject\.toml$",
            r"/setup\.(py|cfg)$",
        ],
    ),
    EndpointPattern(
        name="ruby_gemfile",
        description="Ruby Gemfile / Gemfile.lock",
        category=PatternCategory.PACKAGE,
        severity=Severity.LOW,
        phase11_score=2,
        tags=["package-manager", "ruby"],
        path_patterns=[
            r"/Gemfile(\.lock)?$",
            r"/\.bundle/config$",
        ],
    ),
    EndpointPattern(
        name="gradle_maven",
        description="Gradle or Maven build file",
        category=PatternCategory.PACKAGE,
        severity=Severity.LOW,
        phase11_score=2,
        tags=["package-manager", "java"],
        path_patterns=[
            r"/build\.gradle(\.kts)?$",
            r"/pom\.xml$",
            r"/gradle\.properties$",
            r"/settings\.gradle(\.kts)?$",
        ],
    ),

    # ===================================================================
    # 12. FRAMEWORK INTERNALS
    # ===================================================================

    EndpointPattern(
        name="webpack_hmr",
        description="Webpack Hot Module Replacement — dev server exposed",
        category=PatternCategory.FRAMEWORK,
        severity=Severity.MEDIUM,
        phase11_score=4,
        tags=["framework", "webpack", "dev-exposure"],
        path_patterns=[
            r"/__webpack_hmr$",
            r"/sockjs-node(/|$)",
            r"/webpack-dev-server(/|$)",
            r"/__webpack_dev_server__(/|$)",
        ],
    ),
    EndpointPattern(
        name="rails_info",
        description="Rails info / routing pages — exposed in dev mode",
        category=PatternCategory.FRAMEWORK,
        severity=Severity.MEDIUM,
        phase11_score=4,
        tags=["framework", "rails"],
        path_patterns=[
            r"/rails/info(/|$)",
            r"/rails/mailers(/|$)",
        ],
    ),
    EndpointPattern(
        name="django_debug",
        description="Django debug toolbar or admin endpoint",
        category=PatternCategory.FRAMEWORK,
        severity=Severity.HIGH,
        phase11_score=7,
        tags=["framework", "django", "debug"],
        path_patterns=[
            r"/__debug__(/|$)",
            r"/django-admin(/|$)",
            r"/silk(/|$)",
        ],
    ),
    EndpointPattern(
        name="laravel_telescope",
        description="Laravel Telescope debug panel",
        category=PatternCategory.FRAMEWORK,
        severity=Severity.HIGH,
        phase11_score=7,
        tags=["framework", "laravel", "debug"],
        path_patterns=[
            r"/telescope(/|$)",
            r"/horizon(/|$)",
        ],
    ),
    EndpointPattern(
        name="wordpress_api",
        description="WordPress REST API — user enumeration, post data",
        category=PatternCategory.FRAMEWORK,
        severity=Severity.MEDIUM,
        phase11_score=4,
        tags=["framework", "wordpress", "api"],
        path_patterns=[
            r"/wp-json(/|$)",
            r"/wp-json/wp/v2/(users|posts|pages)(/|$)",
            r"/xmlrpc\.php$",
        ],
    ),

    # ===================================================================
    # 13. SENSITIVE DATA FILES
    # ===================================================================

    EndpointPattern(
        name="sensitive_text",
        description="Plaintext file with sensitive name",
        category=PatternCategory.SENSITIVE_DATA,
        severity=Severity.HIGH,
        phase11_score=7,
        tags=["sensitive-data"],
        path_patterns=[
            r"/(passwords?|passwd|shadow|users?|accounts?)\.(txt|csv|json|xml)$",
            r"/dump\.(txt|csv|json)$",
            r"/userdata\.(csv|json|xml)$",
        ],
    ),
    EndpointPattern(
        name="certificate_file",
        description="TLS certificate or private key file",
        category=PatternCategory.SENSITIVE_DATA,
        severity=Severity.CRITICAL,
        phase11_score=10,
        tags=["sensitive-data", "crypto"],
        path_patterns=[
            r"\.(pem|crt|cer|p7b|p12|pfx|jks|keystore)$",
            r"/ssl(/certs?|/keys?|/private)",
        ],
    ),

    # ===================================================================
    # 14. ROBOTS & DISCOVERY
    # ===================================================================

    EndpointPattern(
        name="robots_txt",
        description="robots.txt — may reveal hidden paths",
        category=PatternCategory.DISCOVERY,
        severity=Severity.LOW,
        phase11_score=2,
        tags=["discovery"],
        path_patterns=[r"/robots\.txt$"],
    ),
    EndpointPattern(
        name="sitemap",
        description="Sitemap file — reveals URL structure",
        category=PatternCategory.DISCOVERY,
        severity=Severity.INFO,
        phase11_score=1,
        tags=["discovery"],
        path_patterns=[
            r"/sitemap([-_]\w+)?\.xml(\.gz)?$",
            r"/sitemap\.txt$",
        ],
    ),
    EndpointPattern(
        name="security_txt",
        description="security.txt — responsible disclosure info",
        category=PatternCategory.DISCOVERY,
        severity=Severity.INFO,
        phase11_score=1,
        tags=["discovery"],
        path_patterns=[
            r"/security\.txt$",
            r"/\.well-known/security\.txt$",
        ],
    ),
    EndpointPattern(
        name="humans_txt",
        description="humans.txt — team / technology info",
        category=PatternCategory.DISCOVERY,
        severity=Severity.INFO,
        phase11_score=1,
        tags=["discovery"],
        path_patterns=[r"/humans\.txt$"],
    ),

    # ===================================================================
    # 15. LOG & ERROR FILES
    # ===================================================================

    EndpointPattern(
        name="access_log",
        description="Exposed web server access or error log",
        category=PatternCategory.LOGS,
        severity=Severity.HIGH,
        phase11_score=7,
        tags=["logs", "info-disclosure"],
        path_patterns=[
            r"/(access|error|debug|application|app|server)[_.-]?log(s)?(\.\w+)?$",
            r"/logs?/(access|error|debug)\.log$",
            r"/log\.txt$",
        ],
    ),
    EndpointPattern(
        name="php_error_log",
        description="PHP error log file",
        category=PatternCategory.LOGS,
        severity=Severity.HIGH,
        phase11_score=7,
        tags=["logs", "php", "info-disclosure"],
        path_patterns=[
            r"/php[_-]?errors?\.log$",
            r"/php_error\.log$",
        ],
    ),
    EndpointPattern(
        name="syslog",
        description="System log exposed",
        category=PatternCategory.LOGS,
        severity=Severity.CRITICAL,
        phase11_score=10,
        tags=["logs", "system"],
        path_patterns=[
            r"/(var/log/|proc/|etc/)(syslog|messages|auth\.log|kern\.log)",
            r"/syslog$",
        ],
    ),
]


# ---------------------------------------------------------------------------
# Compile all patterns at import time
# ---------------------------------------------------------------------------

_SEVERITY_RANK = {s: i for i, s in enumerate(
    [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO]
)}


def get_compiled_patterns() -> list[EndpointPattern]:
    """Return all patterns with regex pre-compiled, sorted CRITICAL first."""
    patterns = [p.compile() for p in ENDPOINT_PATTERNS]
    return sorted(patterns, key=lambda p: _SEVERITY_RANK[p.severity])


COMPILED_PATTERNS: list[EndpointPattern] = get_compiled_patterns()
