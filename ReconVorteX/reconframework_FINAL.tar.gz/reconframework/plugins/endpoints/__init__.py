"""
plugins/endpoints/__init__.py
================================
Phase 7 — Sensitive Endpoint Discovery plugin package.
"""

from plugins.endpoints.matcher import EndpointFinding, match_urls, severity_passes
from plugins.endpoints.patterns import (
    COMPILED_PATTERNS,
    EndpointPattern,
    PatternCategory,
    Severity,
)

__all__ = [
    "match_urls",
    "EndpointFinding",
    "severity_passes",
    "EndpointPattern",
    "PatternCategory",
    "Severity",
    "COMPILED_PATTERNS",
]
