"""
plugins/endpoints/matcher.py
================================
URL-to-pattern matching engine for Phase 7.

Takes a list of URLs from Phase 6 and runs every EndpointPattern against
the URL's path+query. Returns one EndpointFinding per (url, pattern) hit.

Design
------
• Stateless — call match_urls() from anywhere.
• One URL can match multiple patterns (e.g. /backup.sql matches both
  backup_archive and sql_dump).
• Results are deduplicated at (url, pattern.name) level.
• Severity ordering is preserved in the returned list.
• Phase 11 score is attached to each finding for downstream consumption.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from urllib.parse import urlparse

from plugins.endpoints.patterns import (
    COMPILED_PATTERNS,
    EndpointPattern,
    PatternCategory,
    Severity,
)


# ---------------------------------------------------------------------------
# Finding model
# ---------------------------------------------------------------------------

@dataclass
class EndpointFinding:
    """A single sensitive endpoint match."""

    url:          str
    host:         str
    path:         str
    pattern_name: str
    description:  str
    category:     PatternCategory
    severity:     Severity
    phase11_score: int
    tags:         list[str] = field(default_factory=list)
    matched_at:   datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )

    def to_dict(self) -> dict:
        return {
            "url":           self.url,
            "host":          self.host,
            "path":          self.path,
            "pattern_name":  self.pattern_name,
            "description":   self.description,
            "category":      self.category.value,
            "severity":      self.severity.value,
            "phase11_score": self.phase11_score,
            "tags":          self.tags,
            "matched_at":    self.matched_at.isoformat(),
        }


# ---------------------------------------------------------------------------
# Severity filtering helper
# ---------------------------------------------------------------------------

_SEVERITY_RANK = {
    Severity.CRITICAL: 0,
    Severity.HIGH:     1,
    Severity.MEDIUM:   2,
    Severity.LOW:      3,
    Severity.INFO:     4,
}


def severity_passes(finding: Severity, minimum: Severity) -> bool:
    return _SEVERITY_RANK[finding] <= _SEVERITY_RANK[minimum]


# ---------------------------------------------------------------------------
# Matcher
# ---------------------------------------------------------------------------

def match_urls(
    urls:        list[str],
    *,
    min_severity: Severity = Severity.LOW,
    patterns:    list[EndpointPattern] | None = None,
) -> list[EndpointFinding]:
    """
    Run all patterns against every URL.

    Parameters
    ----------
    urls:         List of URLs from Phase 6.
    min_severity: Minimum severity to include in results.
    patterns:     Override pattern list (default: COMPILED_PATTERNS).

    Returns
    -------
    Deduplicated EndpointFinding list sorted CRITICAL → INFO, then by URL.
    """
    active_patterns = patterns if patterns is not None else COMPILED_PATTERNS
    seen: set[tuple[str, str]] = set()   # (url, pattern_name)
    findings: list[EndpointFinding] = []

    for url in urls:
        url = url.strip()
        if not url:
            continue

        try:
            parsed = urlparse(url)
            # Match against path + query string combined
            path_query = (parsed.path + ("?" + parsed.query if parsed.query else "")).lower()
            host = parsed.hostname or ""
        except Exception:
            continue

        for pat in active_patterns:
            # Fast severity pre-filter before running regex
            if not severity_passes(pat.severity, min_severity):
                continue

            if not pat.matches(path_query):
                continue

            key = (url, pat.name)
            if key in seen:
                continue
            seen.add(key)

            findings.append(EndpointFinding(
                url=url,
                host=host,
                path=parsed.path,
                pattern_name=pat.name,
                description=pat.description,
                category=pat.category,
                severity=pat.severity,
                phase11_score=pat.phase11_score,
                tags=list(pat.tags),
            ))

    # Sort: severity DESC, then URL asc
    findings.sort(key=lambda f: (_SEVERITY_RANK[f.severity], f.url))
    return findings
