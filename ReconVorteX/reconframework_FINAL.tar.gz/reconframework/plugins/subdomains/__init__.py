"""
plugins/subdomains/__init__.py
================================
Exports all subdomain-discovery plugins in one import.

To add a new plugin:
  1. Create plugins/subdomains/myplugin.py with a class inheriting BasePlugin.
  2. Import it here and add to ALL_PLUGINS.

That's it — the Phase 1 orchestrator picks it up automatically.
"""

from plugins.subdomains.alienvault import AlienVaultPlugin
from plugins.subdomains.chaos import ChaosPlugin
from plugins.subdomains.crtsh import CrtShPlugin
from plugins.subdomains.hackertarget import HackerTargetPlugin
from plugins.subdomains.rapiddns import RapidDNSPlugin
from plugins.subdomains.tool_runner import (
    AmassPlugin,
    AssetfinderPlugin,
    FindomainPlugin,
    SubfinderPlugin,
)

ALL_PLUGINS = [
    SubfinderPlugin,
    AssetfinderPlugin,
    FindomainPlugin,
    AmassPlugin,
    CrtShPlugin,
    ChaosPlugin,
    AlienVaultPlugin,
    HackerTargetPlugin,
    RapidDNSPlugin,
]

__all__ = [
    "ALL_PLUGINS",
    "SubfinderPlugin",
    "AssetfinderPlugin",
    "FindomainPlugin",
    "AmassPlugin",
    "CrtShPlugin",
    "ChaosPlugin",
    "AlienVaultPlugin",
    "HackerTargetPlugin",
    "RapidDNSPlugin",
]
