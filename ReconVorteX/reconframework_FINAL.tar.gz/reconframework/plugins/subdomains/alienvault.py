"""
plugins/subdomains/alienvault.py
=================================
Passive subdomain discovery via AlienVault OTX Passive DNS API.

No auth required for basic queries.
Docs: https://otx.alienvault.com/api
"""

from __future__ import annotations

import re

from core.base_plugin import BasePlugin, PluginContext, PluginResult
from core.http_client import fetch_json
from core.models import Subdomain

_HOSTNAME_RE = re.compile(r"^(?:[a-z0-9](?:[a-z0-9\-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$")


class AlienVaultPlugin(BasePlugin[list[Subdomain]]):
    """Fetch passive DNS records from AlienVault OTX."""

    NAME = "alienvault"
    PRIORITY = 15

    async def run(self, ctx: PluginContext) -> PluginResult[list[Subdomain]]:
        domain = ctx.domain
        url = ctx.config.phase1.alienvault_url.format(domain=domain)

        self._log.info("Querying AlienVault OTX", extra={"domain": domain})

        data = await fetch_json(
            url,
            timeout_s=ctx.config.phase1.http_timeout,
            retries=ctx.config.phase1.retry_attempts,
            wait_min=ctx.config.phase1.retry_wait_min,
            wait_max=ctx.config.phase1.retry_wait_max,
        )

        if data is None or not isinstance(data, dict):
            ctx.record_error(self.NAME, "AlienVault OTX returned no data")
            return self._fail("AlienVault OTX returned no data")

        passive_dns: list[dict] = data.get("passive_dns", [])
        subdomains: dict[str, Subdomain] = {}

        for record in passive_dns:
            hostname: str = record.get("hostname", "").strip().lower()
            if not hostname or not hostname.endswith(domain):
                continue
            if not _HOSTNAME_RE.match(hostname):
                continue
            if hostname not in subdomains:
                subdomains[hostname] = Subdomain(host=hostname, sources=[self.NAME])

        found = list(subdomains.values())
        self._log.info(
            "AlienVault OTX complete",
            extra={"domain": domain, "found": len(found)},
        )
        return self._ok(found)
