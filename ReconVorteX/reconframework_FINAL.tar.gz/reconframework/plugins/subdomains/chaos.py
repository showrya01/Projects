"""
plugins/subdomains/chaos.py
============================
Passive subdomain discovery via ProjectDiscovery Chaos Dataset.

Requires a free API key: https://chaos.projectdiscovery.io/
Set via env var: RF_CHAOS_KEY or config.yaml phase1.chaos_key

The Chaos dataset is a massive, continuously-updated collection of public
bug-bounty program subdomains. Even without a key, some programs publish
their data publicly — the plugin gracefully skips if unauthenticated.
"""

from __future__ import annotations

import io
import zipfile

import aiohttp

from core.base_plugin import BasePlugin, PluginContext, PluginResult
from core.models import Subdomain


class ChaosPlugin(BasePlugin[list[Subdomain]]):
    """Fetch subdomains from ProjectDiscovery Chaos dataset (ZIP → txt)."""

    NAME = "chaos"
    PRIORITY = 12

    async def run(self, ctx: PluginContext) -> PluginResult[list[Subdomain]]:
        api_key = ctx.config.phase1.chaos_key
        if not api_key:
            self._log.info(
                "Chaos key not set — skipping",
                extra={"domain": ctx.domain, "hint": "Set RF_CHAOS_KEY env var"},
            )
            # Soft skip: not an error, just unavailable
            return self._ok([])

        domain = ctx.domain
        url = ctx.config.phase1.chaos_url.format(domain=domain)
        headers = {"Authorization": api_key}
        timeout = aiohttp.ClientTimeout(total=ctx.config.phase1.http_timeout)

        self._log.info("Querying Chaos dataset", extra={"domain": domain})

        try:
            raw_bytes = await self._fetch_zip(url, headers, timeout)
        except aiohttp.ClientResponseError as exc:
            if exc.status == 404:
                self._log.info(
                    "Chaos: domain not in dataset",
                    extra={"domain": domain},
                )
                return self._ok([])
            if exc.status in (401, 403):
                ctx.record_error(self.NAME, "Chaos: invalid or expired API key", exc)
                return self._fail("Chaos API key rejected (401/403)")
            ctx.record_error(self.NAME, f"Chaos HTTP {exc.status}", exc)
            return self._fail(str(exc))
        except Exception as exc:  # noqa: BLE001
            ctx.record_error(self.NAME, f"Chaos request failed: {exc}", exc)
            return self._fail(str(exc))

        # Unzip in-memory and parse hostnames
        subdomains: dict[str, Subdomain] = {}
        try:
            with zipfile.ZipFile(io.BytesIO(raw_bytes)) as zf:
                for name in zf.namelist():
                    if not name.endswith(".txt"):
                        continue
                    text = zf.read(name).decode(errors="replace")
                    for line in text.splitlines():
                        host = line.strip().lower().lstrip("*.")
                        if host and (host.endswith(f".{domain}") or host == domain):
                            if host not in subdomains:
                                subdomains[host] = Subdomain(host=host, sources=[self.NAME])
        except zipfile.BadZipFile as exc:
            ctx.record_error(self.NAME, "Chaos: bad zip response", exc)
            return self._fail("Bad zip received from Chaos")

        found = list(subdomains.values())
        self._log.info(
            "Chaos complete",
            extra={"domain": domain, "found": len(found)},
        )
        return self._ok(found)

    async def _fetch_zip(
        self,
        url: str,
        headers: dict,
        timeout: aiohttp.ClientTimeout,
    ) -> bytes:
        """Download the ZIP file and return raw bytes."""
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(url, headers=headers, ssl=False) as resp:
                resp.raise_for_status()
                return await resp.read()
