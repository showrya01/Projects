"""
plugins/subdomains/tool_runner.py
==================================
Wrappers for external binary tools: Subfinder, Amass, Assetfinder, Findomain.

Each class follows the same pattern:
  1. Check if the binary exists on PATH (or configured path).
  2. Run it asynchronously with asyncio.create_subprocess_exec.
  3. Parse stdout line-by-line for hostnames.
  4. Return a PluginResult[list[Subdomain]].

If a binary is not installed the plugin returns a failed result
WITHOUT raising — the orchestrator simply skips that source.
"""

from __future__ import annotations

import asyncio
import re
import shutil
from typing import Any

from core.base_plugin import BasePlugin, PluginContext, PluginResult
from core.models import Subdomain

_HOSTNAME_RE = re.compile(r"^(?:[a-z0-9](?:[a-z0-9\-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$")


# ---------------------------------------------------------------------------
# Helper — async subprocess with timeout
# ---------------------------------------------------------------------------

async def _run_tool(
    cmd: list[str],
    timeout_s: int = 300,
) -> tuple[str, str, int]:
    """
    Run *cmd* asynchronously.

    Returns (stdout, stderr, returncode).
    Raises asyncio.TimeoutError if *timeout_s* is exceeded.
    """
    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        stdout_b, stderr_b = await asyncio.wait_for(
            proc.communicate(), timeout=timeout_s
        )
    except asyncio.TimeoutError:
        proc.kill()
        await proc.communicate()
        raise

    return (
        stdout_b.decode(errors="replace"),
        stderr_b.decode(errors="replace"),
        proc.returncode or 0,
    )


def _parse_hostnames(text: str, domain: str) -> list[str]:
    """Extract valid hostnames that belong to *domain* from raw text."""
    found = []
    for line in text.splitlines():
        host = line.strip().lower().lstrip("*.")
        if not host:
            continue
        # Some tools print "host,ip" or "host [ip]" — take first token
        host = re.split(r"[\s,\[\]]", host)[0]
        if not host.endswith(domain):
            continue
        if not _HOSTNAME_RE.match(host):
            continue
        found.append(host)
    return found


def _binary_available(binary: str) -> bool:
    return shutil.which(binary) is not None


# ---------------------------------------------------------------------------
# Subfinder
# ---------------------------------------------------------------------------

class SubfinderPlugin(BasePlugin[list[Subdomain]]):
    """Run Subfinder and parse its output."""

    NAME = "subfinder"
    PRIORITY = 1  # fastest passive tool — run first

    async def run(self, ctx: PluginContext) -> PluginResult[list[Subdomain]]:
        binary = ctx.config.phase1.subfinder_bin
        if not _binary_available(binary):
            ctx.record_error(self.NAME, f"Binary not found: {binary}")
            return self._fail(f"{binary} not installed or not on PATH")

        domain = ctx.domain
        cmd = [binary, "-d", domain, "-silent", "-all"]
        self._log.info("Running Subfinder", extra={"domain": domain, "cmd": " ".join(cmd)})

        try:
            stdout, stderr, rc = await _run_tool(cmd, timeout_s=ctx.config.phase1.tool_timeout)
        except asyncio.TimeoutError:
            return self._fail(f"Subfinder timed out after {ctx.config.phase1.tool_timeout}s")

        if rc != 0:
            self._log.warning(
                "Subfinder non-zero exit",
                extra={"rc": rc, "stderr": stderr[:200]},
            )

        hosts = _parse_hostnames(stdout, domain)
        subdomains = [Subdomain(host=h, sources=[self.NAME]) for h in dict.fromkeys(hosts)]
        self._log.info("Subfinder complete", extra={"domain": domain, "found": len(subdomains)})
        return self._ok(subdomains)


# ---------------------------------------------------------------------------
# Amass
# ---------------------------------------------------------------------------

class AmassPlugin(BasePlugin[list[Subdomain]]):
    """Run Amass in passive enumeration mode."""

    NAME = "amass"
    PRIORITY = 5  # slightly heavier than subfinder

    async def run(self, ctx: PluginContext) -> PluginResult[list[Subdomain]]:
        binary = ctx.config.phase1.amass_bin
        if not _binary_available(binary):
            ctx.record_error(self.NAME, f"Binary not found: {binary}")
            return self._fail(f"{binary} not installed or not on PATH")

        domain = ctx.domain
        # -passive: no active probing, just intelligence sources
        cmd = [binary, "enum", "-passive", "-norecursive", "-d", domain]
        self._log.info("Running Amass", extra={"domain": domain, "cmd": " ".join(cmd)})

        try:
            stdout, stderr, rc = await _run_tool(cmd, timeout_s=ctx.config.phase1.tool_timeout)
        except asyncio.TimeoutError:
            return self._fail(f"Amass timed out after {ctx.config.phase1.tool_timeout}s")

        hosts = _parse_hostnames(stdout, domain)
        subdomains = [Subdomain(host=h, sources=[self.NAME]) for h in dict.fromkeys(hosts)]
        self._log.info("Amass complete", extra={"domain": domain, "found": len(subdomains)})
        return self._ok(subdomains)


# ---------------------------------------------------------------------------
# Assetfinder
# ---------------------------------------------------------------------------

class AssetfinderPlugin(BasePlugin[list[Subdomain]]):
    """Run Assetfinder (tomnomnom) for quick passive discovery."""

    NAME = "assetfinder"
    PRIORITY = 2

    async def run(self, ctx: PluginContext) -> PluginResult[list[Subdomain]]:
        binary = ctx.config.phase1.assetfinder_bin
        if not _binary_available(binary):
            ctx.record_error(self.NAME, f"Binary not found: {binary}")
            return self._fail(f"{binary} not installed or not on PATH")

        domain = ctx.domain
        cmd = [binary, "--subs-only", domain]
        self._log.info("Running Assetfinder", extra={"domain": domain})

        try:
            stdout, stderr, rc = await _run_tool(cmd, timeout_s=ctx.config.phase1.tool_timeout)
        except asyncio.TimeoutError:
            return self._fail(f"Assetfinder timed out after {ctx.config.phase1.tool_timeout}s")

        hosts = _parse_hostnames(stdout, domain)
        subdomains = [Subdomain(host=h, sources=[self.NAME]) for h in dict.fromkeys(hosts)]
        self._log.info("Assetfinder complete", extra={"domain": domain, "found": len(subdomains)})
        return self._ok(subdomains)


# ---------------------------------------------------------------------------
# Findomain
# ---------------------------------------------------------------------------

class FindomainPlugin(BasePlugin[list[Subdomain]]):
    """Run Findomain for certificate-transparency + API sources."""

    NAME = "findomain"
    PRIORITY = 3

    async def run(self, ctx: PluginContext) -> PluginResult[list[Subdomain]]:
        binary = ctx.config.phase1.findomain_bin
        if not _binary_available(binary):
            ctx.record_error(self.NAME, f"Binary not found: {binary}")
            return self._fail(f"{binary} not installed or not on PATH")

        domain = ctx.domain
        cmd = [binary, "--target", domain, "--quiet"]
        self._log.info("Running Findomain", extra={"domain": domain})

        try:
            stdout, stderr, rc = await _run_tool(cmd, timeout_s=ctx.config.phase1.tool_timeout)
        except asyncio.TimeoutError:
            return self._fail(f"Findomain timed out after {ctx.config.phase1.tool_timeout}s")

        hosts = _parse_hostnames(stdout, domain)
        subdomains = [Subdomain(host=h, sources=[self.NAME]) for h in dict.fromkeys(hosts)]
        self._log.info("Findomain complete", extra={"domain": domain, "found": len(subdomains)})
        return self._ok(subdomains)
