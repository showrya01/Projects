"""
plugins/subdomains/crtsh.py
============================
Passive subdomain discovery via crt.sh certificate transparency logs.

No binary required — pure HTTPS query to crt.sh JSON API.
"""

from __future__ import annotations

import re
from typing import Any

from core.base_plugin import BasePlugin, PluginContext, PluginResult
from core.http_client import fetch_json
from core.models import Subdomain

# Only keep valid-looking hostnames
_HOSTNAME_RE = re.compile(r"^(?:[a-z0-9](?:[a-z0-9\-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$")


class CrtShPlugin(BasePlugin[list[Subdomain]]):
    """Fetch subdomains from crt.sh certificate transparency search."""

    NAME = "crtsh"
    PRIORITY = 10  # passive & fast — run early

    async def run(self, ctx: PluginContext) -> PluginResult[list[Subdomain]]:
        domain = ctx.domain
        url = ctx.config.phase1.crtsh_url.format(domain=f"%.{domain}")

        self._log.info("Querying crt.sh", extra={"domain": domain, "url": url})

        data = await fetch_json(
            url,
            timeout_s=ctx.config.phase1.http_timeout,
            retries=ctx.config.phase1.retry_attempts,
            wait_min=ctx.config.phase1.retry_wait_min,
            wait_max=ctx.config.phase1.retry_wait_max,
        )

        if data is None:
            ctx.record_error(self.NAME, "crt.sh request failed or returned no data")
            return self._fail("crt.sh returned no data")

        subdomains: dict[str, Subdomain] = {}

        for entry in data:
            # crt.sh returns name_value which may contain newline-separated names
            name_value: str = entry.get("name_value", "")
            for raw in name_value.splitlines():
                host = raw.strip().lower().lstrip("*.")
                if not host or not host.endswith(domain):
                    continue
                if not _HOSTNAME_RE.match(host):
                    continue
                if host not in subdomains:
                    subdomains[host] = Subdomain(host=host, sources=[self.NAME])

        found = list(subdomains.values())
        self._log.info(
            "crt.sh complete",
            extra={"domain": domain, "found": len(found)},
        )
        return self._ok(found)
