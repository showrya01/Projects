"""
plugins/subdomains/rapiddns.py
================================
Passive subdomain discovery via RapidDNS.io HTML scrape.

No auth required.  Parses the HTML table for hostnames.
"""

from __future__ import annotations

import re

from core.base_plugin import BasePlugin, PluginContext, PluginResult
from core.http_client import fetch_text
from core.models import Subdomain

_HOSTNAME_RE = re.compile(r"^(?:[a-z0-9](?:[a-z0-9\-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$")
# RapidDNS puts hostnames inside <td>...</td> cells
_TD_RE = re.compile(r"<td[^>]*>([^<]+)</td>", re.IGNORECASE)


class RapidDNSPlugin(BasePlugin[list[Subdomain]]):
    """Scrape RapidDNS.io for known subdomains."""

    NAME = "rapiddns"
    PRIORITY = 25

    async def run(self, ctx: PluginContext) -> PluginResult[list[Subdomain]]:
        domain = ctx.domain
        url = ctx.config.phase1.rapiddns_url.format(domain=domain)

        self._log.info("Querying RapidDNS", extra={"domain": domain})

        text = await fetch_text(
            url,
            timeout_s=ctx.config.phase1.http_timeout,
            retries=ctx.config.phase1.retry_attempts,
            wait_min=ctx.config.phase1.retry_wait_min,
            wait_max=ctx.config.phase1.retry_wait_max,
            headers={"Accept": "text/html"},
        )

        if text is None:
            ctx.record_error(self.NAME, "RapidDNS returned no data")
            return self._fail("RapidDNS returned no data")

        subdomains: dict[str, Subdomain] = {}
        for match in _TD_RE.finditer(text):
            candidate = match.group(1).strip().lower()
            if not candidate.endswith(domain):
                continue
            if not _HOSTNAME_RE.match(candidate):
                continue
            if candidate not in subdomains:
                subdomains[candidate] = Subdomain(host=candidate, sources=[self.NAME])

        found = list(subdomains.values())
        self._log.info(
            "RapidDNS complete",
            extra={"domain": domain, "found": len(found)},
        )
        return self._ok(found)
