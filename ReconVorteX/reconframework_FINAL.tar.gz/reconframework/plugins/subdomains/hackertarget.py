"""
plugins/subdomains/hackertarget.py
===================================
Passive subdomain discovery via HackerTarget hostsearch API.

Free tier: limited requests/day.  No key required.
https://hackertarget.com/find-dns-host-records/
"""

from __future__ import annotations

import re

from core.base_plugin import BasePlugin, PluginContext, PluginResult
from core.http_client import fetch_text
from core.models import Subdomain

_HOSTNAME_RE = re.compile(r"^(?:[a-z0-9](?:[a-z0-9\-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$")


class HackerTargetPlugin(BasePlugin[list[Subdomain]]):
    """Fetch subdomains from HackerTarget hostsearch."""

    NAME = "hackertarget"
    PRIORITY = 20

    async def run(self, ctx: PluginContext) -> PluginResult[list[Subdomain]]:
        domain = ctx.domain
        url = ctx.config.phase1.hackertarget_url.format(domain=domain)

        self._log.info("Querying HackerTarget", extra={"domain": domain})

        text = await fetch_text(
            url,
            timeout_s=ctx.config.phase1.http_timeout,
            retries=ctx.config.phase1.retry_attempts,
            wait_min=ctx.config.phase1.retry_wait_min,
            wait_max=ctx.config.phase1.retry_wait_max,
        )

        if text is None:
            ctx.record_error(self.NAME, "HackerTarget returned no data")
            return self._fail("HackerTarget returned no data")

        # Rate-limit message from HackerTarget
        if "API count exceeded" in text or "error" in text.lower():
            ctx.record_error(self.NAME, f"HackerTarget API limit/error: {text[:100]}")
            return self._fail(text[:100])

        subdomains: dict[str, Subdomain] = {}
        # Response format: "subdomain.example.com,1.2.3.4\n..."
        for line in text.splitlines():
            parts = line.split(",")
            if not parts:
                continue
            host = parts[0].strip().lower()
            if not host or not host.endswith(domain):
                continue
            if not _HOSTNAME_RE.match(host):
                continue
            if host not in subdomains:
                subdomains[host] = Subdomain(host=host, sources=[self.NAME])

        found = list(subdomains.values())
        self._log.info(
            "HackerTarget complete",
            extra={"domain": domain, "found": len(found)},
        )
        return self._ok(found)
