# DorkMatrix

> **Search Beyond Search Engines.**

DorkMatrix is a fully open-source, self-hosted recon platform for bug hunters.
Type a Google Dork query and instantly search across Google, Bing, DuckDuckGo,
Brave, and Yandex — each opening in its own tab with your query pre-filled.

No paid APIs. No proxies. No SaaS. Runs entirely on your machine.

🔗 **Repository:** https://github.com/showrya01/Projects/tree/main/DorkMatrix/frontend

---

## What It Does

Sometimes sensitive files, admin panels, logs, backup files, or exposed endpoints
appear in one search engine but not others. DorkMatrix lets you fire the same dork
across all five engines in one click — so you never miss what one engine indexed
and another didn't.

---

## Features

- **5-engine search** — Google, Bing, DuckDuckGo, Brave, Yandex
- **Terminal-style UI** — dark mode, hacker aesthetic
- **Prebuilt dork library** — secrets, admin panels, logs, backups, DB dumps, cloud exposure
- **Target auto-fill** — set a target once, `{TARGET}` fills across all dorks automatically
- **One-click copy** — copy any dork to clipboard instantly
- **Zero cost** — no paid services required

---

## Project Structure

```
DorkMatrix/
├── frontend/
│   ├── src/
│   │   ├── app/
│   │   │   ├── layout.js          # Root layout
│   │   │   ├── globals.css        # Global styles + Tailwind
│   │   │   ├── page.js            # Landing page  →  /
│   │   │   ├── search/
│   │   │   │   └── page.js        # Dashboard      →  /search
│   │   │   └── settings/
│   │   │       └── page.js        # Settings        →  /settings
│   │   ├── components/
│   │   │   └── shared/
│   │   │       └── Nav.jsx        # Shared navigation bar
│   │   ├── data/
│   │   │   └── mockData.js        # Dork library + engine constants
│   │   └── lib/
│   │       └── api.js             # Backend API client (optional)
│   ├── package.json
│   ├── next.config.js
│   ├── tailwind.config.js
│   ├── postcss.config.js
│   └── jsconfig.json
└── README.md
```

---

## Requirements

| Tool | Version |
|------|---------|
| Node.js | 18 or higher |
| npm | 9 or higher |

Check your versions:
```bash
node -v
npm -v
```

---

## Setup & Installation

### Step 1 — Clone the repository

```bash
git clone https://github.com/showrya01/Projects.git
cd Projects/DorkMatrix/frontend
```

---

### Step 2 — Install dependencies

```bash
npm install
```

You will see some deprecation warnings — these are from Next.js sub-dependencies
and are safe to ignore. Installation is complete when you see no `npm error` lines.

---

### Step 3 — Run locally

```bash
npm run dev
```

Expected output:
```
▲ Next.js 14.x.x
- Local: http://localhost:3000
✓ Ready in ~2s
```

Open your browser and go to:
```
http://localhost:3000
```

---

## How to Use

### Basic Search

1. Go to **http://localhost:3000/search**
2. Type your dork in the terminal input bar:
   ```
   site:example.com ext:env
   ```
3. Click any engine button — it opens that engine in a new tab with your query

### Using the Target Field

Set a target domain to auto-fill `{TARGET}` across all dorks in the library:

```
Target: example.com
Dork:   site:{TARGET} ext:env  →  becomes  →  site:example.com ext:env
```

### Dork Library

Below the search bar there are prebuilt dorks in 6 categories:

| Category | What it finds |
|----------|--------------|
| `/secrets_exposure` | `.env` files, API keys, AWS credentials |
| `/admin_panels` | Login pages, dashboards, cPanel |
| `/logs` | Error logs, debug output, stack traces |
| `/backups` | `.bak`, `.zip`, `.tar.gz`, `.old` files |
| `/database_dumps` | `.sql`, `.db`, `.sqlite` files |
| `/cloud_exposure` | S3 buckets, GCS, Azure Blob Storage |

Click **↗** on any dork to load it into the search bar.
Click the **copy** icon to copy it to clipboard.

---

## Search Engines

| Engine | Button Color | Notes |
|--------|-------------|-------|
| Google | Gray | Best coverage, may require CAPTCHA for automated queries |
| Bing | Blue | Reliable, good indexing of older content |
| DuckDuckGo | Amber | Privacy-focused, no tracking, default on Enter key |
| Brave | Orange | Independent index, growing coverage |
| Yandex | Rose | Strong coverage of Eastern European / Russian infrastructure |

> Pressing **Enter** opens DuckDuckGo by default.

---

## Example Dorks to Try

```
# Find exposed environment files
site:example.com ext:env

# Find admin panels
site:example.com inurl:admin

# Find exposed database files
site:example.com ext:sql

# Find AWS credentials
site:example.com ("AWS_ACCESS_KEY_ID")

# Find error logs
site:example.com ext:log intext:error

# Find backup files
site:example.com ext:bak
```

Replace `example.com` with your target domain.

---

## Troubleshooting

### 404 on localhost:3000

Check for a duplicate `app/` folder at the root level:

```bash
ls ~/Projects/DorkMatrix/frontend/
```

If you see an `app/` folder alongside `src/`, delete it:

```bash
rm -rf app/ components/ lib/
rm -rf .next/
npm run dev
```

---

### npm install fails with EPERM on Windows/WSL

You are running Windows npm inside WSL. Install Node.js natively inside WSL:

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
source ~/.bashrc
nvm install 18
nvm use 18
npm install
```

---

### Page loads but looks unstyled

TailwindCSS build failed. Run:

```bash
rm -rf .next node_modules/.cache
npm run dev
```

---

### Popup blocked when clicking engine buttons

Your browser is blocking new tabs from localhost. Fix:

- **Chrome/Brave** → Click the blocked popup icon in the address bar → Allow always
- **Firefox** → Click the shield icon → Allow popups from localhost

---

## Build for Production

```bash
npm run build
npm start
```

Runs on port 3000 by default.

---

## Tech Stack

| Technology | Purpose |
|-----------|---------|
| Next.js 14 | React framework, App Router |
| React 18 | UI components |
| TailwindCSS 3 | Styling |
| lucide-react | Icons |
| framer-motion | Animations |

---

## Legal & Responsible Use

DorkMatrix is a tool for authorized security research, bug bounty hunting,
and penetration testing.

**Only use it against:**
- Your own infrastructure
- Intentionally vulnerable practice environments (e.g. testphp.vulnweb.com)
- Bug bounty targets within their defined scope

Unauthorized use against systems you do not own or have explicit written
permission to test may violate laws including the Computer Fraud and Abuse
Act (CFAA) and equivalent legislation in your country.

The authors are not responsible for misuse.

---

## License

MIT — free to use, modify, and distribute.

---

*Built for bug hunters. Use responsibly.*
